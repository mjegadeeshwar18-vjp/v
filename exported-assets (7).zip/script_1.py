# Create services directory first
import os
os.makedirs('services', exist_ok=True)

# Create enhanced payment service
payment_service = '''const Razorpay = require('razorpay');
const crypto = require('crypto');
const axios = require('axios');

class PaymentService {
    constructor() {
        // Initialize Razorpay
        this.razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY_ID,
            key_secret: process.env.RAZORPAY_KEY_SECRET,
        });
        
        // Payment methods configuration
        this.paymentMethods = {
            UPI: 'upi',
            NET_BANKING: 'netbanking',
            CARD: 'card',
            WALLET: 'wallet',
            EMI: 'emi'
        };
    }

    /**
     * Create Razorpay order for EMI payment
     */
    async createEMIPaymentOrder(amount, currency = 'INR', receipt, notes = {}) {
        try {
            const options = {
                amount: amount * 100, // Amount in paisa
                currency,
                receipt,
                notes: {
                    ...notes,
                    payment_type: 'emi_payment',
                    platform: 'p2p_lending'
                }
            };

            const order = await this.razorpay.orders.create(options);
            return {
                success: true,
                order
            };
        } catch (error) {
            console.error('Error creating EMI payment order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create Razorpay order for investment
     */
    async createInvestmentOrder(amount, currency = 'INR', receipt, notes = {}) {
        try {
            const options = {
                amount: amount * 100, // Amount in paisa
                currency,
                receipt,
                notes: {
                    ...notes,
                    payment_type: 'investment',
                    platform: 'p2p_lending'
                }
            };

            const order = await this.razorpay.orders.create(options);
            return {
                success: true,
                order
            };
        } catch (error) {
            console.error('Error creating investment order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Verify payment signature from Razorpay
     */
    verifyPaymentSignature(razorpay_order_id, razorpay_payment_id, razorpay_signature) {
        try {
            const sign = razorpay_order_id + "|" + razorpay_payment_id;
            const expectedSign = crypto
                .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
                .update(sign.toString())
                .digest("hex");

            return razorpay_signature === expectedSign;
        } catch (error) {
            console.error('Error verifying payment signature:', error);
            return false;
        }
    }

    /**
     * Get payment details from Razorpay
     */
    async getPaymentDetails(paymentId) {
        try {
            const payment = await this.razorpay.payments.fetch(paymentId);
            return {
                success: true,
                payment
            };
        } catch (error) {
            console.error('Error fetching payment details:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Process refund
     */
    async processRefund(paymentId, amount, reason = 'Normal refund') {
        try {
            const refund = await this.razorpay.payments.refund(paymentId, {
                amount: amount * 100, // Amount in paisa
                reason,
                receipt: `refund_${Date.now()}`
            });

            return {
                success: true,
                refund
            };
        } catch (error) {
            console.error('Error processing refund:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create payout for investor returns (requires Razorpay X)
     */
    async createPayout(amount, accountNumber, ifsc, purpose = 'investment_returns') {
        try {
            const payout = await axios.post('https://api.razorpay.com/v1/payouts', {
                account_number: process.env.RAZORPAY_ACCOUNT_NUMBER,
                amount: amount * 100,
                currency: 'INR',
                mode: 'NEFT',
                purpose,
                fund_account: {
                    account_type: 'bank_account',
                    bank_account: {
                        account_number: accountNumber,
                        ifsc
                    },
                    contact: {
                        name: 'Investor',
                        type: 'customer'
                    }
                },
                queue_if_low_balance: true,
                reference_id: `payout_${Date.now()}`
            }, {
                auth: {
                    username: process.env.RAZORPAY_KEY_ID,
                    password: process.env.RAZORPAY_KEY_SECRET
                }
            });

            return {
                success: true,
                payout: payout.data
            };
        } catch (error) {
            console.error('Error creating payout:', error);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }

    /**
     * Generate payment link for EMI
     */
    async generatePaymentLink(amount, description, customerInfo, dueDate) {
        try {
            const paymentLink = await this.razorpay.paymentLink.create({
                amount: amount * 100,
                currency: 'INR',
                description,
                customer: {
                    name: customerInfo.name,
                    email: customerInfo.email,
                    contact: customerInfo.phone
                },
                notify: {
                    sms: true,
                    email: true
                },
                reminder_enable: true,
                callback_url: `${process.env.FRONTEND_URL}/payment-callback`,
                callback_method: 'get',
                expire_by: Math.floor(new Date(dueDate).getTime() / 1000)
            });

            return {
                success: true,
                paymentLink
            };
        } catch (error) {
            console.error('Error generating payment link:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Check payment status
     */
    async checkPaymentStatus(orderId) {
        try {
            const order = await this.razorpay.orders.fetch(orderId);
            const payments = await this.razorpay.orders.fetchPayments(orderId);
            
            return {
                success: true,
                order,
                payments: payments.items
            };
        } catch (error) {
            console.error('Error checking payment status:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
}

module.exports = new PaymentService();
'''

with open('services/paymentService.js', 'w') as f:
    f.write(payment_service)

# Create notification service
notification_service = '''const nodemailer = require('nodemailer');

class NotificationService {
    constructor() {
        this.transporter = nodemailer.createTransporter({
            host: process.env.EMAIL_HOST || 'smtp.gmail.com',
            port: process.env.EMAIL_PORT || 587,
            secure: false,
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });
    }

    /**
     * Send EMI reminder email
     */
    async sendEMIReminder(user, loan, emi) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: `EMI Reminder - Due Date: ${new Date(emi.dueDate).toLocaleDateString()}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #2563eb;">EMI Payment Reminder</h2>
                    <p>Dear ${user.name},</p>
                    <p>This is a reminder that your EMI payment is due soon.</p>
                    <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Payment Details:</h3>
                        <p><strong>Loan ID:</strong> ${loan._id}</p>
                        <p><strong>EMI Number:</strong> ${emi.emiNumber}</p>
                        <p><strong>Amount:</strong> ₹${emi.amount.toLocaleString()}</p>
                        <p><strong>Due Date:</strong> ${new Date(emi.dueDate).toLocaleDateString()}</p>
                    </div>
                    <a href="${process.env.FRONTEND_URL}/dashboard" 
                       style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                       Pay Now
                    </a>
                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        Please ensure timely payment to avoid late fees and maintain your credit score.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending EMI reminder:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send payment confirmation email
     */
    async sendPaymentConfirmation(user, transaction) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: 'Payment Confirmation',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">Payment Confirmed</h2>
                    <p>Dear ${user.name},</p>
                    <p>Your payment has been successfully processed.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
                        <h3>Transaction Details:</h3>
                        <p><strong>Transaction ID:</strong> ${transaction._id}</p>
                        <p><strong>Amount:</strong> ₹${transaction.amount.toLocaleString()}</p>
                        <p><strong>Type:</strong> ${transaction.type.replace('_', ' ').toUpperCase()}</p>
                        <p><strong>Date:</strong> ${new Date(transaction.createdAt).toLocaleString()}</p>
                    </div>
                    <p style="color: #64748b; font-size: 14px;">
                        Thank you for using our platform.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending payment confirmation:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send loan approval notification
     */
    async sendLoanApproval(borrower, loan) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: borrower.email,
            subject: 'Loan Application Approved',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">Congratulations! Your Loan is Approved</h2>
                    <p>Dear ${borrower.name},</p>
                    <p>We're pleased to inform you that your loan application has been approved.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Loan Details:</h3>
                        <p><strong>Amount:</strong> ₹${loan.amount.toLocaleString()}</p>
                        <p><strong>Interest Rate:</strong> ${loan.interestRate}% per annum</p>
                        <p><strong>EMI:</strong> ₹${loan.emi.toLocaleString()}</p>
                    </div>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending notification:', error);
            return { success: false, error: error.message };
        }
    }
}

module.exports = new NotificationService();
'''

with open('services/notificationService.js', 'w') as f:
    f.write(notification_service)

print("Created payment and notification services:")
print("- services/paymentService.js (Real Razorpay integration)")
print("- services/notificationService.js (Email notifications)")

# Update the enhanced .env file with payment gateway variables
env_enhanced = '''# Database
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/p2p_lending?retryWrites=true&w=majority

# Server
NODE_ENV=production
PORT=5000
FRONTEND_URL=https://your-frontend-domain.com

# JWT
JWT_SECRET=your_super_secure_jwt_secret_key_here_min_32_characters
JWT_EXPIRE=30d

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-gmail-app-password

# Razorpay Payment Gateway
RAZORPAY_KEY_ID=rzp_test_your_key_id_here
RAZORPAY_KEY_SECRET=your_razorpay_secret_here
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret_here
RAZORPAY_ACCOUNT_NUMBER=your_razorpay_x_account_number

# File Upload
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads

# KYC API Keys (Optional - for real KYC verification)
KYC_API_KEY=your_kyc_verification_api_key
KYC_BASE_URL=https://api.kycverification.com

# Admin Configuration
ADMIN_EMAIL=admin@p2plending.com
ADMIN_PASSWORD=secure_admin_password_123

# Platform Settings
PLATFORM_FEE_RATE=0.02
MIN_INVESTMENT=100
MAX_LOAN_AMOUNT=5000000
MIN_LOAN_AMOUNT=10000

# SMS Configuration (Optional)
SMS_API_KEY=your_sms_api_key
SMS_SENDER_ID=LENDCO
'''

with open('.env.example', 'w') as f:
    f.write(env_enhanced)

print("- .env.example (Enhanced with payment gateway variables)")