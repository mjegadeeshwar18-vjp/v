const { validationResult } = require('express-validator');

// Generic validation middleware
const validateRequest = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation error',
            errors: errors.array()
        });
    }
    next();
};

// File validation middleware
const validateFileUpload = (allowedTypes, maxSize = 5 * 1024 * 1024) => {
    return (req, res, next) => {
        if (!req.files || Object.keys(req.files).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'No files uploaded'
            });
        }

        for (const [key, files] of Object.entries(req.files)) {
            const fileArray = Array.isArray(files) ? files : [files];

            for (const file of fileArray) {
                // Check file size
                if (file.size > maxSize) {
                    return res.status(400).json({
                        success: false,
                        message: `File ${file.name} is too large. Maximum size is ${maxSize / (1024 * 1024)}MB`
                    });
                }

                // Check file type
                const fileExtension = file.name.split('.').pop().toLowerCase();
                if (!allowedTypes.includes(fileExtension)) {
                    return res.status(400).json({
                        success: false,
                        message: `File type ${fileExtension} is not allowed. Allowed types: ${allowedTypes.join(', ')}`
                    });
                }
            }
        }

        next();
    };
};

// Amount validation
const validateAmount = (field, min, max) => {
    return (req, res, next) => {
        const amount = parseFloat(req.body[field]);

        if (isNaN(amount)) {
            return res.status(400).json({
                success: false,
                message: `${field} must be a valid number`
            });
        }

        if (amount < min) {
            return res.status(400).json({
                success: false,
                message: `${field} must be at least ₹${min.toLocaleString()}`
            });
        }

        if (amount > max) {
            return res.status(400).json({
                success: false,
                message: `${field} cannot exceed ₹${max.toLocaleString()}`
            });
        }

        next();
    };
};

module.exports = {
    validateRequest,
    validateFileUpload,
    validateAmount
};
