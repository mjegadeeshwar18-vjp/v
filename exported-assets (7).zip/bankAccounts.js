const express = require('express');
const { body, validationResult } = require('express-validator');
const BankAccount = require('../models/BankAccount');
const { protect } = require('../middleware/auth');
const paymentService = require('../services/paymentService');

const router = express.Router();

// @desc    Add bank account
// @route   POST /api/bank-accounts
// @access  Private
router.post('/', protect, [
    body('accountNumber').matches(/^[0-9]{9,18}$/).withMessage('Please enter a valid account number'),
    body('ifscCode').matches(/^[A-Z]{4}0[A-Z0-9]{6}$/).withMessage('Please enter a valid IFSC code'),
    body('bankName').trim().notEmpty().withMessage('Bank name is required'),
    body('accountHolderName').trim().notEmpty().withMessage('Account holder name is required'),
    body('accountType').isIn(['savings', 'current']).withMessage('Account type must be savings or current')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { accountNumber, ifscCode, bankName, branchName, accountHolderName, accountType, isPrimary } = req.body;

        // Check if account already exists
        const existingAccount = await BankAccount.findOne({
            user: req.user.id,
            accountNumber
        });

        if (existingAccount) {
            return res.status(400).json({
                success: false,
                message: 'This bank account is already added'
            });
        }

        // Create bank account
        const bankAccount = await BankAccount.create({
            user: req.user.id,
            accountNumber,
            ifscCode,
            bankName,
            branchName,
            accountHolderName,
            accountType,
            isPrimary: isPrimary || false
        });

        // Verify bank account (optional - requires Razorpay X)
        if (process.env.RAZORPAY_KEY_ID) {
            const verificationResult = await paymentService.validateBankAccount(accountNumber, ifscCode);
            if (verificationResult.success) {
                bankAccount.isVerified = true;
                bankAccount.verificationDetails = {
                    method: 'razorpay',
                    date: new Date(),
                    status: 'success'
                };
                await bankAccount.save();
            }
        }

        res.status(201).json({
            success: true,
            data: bankAccount,
            message: 'Bank account added successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Get user bank accounts
// @route   GET /api/bank-accounts
// @access  Private
router.get('/', protect, async (req, res) => {
    try {
        const bankAccounts = await BankAccount.find({ user: req.user.id }).sort({ isPrimary: -1, createdAt: -1 });

        res.status(200).json({
            success: true,
            count: bankAccounts.length,
            data: bankAccounts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Update bank account
// @route   PUT /api/bank-accounts/:id
// @access  Private
router.put('/:id', protect, [
    body('bankName').optional().trim().notEmpty().withMessage('Bank name cannot be empty'),
    body('branchName').optional().trim(),
    body('accountHolderName').optional().trim().notEmpty().withMessage('Account holder name cannot be empty')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const bankAccount = await BankAccount.findOne({
            _id: req.params.id,
            user: req.user.id
        });

        if (!bankAccount) {
            return res.status(404).json({
                success: false,
                message: 'Bank account not found'
            });
        }

        const { bankName, branchName, accountHolderName, isPrimary } = req.body;

        if (bankName) bankAccount.bankName = bankName;
        if (branchName) bankAccount.branchName = branchName;
        if (accountHolderName) bankAccount.accountHolderName = accountHolderName;
        if (isPrimary !== undefined) bankAccount.isPrimary = isPrimary;

        await bankAccount.save();

        res.status(200).json({
            success: true,
            data: bankAccount,
            message: 'Bank account updated successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Delete bank account
// @route   DELETE /api/bank-accounts/:id
// @access  Private
router.delete('/:id', protect, async (req, res) => {
    try {
        const bankAccount = await BankAccount.findOne({
            _id: req.params.id,
            user: req.user.id
        });

        if (!bankAccount) {
            return res.status(404).json({
                success: false,
                message: 'Bank account not found'
            });
        }

        await bankAccount.remove();

        res.status(200).json({
            success: true,
            message: 'Bank account deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

module.exports = router;
