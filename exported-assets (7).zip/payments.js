const express = require('express');
const { body, validationResult } = require('express-validator');
const Loan = require('../models/Loan');
const Investment = require('../models/Investment');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const paymentService = require('../services/paymentService');
const notificationService = require('../services/notificationService');
const crypto = require('crypto');

const router = express.Router();

// @desc    Create payment order for EMI
// @route   POST /api/payments/create-emi-order
// @access  Private (Borrowers only)
router.post('/create-emi-order', protect, [
    body('loanId').isMongoId().withMessage('Invalid loan ID'),
    body('emiNumber').isInt({ min: 1 }).withMessage('Invalid EMI number')
], async (req, res) => {
    try {
        if (req.user.userType !== 'borrower') {
            return res.status(403).json({
                success: false,
                message: 'Only borrowers can create EMI payment orders'
            });
        }

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { loanId, emiNumber } = req.body;

        const loan = await Loan.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        if (loan.borrower.toString() !== req.user.id) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to pay for this loan'
            });
        }

        const emi = loan.repayments.find(r => r.emiNumber === emiNumber);
        if (!emi) {
            return res.status(404).json({
                success: false,
                message: 'EMI not found'
            });
        }

        if (emi.status === 'paid') {
            return res.status(400).json({
                success: false,
                message: 'EMI already paid'
            });
        }

        // Create Razorpay order
        const receipt = `emi_${loanId}_${emiNumber}_${Date.now()}`;
        const notes = {
            loan_id: loanId,
            emi_number: emiNumber,
            borrower_id: req.user.id,
            borrower_name: req.user.name,
            borrower_email: req.user.email
        };

        const result = await paymentService.createEMIPaymentOrder(
            emi.amount,
            'INR',
            receipt,
            notes
        );

        if (!result.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to create payment order',
                error: result.error
            });
        }

        // Store pending transaction
        await Transaction.create({
            user: req.user.id,
            loan: loanId,
            type: 'loan_repayment',
            amount: emi.amount,
            status: 'pending',
            paymentMethod: 'razorpay',
            paymentId: result.order.id,
            description: `EMI payment ${emiNumber} for loan ${loanId}`,
            metadata: new Map([
                ['razorpay_order_id', result.order.id],
                ['emi_number', emiNumber],
                ['receipt', receipt]
            ])
        });

        res.status(200).json({
            success: true,
            data: {
                order: result.order,
                key: process.env.RAZORPAY_KEY_ID,
                emi: emi,
                user: {
                    name: req.user.name,
                    email: req.user.email,
                    phone: req.user.phone
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Create payment order for investment
// @route   POST /api/payments/create-investment-order
// @access  Private (Lenders only)
router.post('/create-investment-order', protect, [
    body('loanId').isMongoId().withMessage('Invalid loan ID'),
    body('amount').isNumeric().custom(value => {
        if (value < 100) {
            throw new Error('Minimum investment amount is ₹100');
        }
        return true;
    })
], async (req, res) => {
    try {
        if (req.user.userType !== 'lender') {
            return res.status(403).json({
                success: false,
                message: 'Only lenders can create investment orders'
            });
        }

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { loanId, amount } = req.body;

        const loan = await Loan.findById(loanId).populate('borrower', 'name creditGrade');
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        if (!['approved', 'funding'].includes(loan.status)) {
            return res.status(400).json({
                success: false,
                message: 'This loan is not available for investment'
            });
        }

        if (amount > loan.remainingAmount) {
            return res.status(400).json({
                success: false,
                message: `Investment amount cannot exceed remaining loan amount of ₹${loan.remainingAmount}`
            });
        }

        // Create Razorpay order
        const receipt = `invest_${loanId}_${req.user.id}_${Date.now()}`;
        const notes = {
            loan_id: loanId,
            investor_id: req.user.id,
            investor_name: req.user.name,
            investor_email: req.user.email,
            borrower_name: loan.borrower.name,
            credit_grade: loan.creditGrade
        };

        const result = await paymentService.createInvestmentOrder(
            amount,
            'INR',
            receipt,
            notes
        );

        if (!result.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to create payment order',
                error: result.error
            });
        }

        await Transaction.create({
            user: req.user.id,
            loan: loanId,
            type: 'investment',
            amount: amount,
            status: 'pending',
            paymentMethod: 'razorpay',
            paymentId: result.order.id,
            description: `Investment in loan ${loanId}`,
            metadata: new Map([
                ['razorpay_order_id', result.order.id],
                ['receipt', receipt]
            ])
        });

        res.status(200).json({
            success: true,
            data: {
                order: result.order,
                key: process.env.RAZORPAY_KEY_ID,
                loan: {
                    id: loan._id,
                    borrower: loan.borrower.name,
                    creditGrade: loan.creditGrade,
                    interestRate: loan.interestRate
                },
                user: {
                    name: req.user.name,
                    email: req.user.email,
                    phone: req.user.phone
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Verify payment and complete transaction
// @route   POST /api/payments/verify
// @access  Private
router.post('/verify', protect, [
    body('razorpay_order_id').notEmpty().withMessage('Order ID is required'),
    body('razorpay_payment_id').notEmpty().withMessage('Payment ID is required'),
    body('razorpay_signature').notEmpty().withMessage('Signature is required')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

        // Verify signature
        const isValidSignature = paymentService.verifyPaymentSignature(
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature
        );

        if (!isValidSignature) {
            return res.status(400).json({
                success: false,
                message: 'Invalid payment signature'
            });
        }

        // Find transaction
        const transaction = await Transaction.findOne({
            paymentId: razorpay_order_id,
            user: req.user.id,
            status: 'pending'
        });

        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: 'Transaction not found'
            });
        }

        // Get payment details from Razorpay
        const paymentResult = await paymentService.getPaymentDetails(razorpay_payment_id);

        if (!paymentResult.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to verify payment details'
            });
        }

        const payment = paymentResult.payment;

        // Update transaction
        transaction.status = payment.status === 'captured' ? 'completed' : 'failed';
        transaction.metadata.set('razorpay_payment_id', razorpay_payment_id);
        transaction.metadata.set('payment_method', payment.method);
        await transaction.save();

        if (payment.status === 'captured') {
            // Process based on transaction type
            if (transaction.type === 'loan_repayment') {
                await processEMIPayment(transaction);
            } else if (transaction.type === 'investment') {
                await processInvestment(transaction);
            }

            // Send confirmation email
            await notificationService.sendPaymentConfirmation(req.user, transaction);

            res.status(200).json({
                success: true,
                message: 'Payment verified and processed successfully',
                data: {
                    transaction,
                    payment: {
                        id: payment.id,
                        amount: payment.amount / 100,
                        method: payment.method,
                        status: payment.status
                    }
                }
            });
        } else {
            res.status(400).json({
                success: false,
                message: 'Payment not captured'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// Helper function to process EMI payment
async function processEMIPayment(transaction) {
    const loan = await Loan.findById(transaction.loan);
    const emiNumber = transaction.metadata.get('emi_number');

    const emiIndex = loan.repayments.findIndex(r => r.emiNumber == emiNumber);
    if (emiIndex !== -1) {
        loan.repayments[emiIndex].status = 'paid';
        loan.repayments[emiIndex].paidDate = new Date();

        const allPaid = loan.repayments.every(r => r.status === 'paid');
        if (allPaid) {
            loan.status = 'completed';
            loan.completedAt = new Date();
        }

        await loan.save();
        await distributeReturns(loan, loan.repayments[emiIndex]);
    }
}

// Helper function to process investment
async function processInvestment(transaction) {
    const loan = await Loan.findById(transaction.loan);

    const investment = await Investment.create({
        investor: transaction.user,
        loan: transaction.loan,
        amount: transaction.amount,
        interestRate: loan.interestRate,
        expectedReturns: transaction.amount * (1 + (loan.interestRate / 100) * (loan.tenure / 12))
    });

    loan.investments.push({
        investor: transaction.user,
        amount: transaction.amount,
        date: new Date(),
        status: 'active'
    });

    loan.totalFunded += transaction.amount;
    loan.remainingAmount -= transaction.amount;

    if (loan.remainingAmount <= 0) {
        loan.status = 'active';
        loan.fundedAt = new Date();
        loan.repayments = loan.generateEMISchedule();
    } else if (loan.status === 'approved') {
        loan.status = 'funding';
    }

    await loan.save();
    transaction.investment = investment._id;
    await transaction.save();
}

// Helper function to distribute returns
async function distributeReturns(loan, emi) {
    const platformFeeRate = parseFloat(process.env.PLATFORM_FEE_RATE) || 0.02;

    for (const investment of loan.investments) {
        if (investment.status === 'active') {
            const investmentShare = investment.amount / loan.amount;
            const returnAmount = emi.amount * investmentShare;
            const platformFee = returnAmount * platformFeeRate;
            const netReturn = returnAmount - platformFee;

            const investmentDoc = await Investment.findOne({
                investor: investment.investor,
                loan: loan._id
            });

            if (investmentDoc) {
                investmentDoc.returns.push({
                    month: emi.emiNumber,
                    amount: netReturn,
                    principal: emi.principal * investmentShare,
                    interest: emi.interest * investmentShare,
                    receivedDate: new Date(),
                    status: 'received'
                });

                investmentDoc.totalReceived += netReturn;

                if (loan.status === 'completed') {
                    investmentDoc.status = 'completed';
                }

                await investmentDoc.save();

                // Create return transaction
                await Transaction.create({
                    user: investment.investor,
                    loan: loan._id,
                    investment: investmentDoc._id,
                    type: 'investment_return',
                    amount: netReturn,
                    status: 'completed',
                    paymentMethod: 'auto_credit',
                    description: `Return from loan ${loan._id} - EMI ${emi.emiNumber}`
                });
            }
        }
    }
}

// @desc    Razorpay webhook handler
// @route   POST /api/payments/webhook
// @access  Public
router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
    try {
        const signature = req.headers['x-razorpay-signature'];
        const body = req.body;

        const expectedSignature = crypto
            .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
            .update(body)
            .digest('hex');

        if (signature !== expectedSignature) {
            return res.status(400).json({ success: false, message: 'Invalid signature' });
        }

        const event = JSON.parse(body);

        switch (event.event) {
            case 'payment.captured':
                handlePaymentCaptured(event.payload.payment.entity);
                break;
            case 'payment.failed':
                handlePaymentFailed(event.payload.payment.entity);
                break;
            default:
                console.log('Unhandled webhook event:', event.event);
        }

        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Webhook error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

async function handlePaymentCaptured(payment) {
    console.log('Payment captured via webhook:', payment.id);
}

async function handlePaymentFailed(payment) {
    console.log('Payment failed via webhook:', payment.id);
    await Transaction.updateOne(
        { 'metadata.razorpay_payment_id': payment.id },
        { status: 'failed' }
    );
}

// @desc    Get payment methods
// @route   GET /api/payments/methods
// @access  Private
router.get('/methods', protect, (req, res) => {
    res.json({
        success: true,
        data: {
            upi: { name: 'UPI', enabled: true },
            netbanking: { name: 'Net Banking', enabled: true },
            card: { name: 'Credit/Debit Card', enabled: true },
            wallet: { name: 'Wallets', enabled: true }
        }
    });
});

// @desc    Get payment history
// @route   GET /api/payments/history
// @access  Private
router.get('/history', protect, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const transactions = await Transaction.find({ user: req.user.id })
            .populate('loan', 'amount purpose borrower')
            .populate('investment', 'amount expectedReturns')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);

        const total = await Transaction.countDocuments({ user: req.user.id });

        res.status(200).json({
            success: true,
            count: transactions.length,
            total,
            page,
            pages: Math.ceil(total / limit),
            data: transactions
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

module.exports = router;
