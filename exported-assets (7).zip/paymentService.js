const Razorpay = require('razorpay');
const crypto = require('crypto');
const axios = require('axios');

class PaymentService {
    constructor() {
        // Initialize Razorpay
        this.razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY_ID,
            key_secret: process.env.RAZORPAY_KEY_SECRET,
        });

        // Payment methods configuration
        this.paymentMethods = {
            UPI: 'upi',
            NET_BANKING: 'netbanking',
            CARD: 'card',
            WALLET: 'wallet',
            EMI: 'emi'
        };
    }

    /**
     * Create Razorpay order for EMI payment
     */
    async createEMIPaymentOrder(amount, currency = 'INR', receipt, notes = {}) {
        try {
            const options = {
                amount: amount * 100, // Amount in paisa
                currency,
                receipt,
                notes: {
                    ...notes,
                    payment_type: 'emi_payment',
                    platform: 'p2p_lending'
                }
            };

            const order = await this.razorpay.orders.create(options);
            return {
                success: true,
                order
            };
        } catch (error) {
            console.error('Error creating EMI payment order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create Razorpay order for investment
     */
    async createInvestmentOrder(amount, currency = 'INR', receipt, notes = {}) {
        try {
            const options = {
                amount: amount * 100, // Amount in paisa
                currency,
                receipt,
                notes: {
                    ...notes,
                    payment_type: 'investment',
                    platform: 'p2p_lending'
                }
            };

            const order = await this.razorpay.orders.create(options);
            return {
                success: true,
                order
            };
        } catch (error) {
            console.error('Error creating investment order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Verify payment signature from Razorpay
     */
    verifyPaymentSignature(razorpay_order_id, razorpay_payment_id, razorpay_signature) {
        try {
            const sign = razorpay_order_id + "|" + razorpay_payment_id;
            const expectedSign = crypto
                .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
                .update(sign.toString())
                .digest("hex");

            return razorpay_signature === expectedSign;
        } catch (error) {
            console.error('Error verifying payment signature:', error);
            return false;
        }
    }

    /**
     * Get payment details from Razorpay
     */
    async getPaymentDetails(paymentId) {
        try {
            const payment = await this.razorpay.payments.fetch(paymentId);
            return {
                success: true,
                payment
            };
        } catch (error) {
            console.error('Error fetching payment details:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Process refund
     */
    async processRefund(paymentId, amount, reason = 'Normal refund') {
        try {
            const refund = await this.razorpay.payments.refund(paymentId, {
                amount: amount * 100, // Amount in paisa
                reason,
                receipt: `refund_${Date.now()}`
            });

            return {
                success: true,
                refund
            };
        } catch (error) {
            console.error('Error processing refund:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create payout for investor returns (requires Razorpay X)
     */
    async createPayout(amount, accountNumber, ifsc, purpose = 'investment_returns') {
        try {
            const payout = await axios.post('https://api.razorpay.com/v1/payouts', {
                account_number: process.env.RAZORPAY_ACCOUNT_NUMBER,
                amount: amount * 100,
                currency: 'INR',
                mode: 'NEFT',
                purpose,
                fund_account: {
                    account_type: 'bank_account',
                    bank_account: {
                        account_number: accountNumber,
                        ifsc
                    },
                    contact: {
                        name: 'Investor',
                        type: 'customer'
                    }
                },
                queue_if_low_balance: true,
                reference_id: `payout_${Date.now()}`
            }, {
                auth: {
                    username: process.env.RAZORPAY_KEY_ID,
                    password: process.env.RAZORPAY_KEY_SECRET
                }
            });

            return {
                success: true,
                payout: payout.data
            };
        } catch (error) {
            console.error('Error creating payout:', error);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }

    /**
     * Generate payment link for EMI
     */
    async generatePaymentLink(amount, description, customerInfo, dueDate) {
        try {
            const paymentLink = await this.razorpay.paymentLink.create({
                amount: amount * 100,
                currency: 'INR',
                description,
                customer: {
                    name: customerInfo.name,
                    email: customerInfo.email,
                    contact: customerInfo.phone
                },
                notify: {
                    sms: true,
                    email: true
                },
                reminder_enable: true,
                callback_url: `${process.env.FRONTEND_URL}/payment-callback`,
                callback_method: 'get',
                expire_by: Math.floor(new Date(dueDate).getTime() / 1000)
            });

            return {
                success: true,
                paymentLink
            };
        } catch (error) {
            console.error('Error generating payment link:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Check payment status
     */
    async checkPaymentStatus(orderId) {
        try {
            const order = await this.razorpay.orders.fetch(orderId);
            const payments = await this.razorpay.orders.fetchPayments(orderId);

            return {
                success: true,
                order,
                payments: payments.items
            };
        } catch (error) {
            console.error('Error checking payment status:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
}

module.exports = new PaymentService();
