const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Import models
const User = require('../models/User');
const Loan = require('../models/Loan');
const connectDB = require('../config/database');

// Sample data
const sampleUsers = [
    {
        name: 'Admin User',
        email: 'admin@p2plending.com',
        phone: '9876543210',
        password: 'admin123',
        userType: 'admin',
        kycStatus: 'approved',
        isActive: true,
        emailVerified: true,
        phoneVerified: true
    },
    {
        name: 'Rajesh Kumar',
        email: 'rajesh@example.com',
        phone: '9876543211',
        password: 'password123',
        userType: 'borrower',
        kycStatus: 'approved',
        creditGrade: 'A',
        personalInfo: {
            monthlyIncome: 75000,
            occupation: 'Software Engineer',
            maritalStatus: 'married'
        }
    },
    {
        name: 'Priya Sharma',
        email: 'priya@example.com',
        phone: '9876543212',
        password: 'password123',
        userType: 'borrower',
        kycStatus: 'approved',
        creditGrade: 'B',
        personalInfo: {
            monthlyIncome: 45000,
            occupation: 'Teacher',
            maritalStatus: 'single'
        }
    },
    {
        name: 'Amit Patel',
        email: 'amit@example.com',
        phone: '9876543213',
        password: 'password123',
        userType: 'lender',
        kycStatus: 'approved',
        personalInfo: {
            monthlyIncome: 120000,
            occupation: 'Business Owner'
        }
    },
    {
        name: 'Sunita Verma',
        email: 'sunita@example.com',
        phone: '9876543214',
        password: 'password123',
        userType: 'lender',
        kycStatus: 'approved',
        personalInfo: {
            monthlyIncome: 85000,
            occupation: 'Doctor'
        }
    }
];

const seedData = async () => {
    try {
        await connectDB();

        // Clear existing data
        console.log('Clearing existing data...');
        await User.deleteMany({});
        await Loan.deleteMany({});

        // Create users
        console.log('Creating users...');
        const createdUsers = await User.create(sampleUsers);
        console.log(`Created ${createdUsers.length} users`);

        // Find borrowers for loan creation
        const borrowers = createdUsers.filter(user => user.userType === 'borrower');

        // Create sample loans
        const sampleLoans = [
            {
                borrower: borrowers[0]._id,
                amount: 500000,
                purpose: 'Business Expansion',
                tenure: 24,
                interestRate: 12,
                emi: 23537,
                creditGrade: 'A',
                status: 'approved',
                description: 'Need funds to expand my software consultancy business'
            },
            {
                borrower: borrowers[1]._id,
                amount: 200000,
                purpose: 'Education',
                tenure: 36,
                interestRate: 10,
                emi: 6450,
                creditGrade: 'B',
                status: 'funding',
                totalFunded: 50000,
                remainingAmount: 150000,
                description: 'Higher education course fees'
            }
        ];

        console.log('Creating loans...');
        const createdLoans = await Loan.create(sampleLoans);
        console.log(`Created ${createdLoans.length} loans`);

        console.log('\n=== Sample Data Created Successfully ===');
        console.log('\nLogin Credentials:');
        console.log('Admin: admin@p2plending.com / admin123');
        console.log('Borrower 1: rajesh@example.com / password123');
        console.log('Borrower 2: priya@example.com / password123');
        console.log('Lender 1: amit@example.com / password123');
        console.log('Lender 2: sunita@example.com / password123');

        process.exit(0);
    } catch (error) {
        console.error('Error seeding data:', error);
        process.exit(1);
    }
};

// Run if called directly
if (require.main === module) {
    seedData();
}

module.exports = seedData;
