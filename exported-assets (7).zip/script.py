# Create enhanced payment integration with real payment gateways

# Enhanced package.json with payment gateway dependencies
package_json_enhanced = {
    "name": "p2p-lending-backend",
    "version": "1.0.0",
    "description": "P2P Lending Platform Backend API with Real Payment Integration",
    "main": "server.js",
    "scripts": {
        "start": "node server.js",
        "dev": "nodemon server.js",
        "seed": "node utils/seedData.js"
    },
    "keywords": ["p2p", "lending", "nodejs", "mongodb", "razorpay", "payments"],
    "author": "Vallavan Jegadeeshwar Pazhaniponmanikkavel Vishwa",
    "license": "MIT",
    "dependencies": {
        "express": "^4.18.2",
        "mongoose": "^7.5.0",
        "cors": "^2.8.5",
        "dotenv": "^16.3.1",
        "bcryptjs": "^2.4.3",
        "jsonwebtoken": "^9.0.2",
        "multer": "^1.4.5",
        "nodemailer": "^6.9.4",
        "express-rate-limit": "^6.10.0",
        "helmet": "^7.0.0",
        "express-validator": "^7.0.1",
        "razorpay": "^2.9.2",
        "crypto": "^1.0.1",
        "axios": "^1.5.0",
        "moment": "^2.29.4",
        "node-cron": "^3.0.2",
        "winston": "^3.10.0"
    },
    "devDependencies": {
        "nodemon": "^3.0.1"
    },
    "engines": {
        "node": ">=14.0.0"
    }
}

import json
with open('package.json', 'w') as f:
    json.dump(package_json_enhanced, f, indent=2)

print("Enhanced package.json with payment gateway dependencies")

# Create enhanced payment service
payment_service = '''const Razorpay = require('razorpay');
const crypto = require('crypto');
const axios = require('axios');

class PaymentService {
    constructor() {
        // Initialize Razorpay
        this.razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY_ID,
            key_secret: process.env.RAZORPAY_KEY_SECRET,
        });
        
        // Payment methods configuration
        this.paymentMethods = {
            UPI: 'upi',
            NET_BANKING: 'netbanking',
            CARD: 'card',
            WALLET: 'wallet',
            EMI: 'emi'
        };
    }

    /**
     * Create Razorpay order for EMI payment
     */
    async createEMIPaymentOrder(amount, currency = 'INR', receipt, notes = {}) {
        try {
            const options = {
                amount: amount * 100, // Amount in paisa
                currency,
                receipt,
                notes: {
                    ...notes,
                    payment_type: 'emi_payment',
                    platform: 'p2p_lending'
                }
            };

            const order = await this.razorpay.orders.create(options);
            return {
                success: true,
                order
            };
        } catch (error) {
            console.error('Error creating EMI payment order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create Razorpay order for investment
     */
    async createInvestmentOrder(amount, currency = 'INR', receipt, notes = {}) {
        try {
            const options = {
                amount: amount * 100, // Amount in paisa
                currency,
                receipt,
                notes: {
                    ...notes,
                    payment_type: 'investment',
                    platform: 'p2p_lending'
                }
            };

            const order = await this.razorpay.orders.create(options);
            return {
                success: true,
                order
            };
        } catch (error) {
            console.error('Error creating investment order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Verify payment signature from Razorpay
     */
    verifyPaymentSignature(razorpay_order_id, razorpay_payment_id, razorpay_signature) {
        try {
            const sign = razorpay_order_id + "|" + razorpay_payment_id;
            const expectedSign = crypto
                .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
                .update(sign.toString())
                .digest("hex");

            return razorpay_signature === expectedSign;
        } catch (error) {
            console.error('Error verifying payment signature:', error);
            return false;
        }
    }

    /**
     * Get payment details from Razorpay
     */
    async getPaymentDetails(paymentId) {
        try {
            const payment = await this.razorpay.payments.fetch(paymentId);
            return {
                success: true,
                payment
            };
        } catch (error) {
            console.error('Error fetching payment details:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Process refund
     */
    async processRefund(paymentId, amount, reason = 'Normal refund') {
        try {
            const refund = await this.razorpay.payments.refund(paymentId, {
                amount: amount * 100, // Amount in paisa
                reason,
                receipt: `refund_${Date.now()}`
            });

            return {
                success: true,
                refund
            };
        } catch (error) {
            console.error('Error processing refund:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create payout for investor returns
     */
    async createPayout(amount, accountNumber, ifsc, purpose = 'investment_returns') {
        try {
            // Note: This requires Razorpay X (business banking) account
            const payout = await axios.post('https://api.razorpay.com/v1/payouts', {
                account_number: process.env.RAZORPAY_ACCOUNT_NUMBER,
                amount: amount * 100,
                currency: 'INR',
                mode: 'NEFT',
                purpose,
                fund_account: {
                    account_type: 'bank_account',
                    bank_account: {
                        account_number: accountNumber,
                        ifsc
                    },
                    contact: {
                        name: 'Investor',
                        type: 'customer'
                    }
                },
                queue_if_low_balance: true,
                reference_id: `payout_${Date.now()}`
            }, {
                auth: {
                    username: process.env.RAZORPAY_KEY_ID,
                    password: process.env.RAZORPAY_KEY_SECRET
                }
            });

            return {
                success: true,
                payout: payout.data
            };
        } catch (error) {
            console.error('Error creating payout:', error);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }

    /**
     * Validate bank account for payouts
     */
    async validateBankAccount(accountNumber, ifsc) {
        try {
            const response = await axios.post('https://api.razorpay.com/v1/fund_accounts/validations', {
                account_number: accountNumber,
                fund_account: {
                    account_type: 'bank_account',
                    bank_account: {
                        account_number: accountNumber,
                        ifsc
                    }
                },
                amount: 100, // Rs 1.00 for validation
                currency: 'INR',
                receipt: `validation_${Date.now()}`
            }, {
                auth: {
                    username: process.env.RAZORPAY_KEY_ID,
                    password: process.env.RAZORPAY_KEY_SECRET
                }
            });

            return {
                success: true,
                validation: response.data
            };
        } catch (error) {
            console.error('Error validating bank account:', error);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }

    /**
     * Check payment status
     */
    async checkPaymentStatus(orderId) {
        try {
            const order = await this.razorpay.orders.fetch(orderId);
            const payments = await this.razorpay.orders.fetchPayments(orderId);
            
            return {
                success: true,
                order,
                payments: payments.items
            };
        } catch (error) {
            console.error('Error checking payment status:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Generate payment link for EMI
     */
    async generatePaymentLink(amount, description, customerInfo, dueDate) {
        try {
            const paymentLink = await this.razorpay.paymentLink.create({
                amount: amount * 100,
                currency: 'INR',
                description,
                customer: {
                    name: customerInfo.name,
                    email: customerInfo.email,
                    contact: customerInfo.phone
                },
                notify: {
                    sms: true,
                    email: true
                },
                reminder_enable: true,
                callback_url: `${process.env.FRONTEND_URL}/payment-callback`,
                callback_method: 'get',
                expire_by: Math.floor(new Date(dueDate).getTime() / 1000) // Unix timestamp
            });

            return {
                success: true,
                paymentLink
            };
        } catch (error) {
            console.error('Error generating payment link:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Process recurring payment setup
     */
    async setupRecurringPayment(customerId, amount, startDate, frequency = 'monthly') {
        try {
            const subscription = await this.razorpay.subscriptions.create({
                plan_id: process.env.RAZORPAY_PLAN_ID, // Create plans in Razorpay dashboard
                customer_id: customerId,
                quantity: 1,
                total_count: 12, // 12 months
                start_at: Math.floor(new Date(startDate).getTime() / 1000),
                addons: [{
                    item: {
                        name: 'EMI Payment',
                        amount: amount * 100,
                        currency: 'INR'
                    }
                }]
            });

            return {
                success: true,
                subscription
            };
        } catch (error) {
            console.error('Error setting up recurring payment:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
}

module.exports = new PaymentService();
'''

with open('services/paymentService.js', 'w') as f:
    f.write(payment_service)

print("Created services/paymentService.js with real payment integration")

# Create enhanced payments routes with real gateway
payments_enhanced = '''const express = require('express');
const { body, validationResult } = require('express-validator');
const Loan = require('../models/Loan');
const Investment = require('../models/Investment');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const paymentService = require('../services/paymentService');
const crypto = require('crypto');

const router = express.Router();

// @desc    Create payment order for EMI
// @route   POST /api/payments/create-emi-order
// @access  Private (Borrowers only)
router.post('/create-emi-order', protect, [
    body('loanId').isMongoId().withMessage('Invalid loan ID'),
    body('emiNumber').isInt({ min: 1 }).withMessage('Invalid EMI number')
], async (req, res) => {
    try {
        if (req.user.userType !== 'borrower') {
            return res.status(403).json({
                success: false,
                message: 'Only borrowers can create EMI payment orders'
            });
        }

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { loanId, emiNumber } = req.body;

        const loan = await Loan.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        // Check if user owns this loan
        if (loan.borrower.toString() !== req.user.id) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to pay for this loan'
            });
        }

        // Find the EMI
        const emi = loan.repayments.find(r => r.emiNumber === emiNumber);
        if (!emi) {
            return res.status(404).json({
                success: false,
                message: 'EMI not found'
            });
        }

        if (emi.status === 'paid') {
            return res.status(400).json({
                success: false,
                message: 'EMI already paid'
            });
        }

        // Create Razorpay order
        const receipt = `emi_${loanId}_${emiNumber}_${Date.now()}`;
        const notes = {
            loan_id: loanId,
            emi_number: emiNumber,
            borrower_id: req.user.id,
            borrower_name: req.user.name,
            borrower_email: req.user.email
        };

        const result = await paymentService.createEMIPaymentOrder(
            emi.amount,
            'INR',
            receipt,
            notes
        );

        if (!result.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to create payment order',
                error: result.error
            });
        }

        // Store pending transaction
        await Transaction.create({
            user: req.user.id,
            loan: loanId,
            type: 'loan_repayment',
            amount: emi.amount,
            status: 'pending',
            paymentMethod: 'razorpay',
            paymentId: result.order.id,
            description: `EMI payment ${emiNumber} for loan ${loanId}`,
            metadata: new Map([
                ['razorpay_order_id', result.order.id],
                ['emi_number', emiNumber],
                ['receipt', receipt]
            ])
        });

        res.status(200).json({
            success: true,
            data: {
                order: result.order,
                key: process.env.RAZORPAY_KEY_ID,
                emi: emi,
                user: {
                    name: req.user.name,
                    email: req.user.email,
                    phone: req.user.phone
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Create payment order for investment
// @route   POST /api/payments/create-investment-order
// @access  Private (Lenders only)
router.post('/create-investment-order', protect, [
    body('loanId').isMongoId().withMessage('Invalid loan ID'),
    body('amount').isNumeric().custom(value => {
        if (value < 100) {
            throw new Error('Minimum investment amount is ₹100');
        }
        return true;
    })
], async (req, res) => {
    try {
        if (req.user.userType !== 'lender') {
            return res.status(403).json({
                success: false,
                message: 'Only lenders can create investment orders'
            });
        }

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { loanId, amount } = req.body;

        const loan = await Loan.findById(loanId).populate('borrower', 'name creditGrade');
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        if (!['approved', 'funding'].includes(loan.status)) {
            return res.status(400).json({
                success: false,
                message: 'This loan is not available for investment'
            });
        }

        if (amount > loan.remainingAmount) {
            return res.status(400).json({
                success: false,
                message: `Investment amount cannot exceed remaining loan amount of ₹${loan.remainingAmount}`
            });
        }

        // Create Razorpay order
        const receipt = `invest_${loanId}_${req.user.id}_${Date.now()}`;
        const notes = {
            loan_id: loanId,
            investor_id: req.user.id,
            investor_name: req.user.name,
            investor_email: req.user.email,
            borrower_name: loan.borrower.name,
            credit_grade: loan.creditGrade
        };

        const result = await paymentService.createInvestmentOrder(
            amount,
            'INR',
            receipt,
            notes
        );

        if (!result.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to create payment order',
                error: result.error
            });
        }

        // Store pending transaction
        await Transaction.create({
            user: req.user.id,
            loan: loanId,
            type: 'investment',
            amount: amount,
            status: 'pending',
            paymentMethod: 'razorpay',
            paymentId: result.order.id,
            description: `Investment in loan ${loanId}`,
            metadata: new Map([
                ['razorpay_order_id', result.order.id],
                ['receipt', receipt]
            ])
        });

        res.status(200).json({
            success: true,
            data: {
                order: result.order,
                key: process.env.RAZORPAY_KEY_ID,
                loan: {
                    id: loan._id,
                    borrower: loan.borrower.name,
                    creditGrade: loan.creditGrade,
                    interestRate: loan.interestRate
                },
                user: {
                    name: req.user.name,
                    email: req.user.email,
                    phone: req.user.phone
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Verify payment and complete transaction
// @route   POST /api/payments/verify
// @access  Private
router.post('/verify', protect, [
    body('razorpay_order_id').notEmpty().withMessage('Order ID is required'),
    body('razorpay_payment_id').notEmpty().withMessage('Payment ID is required'),
    body('razorpay_signature').notEmpty().withMessage('Signature is required')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors: errors.array()
            });
        }

        const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

        // Verify signature
        const isValidSignature = paymentService.verifyPaymentSignature(
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature
        );

        if (!isValidSignature) {
            return res.status(400).json({
                success: false,
                message: 'Invalid payment signature'
            });
        }

        // Find transaction
        const transaction = await Transaction.findOne({
            paymentId: razorpay_order_id,
            user: req.user.id,
            status: 'pending'
        });

        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: 'Transaction not found'
            });
        }

        // Get payment details from Razorpay
        const paymentResult = await paymentService.getPaymentDetails(razorpay_payment_id);
        
        if (!paymentResult.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to verify payment details'
            });
        }

        const payment = paymentResult.payment;

        // Update transaction
        transaction.status = payment.status === 'captured' ? 'completed' : 'failed';
        transaction.metadata.set('razorpay_payment_id', razorpay_payment_id);
        transaction.metadata.set('payment_method', payment.method);
        transaction.metadata.set('payment_details', JSON.stringify(payment));
        await transaction.save();

        if (payment.status === 'captured') {
            // Process based on transaction type
            if (transaction.type === 'loan_repayment') {
                await processEMIPayment(transaction);
            } else if (transaction.type === 'investment') {
                await processInvestment(transaction);
            }

            res.status(200).json({
                success: true,
                message: 'Payment verified and processed successfully',
                data: {
                    transaction,
                    payment: {
                        id: payment.id,
                        amount: payment.amount / 100,
                        method: payment.method,
                        status: payment.status
                    }
                }
            });
        } else {
            res.status(400).json({
                success: false,
                message: 'Payment not captured',
                data: payment
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// Helper function to process EMI payment
async function processEMIPayment(transaction) {
    const loan = await Loan.findById(transaction.loan);
    const emiNumber = transaction.metadata.get('emi_number');
    
    // Update EMI status
    const emiIndex = loan.repayments.findIndex(r => r.emiNumber == emiNumber);
    if (emiIndex !== -1) {
        loan.repayments[emiIndex].status = 'paid';
        loan.repayments[emiIndex].paidDate = new Date();

        // Check if loan is completed
        const allPaid = loan.repayments.every(r => r.status === 'paid');
        if (allPaid) {
            loan.status = 'completed';
            loan.completedAt = new Date();
        }

        await loan.save();

        // Distribute returns to investors
        await distributeReturns(loan, loan.repayments[emiIndex]);
    }
}

// Helper function to process investment
async function processInvestment(transaction) {
    const loan = await Loan.findById(transaction.loan);
    
    // Create investment record
    const investment = await Investment.create({
        investor: transaction.user,
        loan: transaction.loan,
        amount: transaction.amount,
        interestRate: loan.interestRate,
        expectedReturns: transaction.amount * (1 + (loan.interestRate / 100) * (loan.tenure / 12))
    });

    // Update loan
    loan.investments.push({
        investor: transaction.user,
        amount: transaction.amount,
        date: new Date(),
        status: 'active'
    });

    loan.totalFunded += transaction.amount;
    loan.remainingAmount -= transaction.amount;

    if (loan.remainingAmount <= 0) {
        loan.status = 'active';
        loan.fundedAt = new Date();
        loan.repayments = loan.generateEMISchedule();
    } else if (loan.status === 'approved') {
        loan.status = 'funding';
    }

    await loan.save();

    // Update transaction with investment reference
    transaction.investment = investment._id;
    await transaction.save();
}

// Helper function to distribute returns
async function distributeReturns(loan, emi) {
    const platformFeeRate = 0.02; // 2% platform fee
    
    for (const investment of loan.investments) {
        if (investment.status === 'active') {
            const investmentShare = investment.amount / loan.amount;
            const returnAmount = emi.amount * investmentShare;
            const platformFee = returnAmount * platformFeeRate;
            const netReturn = returnAmount - platformFee;

            // Update investment returns
            const investmentDoc = await Investment.findOne({
                investor: investment.investor,
                loan: loan._id
            });

            if (investmentDoc) {
                investmentDoc.returns.push({
                    month: emi.emiNumber,
                    amount: netReturn,
                    principal: emi.principal * investmentShare,
                    interest: emi.interest * investmentShare,
                    receivedDate: new Date(),
                    status: 'received'
                });

                investmentDoc.totalReceived += netReturn;
                
                if (loan.status === 'completed') {
                    investmentDoc.status = 'completed';
                }

                await investmentDoc.save();

                // Create return transaction
                await Transaction.create({
                    user: investment.investor,
                    loan: loan._id,
                    investment: investmentDoc._id,
                    type: 'investment_return',
                    amount: netReturn,
                    status: 'completed',
                    paymentMethod: 'auto_credit',
                    description: `Return from loan ${loan._id} - EMI ${emi.emiNumber}`
                });
            }
        }
    }
}

// @desc    Webhook for Razorpay events
// @route   POST /api/payments/webhook
// @access  Public (Razorpay webhook)
router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
    try {
        const signature = req.headers['x-razorpay-signature'];
        const body = req.body;

        // Verify webhook signature
        const expectedSignature = crypto
            .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
            .update(body)
            .digest('hex');

        if (signature !== expectedSignature) {
            return res.status(400).json({ success: false, message: 'Invalid signature' });
        }

        const event = JSON.parse(body);
        
        // Handle different event types
        switch (event.event) {
            case 'payment.captured':
                handlePaymentCaptured(event.payload.payment.entity);
                break;
            case 'payment.failed':
                handlePaymentFailed(event.payload.payment.entity);
                break;
            case 'order.paid':
                handleOrderPaid(event.payload.order.entity);
                break;
            default:
                console.log('Unhandled webhook event:', event.event);
        }

        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Webhook error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

async function handlePaymentCaptured(payment) {
    console.log('Payment captured:', payment.id);
    // Additional processing if needed
}

async function handlePaymentFailed(payment) {
    console.log('Payment failed:', payment.id);
    
    // Update transaction status
    await Transaction.updateOne(
        { 'metadata.razorpay_payment_id': payment.id },
        { status: 'failed' }
    );
}

async function handleOrderPaid(order) {
    console.log('Order paid:', order.id);
    // Additional processing if needed
}

// @desc    Get payment history with detailed info
// @route   GET /api/payments/history
// @access  Private
router.get('/history', protect, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const transactions = await Transaction.find({ user: req.user.id })
            .populate('loan', 'amount purpose borrower')
            .populate('investment', 'amount expectedReturns')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);

        const total = await Transaction.countDocuments({ user: req.user.id });

        // Calculate totals
        const totals = await Transaction.aggregate([
            { $match: { user: req.user._id } },
            {
                $group: {
                    _id: '$type',
                    totalAmount: { $sum: '$amount' },
                    count: { $sum: 1 }
                }
            }
        ]);

        res.status(200).json({
            success: true,
            count: transactions.length,
            total,
            page,
            pages: Math.ceil(total / limit),
            data: transactions,
            totals
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @desc    Generate payment link for EMI
// @route   POST /api/payments/generate-link
// @access  Private (Borrowers only)
router.post('/generate-link', protect, [
    body('loanId').isMongoId().withMessage('Invalid loan ID'),
    body('emiNumber').isInt({ min: 1 }).withMessage('Invalid EMI number')
], async (req, res) => {
    try {
        if (req.user.userType !== 'borrower') {
            return res.status(403).json({
                success: false,
                message: 'Only borrowers can generate payment links'
            });
        }

        const { loanId, emiNumber } = req.body;

        const loan = await Loan.findById(loanId);
        if (!loan || loan.borrower.toString() !== req.user.id) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found or access denied'
            });
        }

        const emi = loan.repayments.find(r => r.emiNumber === emiNumber);
        if (!emi || emi.status === 'paid') {
            return res.status(400).json({
                success: false,
                message: 'EMI not found or already paid'
            });
        }

        const result = await paymentService.generatePaymentLink(
            emi.amount,
            `EMI ${emiNumber} payment for loan ${loanId}`,
            {
                name: req.user.name,
                email: req.user.email,
                phone: req.user.phone
            },
            emi.dueDate
        );

        if (!result.success) {
            return res.status(500).json({
                success: false,
                message: 'Failed to generate payment link',
                error: result.error
            });
        }

        res.status(200).json({
            success: true,
            data: result.paymentLink
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

module.exports = router;
'''

with open('routes/payments.js', 'w') as f:
    f.write(payments_enhanced)

print("Enhanced routes/payments.js with real Razorpay integration")

# Create services directory
import os
os.makedirs('services', exist_ok=True)

# Create notification service
notification_service = '''const nodemailer = require('nodemailer');

class NotificationService {
    constructor() {
        this.transporter = nodemailer.createTransporter({
            host: process.env.EMAIL_HOST || 'smtp.gmail.com',
            port: process.env.EMAIL_PORT || 587,
            secure: false,
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });
    }

    /**
     * Send EMI reminder email
     */
    async sendEMIReminder(user, loan, emi) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: `EMI Reminder - Due Date: ${new Date(emi.dueDate).toLocaleDateString()}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #2563eb;">EMI Payment Reminder</h2>
                    <p>Dear ${user.name},</p>
                    <p>This is a reminder that your EMI payment is due soon.</p>
                    <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Payment Details:</h3>
                        <p><strong>Loan ID:</strong> ${loan._id}</p>
                        <p><strong>EMI Number:</strong> ${emi.emiNumber}</p>
                        <p><strong>Amount:</strong> ₹${emi.amount.toLocaleString()}</p>
                        <p><strong>Due Date:</strong> ${new Date(emi.dueDate).toLocaleDateString()}</p>
                    </div>
                    <a href="${process.env.FRONTEND_URL}/dashboard" 
                       style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                       Pay Now
                    </a>
                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        Please ensure timely payment to avoid late fees and maintain your credit score.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending EMI reminder:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send payment confirmation email
     */
    async sendPaymentConfirmation(user, transaction) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: 'Payment Confirmation',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">Payment Confirmed</h2>
                    <p>Dear ${user.name},</p>
                    <p>Your payment has been successfully processed.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
                        <h3>Transaction Details:</h3>
                        <p><strong>Transaction ID:</strong> ${transaction._id}</p>
                        <p><strong>Amount:</strong> ₹${transaction.amount.toLocaleString()}</p>
                        <p><strong>Type:</strong> ${transaction.type.replace('_', ' ').toUpperCase()}</p>
                        <p><strong>Date:</strong> ${new Date(transaction.createdAt).toLocaleString()}</p>
                        <p><strong>Payment Method:</strong> ${transaction.paymentMethod.toUpperCase()}</p>
                    </div>
                    <p style="color: #64748b; font-size: 14px;">
                        Thank you for using our platform. Keep this email for your records.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending payment confirmation:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send investment opportunity notification
     */
    async sendInvestmentOpportunity(lender, loan) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: lender.email,
            subject: 'New Investment Opportunity Available',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #2563eb;">New Investment Opportunity</h2>
                    <p>Dear ${lender.name},</p>
                    <p>A new loan matching your investment criteria is now available for funding.</p>
                    <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Loan Details:</h3>
                        <p><strong>Amount:</strong> ₹${loan.amount.toLocaleString()}</p>
                        <p><strong>Interest Rate:</strong> ${loan.interestRate}% per annum</p>
                        <p><strong>Tenure:</strong> ${loan.tenure} months</p>
                        <p><strong>Purpose:</strong> ${loan.purpose}</p>
                        <p><strong>Credit Grade:</strong> ${loan.creditGrade}</p>
                        <p><strong>EMI:</strong> ₹${loan.emi.toLocaleString()}</p>
                    </div>
                    <a href="${process.env.FRONTEND_URL}/loans/${loan._id}" 
                       style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                       View Details & Invest
                    </a>
                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        Invest with a minimum amount of ₹100. Diversify your investment portfolio with P2P lending.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending investment notification:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send loan approval notification
     */
    async sendLoanApproval(borrower, loan) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: borrower.email,
            subject: 'Loan Application Approved',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">Congratulations! Your Loan is Approved</h2>
                    <p>Dear ${borrower.name},</p>
                    <p>We're pleased to inform you that your loan application has been approved and is now available for funding.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
                        <h3>Loan Details:</h3>
                        <p><strong>Loan Amount:</strong> ₹${loan.amount.toLocaleString()}</p>
                        <p><strong>Interest Rate:</strong> ${loan.interestRate}% per annum</p>
                        <p><strong>Tenure:</strong> ${loan.tenure} months</p>
                        <p><strong>EMI:</strong> ₹${loan.emi.toLocaleString()}</p>
                        <p><strong>Credit Grade:</strong> ${loan.creditGrade}</p>
                    </div>
                    <a href="${process.env.FRONTEND_URL}/dashboard" 
                       style="background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                       View Dashboard
                    </a>
                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        Your loan will now be available to lenders for investment. Once fully funded, the amount will be disbursed to your account.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending loan approval notification:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send KYC approval notification
     */
    async sendKYCApproval(user) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: 'KYC Verification Completed',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">KYC Verification Successful</h2>
                    <p>Dear ${user.name},</p>
                    <p>Your KYC verification has been completed successfully. You can now access all platform features.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
                        <h3>You can now:</h3>
                        <ul>
                            ${user.userType === 'borrower' ? 
                                '<li>Apply for loans up to ₹50,00,000</li><li>Manage your EMI payments</li>' : 
                                '<li>Invest in loans starting from ₹100</li><li>Track your investment returns</li>'
                            }
                            <li>Access your complete dashboard</li>
                            <li>Update your profile information</li>
                        </ul>
                    </div>
                    <a href="${process.env.FRONTEND_URL}/dashboard" 
                       style="background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                       Access Dashboard
                    </a>
                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        Welcome to our P2P lending platform. Start your financial journey with us today!
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending KYC approval notification:', error);
            return { success: false, error: error.message };
        }
    }
}

module.exports = new NotificationService();
'''

with open('services/notificationService.js', 'w') as f:
    f.write(notification_service)

print("Created services/notificationService.js for email notifications")