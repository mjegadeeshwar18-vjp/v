// API Service for LendConnect

class ApiService {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        this.endpoints = API_CONFIG.ENDPOINTS;
    }

    /**
     * Make HTTP request with authentication
     */
    async request(url, options = {}) {
        const token = Token.get();

        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        // Add authentication header if token exists
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        // Convert body to JSON if it's an object
        if (config.body && typeof config.body === 'object' && !(config.body instanceof FormData)) {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(`${this.baseURL}${url}`, config);

            // Handle token expiration
            if (response.status === 401) {
                Token.remove();
                User.remove();
                window.location.href = '/';
                return;
            }

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('API Request failed:', error);
            throw error;
        }
    }

    /**
     * GET request
     */
    async get(url, params = {}) {
        const searchParams = new URLSearchParams(params);
        const queryString = searchParams.toString();
        const fullUrl = queryString ? `${url}?${queryString}` : url;

        return this.request(fullUrl, {
            method: 'GET'
        });
    }

    /**
     * POST request
     */
    async post(url, data = {}) {
        return this.request(url, {
            method: 'POST',
            body: data
        });
    }

    /**
     * PUT request
     */
    async put(url, data = {}) {
        return this.request(url, {
            method: 'PUT',
            body: data
        });
    }

    /**
     * DELETE request
     */
    async delete(url) {
        return this.request(url, {
            method: 'DELETE'
        });
    }

    /**
     * Upload file
     */
    async upload(url, formData) {
        const token = Token.get();

        const config = {
            method: 'POST',
            body: formData,
            headers: {}
        };

        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        try {
            const response = await fetch(`${this.baseURL}${url}`, config);

            if (response.status === 401) {
                Token.remove();
                User.remove();
                window.location.href = '/';
                return;
            }

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('Upload failed:', error);
            throw error;
        }
    }

    // Authentication APIs
    async register(userData) {
        return this.post(this.endpoints.REGISTER, userData);
    }

    async login(credentials) {
        return this.post(this.endpoints.LOGIN, credentials);
    }

    async getMe() {
        return this.get(this.endpoints.ME);
    }

    async updateProfile(userData) {
        return this.put(this.endpoints.UPDATE_PROFILE, userData);
    }

    async changePassword(passwordData) {
        return this.put(this.endpoints.CHANGE_PASSWORD, passwordData);
    }

    // User APIs
    async updatePersonalInfo(personalInfo) {
        return this.put(this.endpoints.PERSONAL_INFO, personalInfo);
    }

    async getDashboard() {
        return this.get(this.endpoints.DASHBOARD);
    }

    // Loan APIs
    async createLoan(loanData) {
        return this.post(this.endpoints.LOANS, loanData);
    }

    async getLoans(params = {}) {
        return this.get(this.endpoints.LOANS, params);
    }

    async getLoan(id) {
        return this.get(this.endpoints.LOANS + `/${id}`);
    }

    async getLoanSchedule(id) {
        const url = this.endpoints.LOAN_SCHEDULE.replace('{id}', id);
        return this.get(url);
    }

    // Investment APIs
    async createInvestment(investmentData) {
        return this.post(this.endpoints.INVESTMENTS, investmentData);
    }

    async getInvestments(params = {}) {
        return this.get(this.endpoints.INVESTMENTS, params);
    }

    async getInvestment(id) {
        return this.get(this.endpoints.INVESTMENTS + `/${id}`);
    }

    // KYC APIs
    async uploadKYC(formData) {
        return this.upload(this.endpoints.KYC_UPLOAD, formData);
    }

    async updateKYCInfo(kycData) {
        return this.put(this.endpoints.KYC_INFO, kycData);
    }

    async getKYCStatus() {
        return this.get(this.endpoints.KYC_STATUS);
    }

    // Payment APIs
    async createEMIOrder(paymentData) {
        return this.post(this.endpoints.CREATE_EMI_ORDER, paymentData);
    }

    async createInvestmentOrder(paymentData) {
        return this.post(this.endpoints.CREATE_INVESTMENT_ORDER, paymentData);
    }

    async verifyPayment(paymentData) {
        return this.post(this.endpoints.VERIFY_PAYMENT, paymentData);
    }

    async getPaymentHistory(params = {}) {
        return this.get(this.endpoints.PAYMENT_HISTORY, params);
    }

    async getPaymentMethods() {
        return this.get(this.endpoints.PAYMENT_METHODS);
    }

    // Bank Account APIs
    async addBankAccount(bankData) {
        return this.post(this.endpoints.BANK_ACCOUNTS, bankData);
    }

    async getBankAccounts() {
        return this.get(this.endpoints.BANK_ACCOUNTS);
    }

    async updateBankAccount(id, bankData) {
        return this.put(this.endpoints.BANK_ACCOUNTS + `/${id}`, bankData);
    }

    async deleteBankAccount(id) {
        return this.delete(this.endpoints.BANK_ACCOUNTS + `/${id}`);
    }

    // Admin APIs
    async getAdminDashboard() {
        return this.get(this.endpoints.ADMIN_DASHBOARD);
    }

    async getPendingLoans() {
        return this.get(this.endpoints.ADMIN_LOANS_PENDING);
    }

    async reviewLoan(id, reviewData) {
        const url = this.endpoints.ADMIN_LOAN_REVIEW.replace('{id}', id);
        return this.put(url, reviewData);
    }

    async getPendingKYC() {
        return this.get(this.endpoints.ADMIN_KYC_PENDING);
    }

    async reviewKYC(id, reviewData) {
        const url = this.endpoints.ADMIN_KYC_REVIEW.replace('{id}', id);
        return this.put(url, reviewData);
    }

    async getUsers(params = {}) {
        return this.get(this.endpoints.ADMIN_USERS, params);
    }
}

// Create global API instance
const api = new ApiService();

// Export to window for global access
window.api = api;
window.ApiService = ApiService;

console.log('🌐 API Service loaded');
