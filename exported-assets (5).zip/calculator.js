// EMI Calculator Module for LendConnect

class EMICalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.setupDefaults();
    }

    bindEvents() {
        // Calculator form inputs
        const inputs = ['loanAmount', 'interestRate', 'loanTenure', 'creditGrade'];
        inputs.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('input', debounce(this.updateCalculation.bind(this), 300));
                element.addEventListener('change', this.updateCalculation.bind(this));
            }
        });

        // Credit grade change updates interest rate
        const creditGrade = document.getElementById('creditGrade');
        if (creditGrade) {
            creditGrade.addEventListener('change', this.updateInterestRate.bind(this));
        }

        // Format number inputs
        const amountInput = document.getElementById('loanAmount');
        if (amountInput) {
            amountInput.addEventListener('input', this.formatAmountInput.bind(this));
        }
    }

    setupDefaults() {
        // Set default values
        this.setDefaultValues();

        // Calculate with defaults
        setTimeout(() => {
            this.updateCalculation();
        }, 100);
    }

    setDefaultValues() {
        const defaults = {
            loanAmount: 500000,
            interestRate: 10,
            loanTenure: 24,
            creditGrade: 'A'
        };

        Object.keys(defaults).forEach(key => {
            const element = document.getElementById(key);
            if (element && !element.value) {
                element.value = defaults[key];
            }
        });
    }

    updateInterestRate() {
        const creditGrade = document.getElementById('creditGrade').value;
        const interestRateInput = document.getElementById('interestRate');

        if (creditGrade && interestRateInput) {
            const rate = Credit.getInterestRate(creditGrade);
            interestRateInput.value = rate;
            this.updateCalculation();
        }
    }

    formatAmountInput(event) {
        const input = event.target;
        let value = input.value.replace(/,/g, '');

        if (!isNaN(value) && value !== '') {
            const num = parseInt(value);
            if (num >= 0) {
                input.value = Format.number(num);
            }
        }
    }

    updateCalculation() {
        const loanAmount = this.parseAmount(document.getElementById('loanAmount')?.value);
        const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
        const loanTenure = parseInt(document.getElementById('loanTenure')?.value) || 0;

        // Validate inputs
        if (!this.validateInputs(loanAmount, interestRate, loanTenure)) {
            this.clearResults();
            return;
        }

        // Calculate EMI
        const emi = EMI.calculate(loanAmount, interestRate, loanTenure);
        const totalInterest = EMI.totalInterest(loanAmount, interestRate, loanTenure);
        const totalAmount = EMI.totalAmount(loanAmount, interestRate, loanTenure);

        // Update display
        this.displayResults({
            emi,
            totalInterest,
            totalAmount,
            loanAmount,
            interestRate,
            loanTenure
        });

        // Update progress indicators if they exist
        this.updateProgressIndicators(loanAmount, interestRate, loanTenure);
    }

    parseAmount(amountStr) {
        if (!amountStr) return 0;
        return parseInt(amountStr.replace(/,/g, '')) || 0;
    }

    validateInputs(amount, rate, tenure) {
        return (
            amount >= APP_CONFIG.LOAN.MIN_AMOUNT &&
            amount <= APP_CONFIG.LOAN.MAX_AMOUNT &&
            rate > 0 && rate <= 30 &&
            tenure >= APP_CONFIG.LOAN.MIN_TENURE &&
            tenure <= APP_CONFIG.LOAN.MAX_TENURE
        );
    }

    displayResults(results) {
        const { emi, totalInterest, totalAmount } = results;

        // Update result elements
        this.updateElement('emiAmount', Format.currency(emi));
        this.updateElement('totalInterest', Format.currency(totalInterest));
        this.updateElement('totalAmount', Format.currency(totalAmount));

        // Show breakdown if element exists
        this.showBreakdown(results);
    }

    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }

    clearResults() {
        this.updateElement('emiAmount', '₹0');
        this.updateElement('totalInterest', '₹0');
        this.updateElement('totalAmount', '₹0');
    }

    showBreakdown(results) {
        const { loanAmount, totalInterest, totalAmount } = results;

        // Create breakdown chart data
        const principalPercentage = (loanAmount / totalAmount) * 100;
        const interestPercentage = (totalInterest / totalAmount) * 100;

        // Update progress bars if they exist
        const principalBar = document.getElementById('principalBar');
        const interestBar = document.getElementById('interestBar');

        if (principalBar && interestBar) {
            principalBar.style.width = `${principalPercentage}%`;
            interestBar.style.width = `${interestPercentage}%`;
        }

        // Update percentage labels
        this.updateElement('principalPercentage', `${principalPercentage.toFixed(1)}%`);
        this.updateElement('interestPercentage', `${interestPercentage.toFixed(1)}%`);
    }

    updateProgressIndicators(amount, rate, tenure) {
        // Amount progress (relative to max loan amount)
        const amountProgress = (amount / APP_CONFIG.LOAN.MAX_AMOUNT) * 100;
        this.updateProgressBar('amountProgress', amountProgress);

        // Rate progress (relative to max rate of 30%)
        const rateProgress = (rate / 30) * 100;
        this.updateProgressBar('rateProgress', rateProgress);

        // Tenure progress (relative to max tenure)
        const tenureProgress = (tenure / APP_CONFIG.LOAN.MAX_TENURE) * 100;
        this.updateProgressBar('tenureProgress', tenureProgress);
    }

    updateProgressBar(id, percentage) {
        const progressBar = document.getElementById(id);
        if (progressBar) {
            progressBar.style.width = `${Math.min(percentage, 100)}%`;
        }
    }

    generateSchedule() {
        const loanAmount = this.parseAmount(document.getElementById('loanAmount')?.value);
        const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
        const loanTenure = parseInt(document.getElementById('loanTenure')?.value) || 0;

        if (!this.validateInputs(loanAmount, interestRate, loanTenure)) {
            showAlert('Please enter valid loan details to generate schedule.', 'error');
            return;
        }

        const schedule = EMI.schedule(loanAmount, interestRate, loanTenure);
        this.displaySchedule(schedule);
    }

    displaySchedule(schedule) {
        const modal = document.getElementById('scheduleModal');
        const tableBody = document.getElementById('scheduleTableBody');

        if (!modal || !tableBody) {
            console.warn('Schedule modal elements not found');
            return;
        }

        // Clear existing rows
        tableBody.innerHTML = '';

        // Populate schedule table
        schedule.forEach(payment => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${payment.emiNumber}</td>
                <td>₹${Format.number(payment.amount)}</td>
                <td>₹${Format.number(payment.principal)}</td>
                <td>₹${Format.number(payment.interest)}</td>
                <td>₹${Format.number(payment.balance)}</td>
            `;
            tableBody.appendChild(row);
        });

        // Show modal
        showModal('scheduleModal');
    }

    exportSchedule() {
        const loanAmount = this.parseAmount(document.getElementById('loanAmount')?.value);
        const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
        const loanTenure = parseInt(document.getElementById('loanTenure')?.value) || 0;

        if (!this.validateInputs(loanAmount, interestRate, loanTenure)) {
            showAlert('Please enter valid loan details to export schedule.', 'error');
            return;
        }

        const schedule = EMI.schedule(loanAmount, interestRate, loanTenure);

        // Create CSV content
        let csvContent = "EMI Number,EMI Amount,Principal,Interest,Balance\n";
        schedule.forEach(payment => {
            csvContent += `${payment.emiNumber},${payment.amount},${payment.principal},${payment.interest},${payment.balance}\n`;
        });

        // Download CSV file
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `emi_schedule_${loanAmount}_${loanTenure}months.csv`;
        link.click();
        window.URL.revokeObjectURL(url);

        showAlert('EMI schedule exported successfully!', 'success');
    }

    reset() {
        this.setDefaultValues();
        this.updateCalculation();
        showAlert('Calculator reset to default values.', 'info');
    }
}

// Global functions for calculator
function calculateEMI() {
    if (window.emiCalculator) {
        window.emiCalculator.updateCalculation();
    }
}

function showCalculator() {
    const calculatorSection = document.getElementById('calculator');
    if (calculatorSection) {
        calculatorSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function generateEMISchedule() {
    if (window.emiCalculator) {
        window.emiCalculator.generateSchedule();
    }
}

function exportEMISchedule() {
    if (window.emiCalculator) {
        window.emiCalculator.exportSchedule();
    }
}

function resetCalculator() {
    if (window.emiCalculator) {
        window.emiCalculator.reset();
    }
}

// Initialize calculator when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.emiCalculator = new EMICalculator();
});

// Export functions
window.calculateEMI = calculateEMI;
window.showCalculator = showCalculator;
window.generateEMISchedule = generateEMISchedule;
window.exportEMISchedule = exportEMISchedule;
window.resetCalculator = resetCalculator;

console.log('🧮 EMI Calculator module loaded');
