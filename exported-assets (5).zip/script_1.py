# Create component styles
components_css = '''/* Modal Components */
.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: var(--white);
    border-radius: var(--border-radius-xl);
    box-shadow: var(--shadow-xl);
    width: 90%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    transform: translateY(-20px);
    transition: transform 0.3s ease;
}

.modal.active .modal-content {
    transform: translateY(0);
}

.modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--spacing-xl);
    border-bottom: 1px solid var(--gray-200);
}

.modal-header h3 {
    margin: 0;
    color: var(--gray-900);
}

.modal-close {
    background: none;
    border: none;
    font-size: 2rem;
    color: var(--gray-400);
    cursor: pointer;
    transition: var(--transition-base);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
}

.modal-close:hover {
    background: var(--gray-100);
    color: var(--gray-700);
}

.modal-body {
    padding: var(--spacing-xl);
}

.form-actions {
    margin: var(--spacing-xl) 0;
}

.form-footer {
    text-align: center;
    padding-top: var(--spacing-lg);
    border-top: 1px solid var(--gray-200);
}

.form-footer p {
    margin: 0;
    color: var(--gray-600);
}

.form-footer a {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: var(--font-weight-medium);
}

.form-footer a:hover {
    text-decoration: underline;
}

/* Alert Components */
.alert {
    padding: var(--spacing-md) var(--spacing-lg);
    border-radius: var(--border-radius-md);
    margin-bottom: var(--spacing-lg);
    border: 1px solid transparent;
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
}

.alert-success {
    background: #f0fdf4;
    border-color: #bbf7d0;
    color: #166534;
}

.alert-error {
    background: #fef2f2;
    border-color: #fecaca;
    color: #dc2626;
}

.alert-warning {
    background: #fffbeb;
    border-color: #fed7aa;
    color: #d97706;
}

.alert-info {
    background: #eff6ff;
    border-color: #bfdbfe;
    color: #2563eb;
}

/* Loading Components */
.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.loading-overlay.active {
    opacity: 1;
    visibility: visible;
}

.loading-spinner {
    text-align: center;
}

.loading-spinner i {
    font-size: 3rem;
    color: var(--primary-color);
    margin-bottom: var(--spacing-lg);
}

.loading-spinner p {
    color: var(--gray-600);
    font-weight: var(--font-weight-medium);
}

/* Card Components */
.card {
    background: var(--white);
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-md);
    overflow: hidden;
    transition: var(--transition-base);
}

.card:hover {
    box-shadow: var(--shadow-lg);
    transform: translateY(-2px);
}

.card-header {
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--gray-200);
}

.card-body {
    padding: var(--spacing-lg);
}

.card-footer {
    padding: var(--spacing-lg);
    border-top: 1px solid var(--gray-200);
    background: var(--gray-50);
}

/* Dashboard Layout */
.dashboard {
    min-height: 100vh;
    background: var(--gray-50);
    padding-top: 80px;
}

.dashboard-container {
    display: grid;
    grid-template-columns: 250px 1fr;
    gap: var(--spacing-2xl);
    max-width: 1400px;
    margin: 0 auto;
    padding: var(--spacing-xl);
}

.sidebar {
    background: var(--white);
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-sm);
    height: fit-content;
    position: sticky;
    top: 100px;
}

.sidebar-header {
    padding: var(--spacing-xl);
    border-bottom: 1px solid var(--gray-200);
}

.sidebar-nav {
    padding: var(--spacing-lg);
}

.nav-item {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    padding: var(--spacing-md) var(--spacing-lg);
    margin-bottom: var(--spacing-xs);
    border-radius: var(--border-radius-md);
    text-decoration: none;
    color: var(--gray-700);
    transition: var(--transition-base);
}

.nav-item:hover {
    background: var(--gray-50);
    color: var(--primary-color);
}

.nav-item.active {
    background: var(--primary-color);
    color: var(--white);
}

.nav-item i {
    font-size: 1.125rem;
}

.main-content {
    min-height: 80vh;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: var(--spacing-lg);
    margin-bottom: var(--spacing-2xl);
}

.stat-card {
    background: var(--white);
    padding: var(--spacing-xl);
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-sm);
    border-left: 4px solid var(--primary-color);
}

.stat-card.success {
    border-left-color: var(--secondary-color);
}

.stat-card.warning {
    border-left-color: var(--warning-color);
}

.stat-card.error {
    border-left-color: var(--error-color);
}

.stat-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: var(--spacing-md);
}

.stat-title {
    color: var(--gray-600);
    font-size: 0.875rem;
    font-weight: var(--font-weight-medium);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.125rem;
}

.stat-icon.primary {
    background: rgba(37, 99, 235, 0.1);
    color: var(--primary-color);
}

.stat-icon.success {
    background: rgba(16, 185, 129, 0.1);
    color: var(--secondary-color);
}

.stat-icon.warning {
    background: rgba(245, 158, 11, 0.1);
    color: var(--warning-color);
}

.stat-value {
    font-size: 2rem;
    font-weight: var(--font-weight-bold);
    color: var(--gray-900);
    margin-bottom: var(--spacing-xs);
}

.stat-change {
    font-size: 0.875rem;
    display: flex;
    align-items: center;
    gap: var(--spacing-xs);
}

.stat-change.positive {
    color: var(--secondary-color);
}

.stat-change.negative {
    color: var(--error-color);
}

/* Table Components */
.table-container {
    background: var(--white);
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
}

.table-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--gray-200);
}

.table-title {
    font-size: 1.25rem;
    font-weight: var(--font-weight-semibold);
    color: var(--gray-900);
}

.table-actions {
    display: flex;
    gap: var(--spacing-md);
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th,
.table td {
    padding: var(--spacing-md) var(--spacing-lg);
    text-align: left;
    border-bottom: 1px solid var(--gray-200);
}

.table th {
    background: var(--gray-50);
    font-weight: var(--font-weight-semibold);
    color: var(--gray-700);
    font-size: 0.875rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: var(--transition-base);
}

.table tbody tr:hover {
    background: var(--gray-50);
}

/* Status Badges */
.badge {
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: var(--font-weight-medium);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.badge-primary {
    background: rgba(37, 99, 235, 0.1);
    color: var(--primary-color);
}

.badge-success {
    background: rgba(16, 185, 129, 0.1);
    color: var(--secondary-color);
}

.badge-warning {
    background: rgba(245, 158, 11, 0.1);
    color: var(--warning-color);
}

.badge-error {
    background: rgba(239, 68, 68, 0.1);
    color: var(--error-color);
}

.badge-secondary {
    background: var(--gray-100);
    color: var(--gray-700);
}

/* Progress Components */
.progress-bar {
    background: var(--gray-200);
    border-radius: 9999px;
    height: 8px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    border-radius: 9999px;
    transition: width 0.5s ease;
}

/* Credit Grade */
.credit-grade {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    font-weight: var(--font-weight-bold);
    font-size: 1rem;
}

.credit-grade.a-plus {
    background: #10b981;
    color: white;
}

.credit-grade.a {
    background: #059669;
    color: white;
}

.credit-grade.b {
    background: #f59e0b;
    color: white;
}

.credit-grade.c {
    background: #f97316;
    color: white;
}

.credit-grade.d {
    background: #ef4444;
    color: white;
}

/* Payment Methods */
.payment-methods {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: var(--spacing-lg);
    margin: var(--spacing-xl) 0;
}

.payment-method {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    padding: var(--spacing-lg);
    border: 2px solid var(--gray-200);
    border-radius: var(--border-radius-lg);
    cursor: pointer;
    transition: var(--transition-base);
}

.payment-method:hover {
    border-color: var(--primary-color);
    background: var(--gray-50);
}

.payment-method.selected {
    border-color: var(--primary-color);
    background: rgba(37, 99, 235, 0.05);
}

.payment-icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--border-radius-md);
    background: var(--gray-100);
    font-size: 1.25rem;
}

.payment-info h4 {
    margin: 0 0 0.25rem 0;
    color: var(--gray-900);
}

.payment-info p {
    margin: 0;
    font-size: 0.875rem;
    color: var(--gray-600);
}

/* Responsive Design */
@media (max-width: 1024px) {
    .dashboard-container {
        grid-template-columns: 1fr;
        gap: var(--spacing-lg);
    }
    
    .sidebar {
        position: static;
        order: 2;
    }
    
    .main-content {
        order: 1;
    }
}

@media (max-width: 640px) {
    .modal-content {
        width: 95%;
        margin: var(--spacing-md);
    }
    
    .modal-header,
    .modal-body {
        padding: var(--spacing-lg);
    }
    
    .dashboard-container {
        padding: var(--spacing-md);
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .table-container {
        overflow-x: auto;
    }
    
    .table {
        min-width: 600px;
    }
    
    .payment-methods {
        grid-template-columns: 1fr;
    }
}

/* Animation Utilities */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-20px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.animate-fade-in {
    animation: fadeIn 0.5s ease-out;
}

.animate-slide-in {
    animation: slideIn 0.5s ease-out;
}

/* Print Styles */
@media print {
    .navbar,
    .sidebar,
    .btn,
    .loading-overlay,
    .modal {
        display: none !important;
    }
    
    .dashboard-container {
        grid-template-columns: 1fr;
        gap: 0;
    }
    
    .card,
    .table-container {
        box-shadow: none;
        border: 1px solid var(--gray-300);
    }
}
'''

with open('frontend/css/components.css', 'w') as f:
    f.write(components_css)

print("Created frontend/css/components.css - Component styles")

# Create JavaScript configuration
config_js = '''// API Configuration
const API_CONFIG = {
    BASE_URL: 'http://localhost:5000/api', // Change this to your deployed backend URL
    ENDPOINTS: {
        // Authentication
        REGISTER: '/auth/register',
        LOGIN: '/auth/login',
        ME: '/auth/me',
        UPDATE_PROFILE: '/auth/profile',
        CHANGE_PASSWORD: '/auth/password',
        
        // Users
        PERSONAL_INFO: '/users/personal-info',
        DASHBOARD: '/users/dashboard',
        
        // Loans
        LOANS: '/loans',
        LOAN_SCHEDULE: '/loans/{id}/schedule',
        
        // Investments
        INVESTMENTS: '/investments',
        
        // KYC
        KYC_UPLOAD: '/kyc/upload',
        KYC_INFO: '/kyc/info',
        KYC_STATUS: '/kyc/status',
        
        // Payments
        CREATE_EMI_ORDER: '/payments/create-emi-order',
        CREATE_INVESTMENT_ORDER: '/payments/create-investment-order',
        VERIFY_PAYMENT: '/payments/verify',
        PAYMENT_HISTORY: '/payments/history',
        PAYMENT_METHODS: '/payments/methods',
        
        // Bank Accounts
        BANK_ACCOUNTS: '/bank-accounts',
        
        // Admin
        ADMIN_DASHBOARD: '/admin/dashboard',
        ADMIN_LOANS_PENDING: '/admin/loans/pending',
        ADMIN_LOAN_REVIEW: '/admin/loans/{id}/review',
        ADMIN_KYC_PENDING: '/admin/kyc/pending',
        ADMIN_KYC_REVIEW: '/admin/kyc/{id}/review',
        ADMIN_USERS: '/admin/users'
    }
};

// Razorpay Configuration
const RAZORPAY_CONFIG = {
    KEY_ID: 'rzp_test_9WzaIvXQJKvzN4', // Replace with your Razorpay key
    OPTIONS: {
        currency: 'INR',
        name: 'LendConnect',
        description: 'P2P Lending Platform',
        image: '/images/logo.png',
        theme: {
            color: '#2563eb'
        }
    }
};

// App Configuration
const APP_CONFIG = {
    NAME: 'LendConnect',
    VERSION: '1.0.0',
    ENVIRONMENT: 'development', // 'development' or 'production'
    
    // Loan Configuration
    LOAN: {
        MIN_AMOUNT: 10000,
        MAX_AMOUNT: 5000000,
        MIN_TENURE: 6,
        MAX_TENURE: 60,
        PURPOSES: [
            'Business Expansion',
            'Education',
            'Home Renovation',
            'Medical Emergency',
            'Wedding',
            'Travel',
            'Debt Consolidation',
            'Personal',
            'Other'
        ]
    },
    
    // Investment Configuration
    INVESTMENT: {
        MIN_AMOUNT: 100,
        DEFAULT_AMOUNT: 1000
    },
    
    // Interest Rates by Credit Grade
    INTEREST_RATES: {
        'A+': 9,
        'A': 10,
        'B': 12,
        'C': 14,
        'D': 16
    },
    
    // File Upload Configuration
    UPLOAD: {
        MAX_SIZE: 5 * 1024 * 1024, // 5MB
        ALLOWED_TYPES: ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']
    },
    
    // Pagination
    PAGINATION: {
        DEFAULT_LIMIT: 10,
        MAX_LIMIT: 50
    }
};

// Theme Configuration
const THEME_CONFIG = {
    COLORS: {
        primary: '#2563eb',
        secondary: '#10b981',
        accent: '#f59e0b',
        error: '#ef4444',
        warning: '#f59e0b',
        success: '#10b981'
    }
};

// Export configurations
window.API_CONFIG = API_CONFIG;
window.RAZORPAY_CONFIG = RAZORPAY_CONFIG;
window.APP_CONFIG = APP_CONFIG;
window.THEME_CONFIG = THEME_CONFIG;

// Set dynamic API base URL based on environment
if (APP_CONFIG.ENVIRONMENT === 'production') {
    // Update this with your production backend URL
    API_CONFIG.BASE_URL = 'https://your-app.railway.app/api';
}

console.log('🚀 LendConnect Frontend Loaded');
console.log('📡 API Base URL:', API_CONFIG.BASE_URL);
console.log('💳 Payment Gateway:', RAZORPAY_CONFIG.KEY_ID ? 'Configured' : 'Not Configured');
'''

with open('frontend/js/config.js', 'w') as f:
    f.write(config_js)

print("Created frontend/js/config.js - Configuration file")

# Create utility functions
utils_js = '''// Utility Functions for LendConnect

/**
 * Local Storage Utilities
 */
const Storage = {
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error('Error saving to localStorage:', error);
        }
    },

    get(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Error reading from localStorage:', error);
            return defaultValue;
        }
    },

    remove(key) {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.error('Error removing from localStorage:', error);
        }
    },

    clear() {
        try {
            localStorage.clear();
        } catch (error) {
            console.error('Error clearing localStorage:', error);
        }
    }
};

/**
 * Authentication Token Management
 */
const Token = {
    set(token) {
        Storage.set('auth_token', token);
    },

    get() {
        return Storage.get('auth_token');
    },

    remove() {
        Storage.remove('auth_token');
    },

    isValid() {
        const token = this.get();
        if (!token) return false;

        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            return payload.exp > Date.now() / 1000;
        } catch (error) {
            return false;
        }
    }
};

/**
 * User Management
 */
const User = {
    set(userData) {
        Storage.set('user_data', userData);
    },

    get() {
        return Storage.get('user_data');
    },

    remove() {
        Storage.remove('user_data');
    },

    isLoggedIn() {
        return this.get() && Token.isValid();
    },

    getRole() {
        const user = this.get();
        return user ? user.userType : null;
    },

    getName() {
        const user = this.get();
        return user ? user.name : null;
    },

    getEmail() {
        const user = this.get();
        return user ? user.email : null;
    }
};

/**
 * Format Utilities
 */
const Format = {
    currency(amount, showSymbol = true) {
        const formatted = new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);

        return showSymbol ? formatted : formatted.replace('₹', '').trim();
    },

    number(number) {
        return new Intl.NumberFormat('en-IN').format(number);
    },

    percentage(value, decimals = 1) {
        return `${Number(value).toFixed(decimals)}%`;
    },

    date(date, options = {}) {
        const defaultOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        };
        
        return new Date(date).toLocaleDateString('en-IN', { ...defaultOptions, ...options });
    },

    dateTime(date) {
        return new Date(date).toLocaleString('en-IN');
    },

    phone(phone) {
        if (!phone) return '';
        const cleaned = phone.replace(/\\D/g, '');
        if (cleaned.length === 10) {
            return `+91 ${cleaned.substring(0, 5)} ${cleaned.substring(5)}`;
        }
        return phone;
    },

    truncate(text, length = 50) {
        if (!text || text.length <= length) return text;
        return text.substring(0, length) + '...';
    }
};

/**
 * Validation Utilities
 */
const Validate = {
    email(email) {
        const re = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
        return re.test(email);
    },

    phone(phone) {
        const re = /^[6-9]\\d{9}$/;
        return re.test(phone.replace(/\\D/g, ''));
    },

    pan(pan) {
        const re = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        return re.test(pan.toUpperCase());
    },

    aadhaar(aadhaar) {
        const cleaned = aadhaar.replace(/\\D/g, '');
        return cleaned.length === 12 && /^[2-9]/.test(cleaned);
    },

    ifsc(ifsc) {
        const re = /^[A-Z]{4}0[A-Z0-9]{6}$/;
        return re.test(ifsc.toUpperCase());
    },

    amount(amount, min = 0, max = Infinity) {
        const num = parseFloat(amount);
        return !isNaN(num) && num >= min && num <= max;
    },

    required(value) {
        return value !== null && value !== undefined && value.toString().trim() !== '';
    }
};

/**
 * EMI Calculation Utilities
 */
const EMI = {
    calculate(principal, rate, tenure) {
        const monthlyRate = rate / (12 * 100);
        if (monthlyRate === 0) {
            return principal / tenure;
        }
        
        const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / 
                   (Math.pow(1 + monthlyRate, tenure) - 1);
        
        return Math.round(emi);
    },

    totalInterest(principal, rate, tenure) {
        const emi = this.calculate(principal, rate, tenure);
        return (emi * tenure) - principal;
    },

    totalAmount(principal, rate, tenure) {
        const emi = this.calculate(principal, rate, tenure);
        return emi * tenure;
    },

    schedule(principal, rate, tenure) {
        const schedule = [];
        const monthlyRate = rate / (12 * 100);
        const emi = this.calculate(principal, rate, tenure);
        let balance = principal;
        
        for (let i = 1; i <= tenure; i++) {
            const interestComponent = balance * monthlyRate;
            const principalComponent = emi - interestComponent;
            balance -= principalComponent;
            
            schedule.push({
                emiNumber: i,
                amount: Math.round(emi),
                principal: Math.round(principalComponent),
                interest: Math.round(interestComponent),
                balance: Math.max(0, Math.round(balance))
            });
        }
        
        return schedule;
    }
};

/**
 * Credit Grade Utilities
 */
const Credit = {
    getGrade(monthlyIncome, loanAmount) {
        if (!monthlyIncome) return 'D';
        
        const ratio = loanAmount / (monthlyIncome * 12);
        
        if (monthlyIncome >= 100000 && ratio <= 3) return 'A+';
        if (monthlyIncome >= 75000 && ratio <= 4) return 'A';
        if (monthlyIncome >= 50000 && ratio <= 5) return 'B';
        if (monthlyIncome >= 25000 && ratio <= 6) return 'C';
        return 'D';
    },

    getInterestRate(grade) {
        return APP_CONFIG.INTEREST_RATES[grade] || 16;
    },

    getDescription(grade) {
        const descriptions = {
            'A+': 'Excellent credit profile',
            'A': 'Very good credit profile',
            'B': 'Good credit profile',
            'C': 'Fair credit profile',
            'D': 'Poor credit profile'
        };
        return descriptions[grade] || 'Unknown';
    },

    getColor(grade) {
        const colors = {
            'A+': '#10b981',
            'A': '#059669',
            'B': '#f59e0b',
            'C': '#f97316',
            'D': '#ef4444'
        };
        return colors[grade] || '#6b7280';
    }
};

/**
 * File Utilities
 */
const FileUtils = {
    validateFile(file) {
        const errors = [];

        // Check file size (5MB limit)
        if (file.size > APP_CONFIG.UPLOAD.MAX_SIZE) {
            errors.push(`File size must be less than ${APP_CONFIG.UPLOAD.MAX_SIZE / (1024 * 1024)}MB`);
        }

        // Check file type
        const extension = file.name.split('.').pop().toLowerCase();
        if (!APP_CONFIG.UPLOAD.ALLOWED_TYPES.includes(extension)) {
            errors.push(`File type '${extension}' is not allowed`);
        }

        return {
            valid: errors.length === 0,
            errors
        };
    },

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';

        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
};

/**
 * URL Utilities
 */
const URL = {
    getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    },

    setQueryParam(param, value) {
        const url = new URL(window.location);
        url.searchParams.set(param, value);
        window.history.pushState({}, '', url);
    },

    removeQueryParam(param) {
        const url = new URL(window.location);
        url.searchParams.delete(param);
        window.history.pushState({}, '', url);
    }
};

/**
 * DOM Utilities
 */
const DOM = {
    show(element) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.style.display = 'block';
            element.classList.remove('hidden');
        }
    },

    hide(element) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.style.display = 'none';
            element.classList.add('hidden');
        }
    },

    toggle(element) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            if (element.style.display === 'none' || element.classList.contains('hidden')) {
                this.show(element);
            } else {
                this.hide(element);
            }
        }
    },

    addClass(element, className) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.classList.add(className);
        }
    },

    removeClass(element, className) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.classList.remove(className);
        }
    },

    hasClass(element, className) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        return element ? element.classList.contains(className) : false;
    }
};

/**
 * Device Utilities
 */
const Device = {
    isMobile() {
        return window.innerWidth <= 768;
    },

    isTablet() {
        return window.innerWidth > 768 && window.innerWidth <= 1024;
    },

    isDesktop() {
        return window.innerWidth > 1024;
    }
};

/**
 * Debounce Utility
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle Utility
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export utilities to window for global access
window.Storage = Storage;
window.Token = Token;
window.User = User;
window.Format = Format;
window.Validate = Validate;
window.EMI = EMI;
window.Credit = Credit;
window.FileUtils = FileUtils;
window.URL = URL;
window.DOM = DOM;
window.Device = Device;
window.debounce = debounce;
window.throttle = throttle;

console.log('🛠️ Utility functions loaded');
'''

with open('frontend/js/utils.js', 'w') as f:
    f.write(utils_js)

print("Created frontend/js/utils.js - Utility functions")