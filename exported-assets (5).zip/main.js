// Main Application JavaScript for LendConnect

class LendConnectApp {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.initializeComponents();
        this.setupNavigationHandlers();
    }

    bindEvents() {
        // Modal events
        this.bindModalEvents();

        // Navigation events
        this.bindNavigationEvents();

        // Form events
        this.bindFormEvents();

        // Window events
        window.addEventListener('resize', this.handleResize.bind(this));
        window.addEventListener('scroll', throttle(this.handleScroll.bind(this), 100));
    }

    bindModalEvents() {
        // Modal close events
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                closeModal(e.target.id);
            }
            if (e.target.classList.contains('modal-close')) {
                const modal = e.target.closest('.modal');
                if (modal) closeModal(modal.id);
            }
        });

        // Escape key to close modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const activeModal = document.querySelector('.modal.active');
                if (activeModal) {
                    closeModal(activeModal.id);
                }
            }
        });
    }

    bindNavigationEvents() {
        // Smooth scroll for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                if (href === '#') return;

                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                    this.updateActiveNavLink(href);
                }
            });
        });

        // Mobile navigation toggle
        const navToggle = document.getElementById('navToggle');
        const navLinks = document.getElementById('navLinks');

        if (navToggle && navLinks) {
            navToggle.addEventListener('click', () => {
                navLinks.classList.toggle('active');
            });
        }
    }

    bindFormEvents() {
        // Format phone number inputs
        document.addEventListener('input', (e) => {
            if (e.target.type === 'tel') {
                this.formatPhoneInput(e.target);
            }
        });

        // Format currency inputs
        document.addEventListener('input', (e) => {
            if (e.target.classList.contains('currency-input')) {
                this.formatCurrencyInput(e.target);
            }
        });

        // Real-time validation
        document.addEventListener('blur', (e) => {
            if (e.target.tagName === 'INPUT') {
                this.validateField(e.target);
            }
        });
    }

    initializeComponents() {
        // Initialize tooltips if library is loaded
        if (typeof tippy !== 'undefined') {
            tippy('[data-tippy-content]');
        }

        // Initialize step tabs
        this.initializeStepTabs();

        // Initialize lazy loading for images
        this.initializeLazyLoading();

        // Update copyright year
        this.updateCopyrightYear();
    }

    initializeStepTabs() {
        const stepTabs = document.querySelectorAll('.step-tab');
        stepTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const targetId = tab.dataset.tab;
                this.showStepContent(targetId);

                // Update active tab
                stepTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
            });
        });
    }

    showStepContent(targetId) {
        const contents = document.querySelectorAll('.step-content');
        contents.forEach(content => {
            content.classList.remove('active');
            if (content.id === targetId) {
                content.classList.add('active');
            }
        });
    }

    initializeLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        observer.unobserve(img);
                    }
                });
            });

            images.forEach(img => observer.observe(img));
        } else {
            // Fallback for older browsers
            images.forEach(img => {
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
            });
        }
    }

    setupNavigationHandlers() {
        // Update active navigation link based on scroll position
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link[href^="#"]');

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const id = entry.target.id;
                    this.updateActiveNavLink(`#${id}`);
                }
            });
        }, { threshold: 0.5 });

        sections.forEach(section => observer.observe(section));
    }

    updateActiveNavLink(activeHref) {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === activeHref) {
                link.classList.add('active');
            }
        });
    }

    handleResize() {
        // Close mobile menu on resize
        const navLinks = document.getElementById('navLinks');
        if (navLinks && window.innerWidth > 1024) {
            navLinks.classList.remove('active');
        }
    }

    handleScroll() {
        const navbar = document.getElementById('navbar');
        if (navbar) {
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }
    }

    formatPhoneInput(input) {
        let value = input.value.replace(/\D/g, '');
        if (value.length > 10) {
            value = value.substring(0, 10);
        }

        if (value.length >= 6) {
            value = `${value.substring(0, 5)} ${value.substring(5)}`;
        }

        input.value = value;
    }

    formatCurrencyInput(input) {
        let value = input.value.replace(/[^\d]/g, '');
        if (value) {
            const number = parseInt(value);
            input.value = Format.number(number);
        }
    }

    validateField(field) {
        const value = field.value.trim();
        const type = field.type;
        const name = field.name || field.id;

        let isValid = true;
        let message = '';

        // Remove existing validation classes
        field.classList.remove('invalid', 'valid');

        switch (type) {
            case 'email':
                if (value && !Validate.email(value)) {
                    isValid = false;
                    message = 'Please enter a valid email address';
                }
                break;
            case 'tel':
                if (value && !Validate.phone(value)) {
                    isValid = false;
                    message = 'Please enter a valid 10-digit phone number';
                }
                break;
            case 'number':
                const min = parseFloat(field.min) || 0;
                const max = parseFloat(field.max) || Infinity;
                const num = parseFloat(value);
                if (value && (isNaN(num) || num < min || num > max)) {
                    isValid = false;
                    message = `Please enter a number between ${min} and ${max}`;
                }
                break;
        }

        // Add validation class
        if (value) {
            field.classList.add(isValid ? 'valid' : 'invalid');
        }

        // Show/hide validation message
        const existingMessage = field.parentNode.querySelector('.validation-message');
        if (existingMessage) {
            existingMessage.remove();
        }

        if (!isValid && message) {
            const messageEl = document.createElement('div');
            messageEl.className = 'validation-message';
            messageEl.textContent = message;
            field.parentNode.appendChild(messageEl);
        }

        return isValid;
    }

    updateCopyrightYear() {
        const yearElements = document.querySelectorAll('.current-year');
        const currentYear = new Date().getFullYear();
        yearElements.forEach(el => {
            el.textContent = currentYear;
        });
    }
}

// Global utility functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';

        // Clear form data
        const forms = modal.querySelectorAll('form');
        forms.forEach(form => form.reset());

        // Clear validation messages
        const messages = modal.querySelectorAll('.validation-message');
        messages.forEach(msg => msg.remove());

        // Clear validation classes
        const inputs = modal.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.classList.remove('valid', 'invalid');
        });
    }
}

function showLoading(message = 'Loading...') {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        const messageEl = overlay.querySelector('.loading-spinner p');
        if (messageEl) {
            messageEl.textContent = message;
        }
        overlay.classList.add('active');
    }
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.remove('active');
    }
}

function showAlert(message, type = 'info', duration = 5000) {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert-notification');
    existingAlerts.forEach(alert => alert.remove());

    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert-notification alert-${type}`;
    alert.innerHTML = `
        <div class="alert-content">
            <i class="fas ${getAlertIcon(type)}"></i>
            <span>${message}</span>
            <button class="alert-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    // Add styles
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 400px;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        transform: translateX(100%);
        opacity: 0;
    `;

    // Add to body
    document.body.appendChild(alert);

    // Show alert with animation
    setTimeout(() => {
        alert.style.transform = 'translateX(0)';
        alert.style.opacity = '1';
    }, 100);

    // Auto remove after duration
    if (duration > 0) {
        setTimeout(() => {
            if (alert && alert.parentNode) {
                alert.style.transform = 'translateX(100%)';
                alert.style.opacity = '0';
                setTimeout(() => {
                    if (alert && alert.parentNode) {
                        alert.remove();
                    }
                }, 300);
            }
        }, duration);
    }
}

function getAlertIcon(type) {
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    return icons[type] || icons.info;
}

// Form submission helper
async function submitForm(formElement, apiCall, successMessage = 'Operation completed successfully') {
    const formData = new FormData(formElement);
    const data = {};

    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }

    try {
        showLoading('Processing...');
        const response = await apiCall(data);

        if (response.success) {
            showAlert(successMessage, 'success');
            formElement.reset();
            return response;
        } else {
            throw new Error(response.message || 'Operation failed');
        }
    } catch (error) {
        console.error('Form submission error:', error);
        showAlert(error.message || 'An error occurred. Please try again.', 'error');
        throw error;
    } finally {
        hideLoading();
    }
}

// Payment integration helper
async function processPayment(paymentData, paymentType = 'investment') {
    try {
        showLoading('Creating payment order...');

        let orderResponse;
        if (paymentType === 'emi') {
            orderResponse = await api.createEMIOrder(paymentData);
        } else {
            orderResponse = await api.createInvestmentOrder(paymentData);
        }

        if (!orderResponse.success) {
            throw new Error(orderResponse.message || 'Failed to create payment order');
        }

        hideLoading();

        // Initialize Razorpay
        const options = {
            key: orderResponse.data.key,
            amount: orderResponse.data.order.amount,
            currency: orderResponse.data.order.currency,
            name: RAZORPAY_CONFIG.OPTIONS.name,
            description: orderResponse.data.order.receipt,
            order_id: orderResponse.data.order.id,
            handler: async function(response) {
                await handlePaymentSuccess(response);
            },
            prefill: {
                name: orderResponse.data.user.name,
                email: orderResponse.data.user.email,
                contact: orderResponse.data.user.phone
            },
            notes: orderResponse.data.order.notes,
            theme: RAZORPAY_CONFIG.OPTIONS.theme
        };

        const razorpay = new Razorpay(options);
        razorpay.on('payment.failed', function(response) {
            handlePaymentFailure(response);
        });

        razorpay.open();

    } catch (error) {
        console.error('Payment processing error:', error);
        showAlert(error.message || 'Failed to process payment', 'error');
        hideLoading();
    }
}

async function handlePaymentSuccess(response) {
    try {
        showLoading('Verifying payment...');

        const verifyResponse = await api.verifyPayment({
            razorpay_order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature
        });

        if (verifyResponse.success) {
            showAlert('Payment successful! Transaction completed.', 'success');

            // Refresh page or redirect after success
            setTimeout(() => {
                window.location.reload();
            }, 2000);
        } else {
            throw new Error(verifyResponse.message || 'Payment verification failed');
        }
    } catch (error) {
        console.error('Payment verification error:', error);
        showAlert(error.message || 'Payment verification failed', 'error');
    } finally {
        hideLoading();
    }
}

function handlePaymentFailure(response) {
    console.error('Payment failed:', response);
    showAlert(
        `Payment failed: ${response.error.description || 'Unknown error'}`,
        'error'
    );
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.app = new LendConnectApp();
});

// Export global functions
window.showModal = showModal;
window.closeModal = closeModal;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.showAlert = showAlert;
window.submitForm = submitForm;
window.processPayment = processPayment;

console.log('🚀 LendConnect App loaded');
