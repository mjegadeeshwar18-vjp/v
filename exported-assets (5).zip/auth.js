// Authentication Module for LendConnect

class AuthManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuthStatus();
    }

    bindEvents() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', this.handleLogin.bind(this));
        }

        // Register form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', this.handleRegister.bind(this));
        }

        // Logout buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('logout-btn') || e.target.closest('.logout-btn')) {
                this.handleLogout();
            }
        });
    }

    async handleLogin(event) {
        event.preventDefault();

        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        if (!this.validateLoginForm(email, password)) {
            return;
        }

        try {
            showLoading();

            const response = await api.login({
                email: email.trim(),
                password: password
            });

            if (response.success) {
                // Store token and user data
                Token.set(response.token);
                User.set(response.data);

                showAlert('Login successful! Welcome back.', 'success');

                // Redirect based on user type
                setTimeout(() => {
                    this.redirectAfterLogin(response.data.userType);
                }, 1000);
            } else {
                showAlert(response.message || 'Login failed. Please try again.', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            showAlert(error.message || 'Login failed. Please check your credentials.', 'error');
        } finally {
            hideLoading();
        }
    }

    async handleRegister(event) {
        event.preventDefault();

        const formData = {
            name: document.getElementById('registerName').value.trim(),
            email: document.getElementById('registerEmail').value.trim(),
            phone: document.getElementById('registerPhone').value.trim(),
            password: document.getElementById('registerPassword').value,
            userType: document.getElementById('userType').value
        };

        if (!this.validateRegisterForm(formData)) {
            return;
        }

        try {
            showLoading();

            const response = await api.register(formData);

            if (response.success) {
                // Store token and user data
                Token.set(response.token);
                User.set(response.data);

                showAlert('Registration successful! Welcome to LendConnect.', 'success');

                // Redirect to dashboard
                setTimeout(() => {
                    this.redirectAfterLogin(response.data.userType);
                }, 1500);
            } else {
                showAlert(response.message || 'Registration failed. Please try again.', 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            showAlert(error.message || 'Registration failed. Please try again.', 'error');
        } finally {
            hideLoading();
        }
    }

    handleLogout() {
        if (confirm('Are you sure you want to logout?')) {
            Token.remove();
            User.remove();
            showAlert('You have been logged out successfully.', 'info');
            setTimeout(() => {
                window.location.href = '/';
            }, 1000);
        }
    }

    validateLoginForm(email, password) {
        if (!email || !password) {
            showAlert('Please fill in all fields.', 'error');
            return false;
        }

        if (!Validate.email(email)) {
            showAlert('Please enter a valid email address.', 'error');
            return false;
        }

        if (password.length < 6) {
            showAlert('Password must be at least 6 characters long.', 'error');
            return false;
        }

        return true;
    }

    validateRegisterForm(data) {
        const { name, email, phone, password, userType } = data;

        if (!name || !email || !phone || !password || !userType) {
            showAlert('Please fill in all fields.', 'error');
            return false;
        }

        if (name.length < 2) {
            showAlert('Name must be at least 2 characters long.', 'error');
            return false;
        }

        if (!Validate.email(email)) {
            showAlert('Please enter a valid email address.', 'error');
            return false;
        }

        if (!Validate.phone(phone)) {
            showAlert('Please enter a valid 10-digit phone number.', 'error');
            return false;
        }

        if (password.length < 6) {
            showAlert('Password must be at least 6 characters long.', 'error');
            return false;
        }

        if (!['borrower', 'lender'].includes(userType)) {
            showAlert('Please select a valid user type.', 'error');
            return false;
        }

        return true;
    }

    redirectAfterLogin(userType) {
        closeModal('loginModal');
        closeModal('registerModal');

        switch (userType) {
            case 'admin':
                window.location.href = '/pages/admin-dashboard.html';
                break;
            case 'borrower':
                window.location.href = '/pages/borrower-dashboard.html';
                break;
            case 'lender':
                window.location.href = '/pages/lender-dashboard.html';
                break;
            default:
                window.location.href = '/pages/dashboard.html';
        }
    }

    checkAuthStatus() {
        // Check if user is logged in and redirect if on login page
        if (User.isLoggedIn()) {
            const currentPage = window.location.pathname;

            // If on home page and logged in, redirect to dashboard
            if (currentPage === '/' || currentPage === '/index.html') {
                const userType = User.getRole();
                this.redirectAfterLogin(userType);
                return;
            }

            // Update navbar for logged in user
            this.updateNavbarForLoggedInUser();
        } else {
            // If on dashboard pages and not logged in, redirect to home
            const currentPage = window.location.pathname;
            if (currentPage.includes('dashboard') || currentPage.includes('pages/')) {
                window.location.href = '/';
                return;
            }
        }
    }

    updateNavbarForLoggedInUser() {
        const navActions = document.querySelector('.nav-actions');
        if (navActions && User.isLoggedIn()) {
            const userName = User.getName();
            const userType = User.getRole();

            navActions.innerHTML = `
                <div class="user-menu">
                    <span class="user-name">Welcome, ${userName}</span>
                    <div class="user-dropdown">
                        <button class="btn btn-outline" onclick="goToDashboard()">
                            <i class="fas fa-tachometer-alt"></i>
                            Dashboard
                        </button>
                        <button class="btn btn-outline logout-btn">
                            <i class="fas fa-sign-out-alt"></i>
                            Logout
                        </button>
                    </div>
                </div>
            `;
        }
    }

    async getCurrentUser() {
        if (!Token.isValid()) {
            return null;
        }

        try {
            const response = await api.getMe();
            if (response.success) {
                User.set(response.data);
                return response.data;
            }
        } catch (error) {
            console.error('Error getting current user:', error);
            Token.remove();
            User.remove();
        }

        return null;
    }

    requireAuth() {
        if (!User.isLoggedIn()) {
            showAlert('Please log in to access this feature.', 'warning');
            showLogin();
            return false;
        }
        return true;
    }

    requireKYC() {
        const user = User.get();
        if (!user || user.kycStatus !== 'approved') {
            showAlert('KYC verification is required to access this feature.', 'warning');
            return false;
        }
        return true;
    }

    requireRole(requiredRole) {
        const userRole = User.getRole();
        if (userRole !== requiredRole) {
            showAlert('You do not have permission to access this feature.', 'error');
            return false;
        }
        return true;
    }
}

// Global functions
function goToDashboard() {
    const userType = User.getRole();
    switch (userType) {
        case 'admin':
            window.location.href = '/pages/admin-dashboard.html';
            break;
        case 'borrower':
            window.location.href = '/pages/borrower-dashboard.html';
            break;
        case 'lender':
            window.location.href = '/pages/lender-dashboard.html';
            break;
        default:
            window.location.href = '/pages/dashboard.html';
    }
}

function showLogin() {
    showModal('loginModal');
}

function showRegister() {
    showModal('registerModal');
}

// Initialize auth manager
const authManager = new AuthManager();

// Export to window
window.authManager = authManager;
window.goToDashboard = goToDashboard;
window.showLogin = showLogin;
window.showRegister = showRegister;

console.log('🔐 Authentication module loaded');
