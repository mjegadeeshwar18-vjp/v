// Dashboard JavaScript for LendConnect

class Dashboard {
    constructor() {
        this.currentUser = null;
        this.currentSection = 'dashboard';
        this.init();
    }

    async init() {
        // Check authentication
        if (!User.isLoggedIn()) {
            window.location.href = '/';
            return;
        }

        try {
            await this.loadUserData();
            this.bindEvents();
            this.loadDashboardData();
            this.initializeEMICalculator();
        } catch (error) {
            console.error('Dashboard initialization error:', error);
            showAlert('Failed to load dashboard. Please try again.', 'error');
        }
    }

    async loadUserData() {
        try {
            const response = await api.getMe();
            if (response.success) {
                this.currentUser = response.data;
                User.set(response.data);
                this.updateUserInfo();
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            // If token is invalid, redirect to home
            window.location.href = '/';
        }
    }

    updateUserInfo() {
        const user = this.currentUser;

        // Update navbar user name
        const userName = document.getElementById('userName');
        if (userName) userName.textContent = `Welcome, ${user.name}`;

        // Update sidebar user info
        const sidebarUserName = document.getElementById('sidebarUserName');
        const sidebarUserType = document.getElementById('sidebarUserType');

        if (sidebarUserName) sidebarUserName.textContent = user.name;
        if (sidebarUserType) {
            sidebarUserType.textContent = user.userType.charAt(0).toUpperCase() + user.userType.slice(1);
            sidebarUserType.className = `user-type ${user.userType}`;
        }
    }

    bindEvents() {
        // Sidebar navigation
        const navItems = document.querySelectorAll('.nav-item[data-section]');
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                this.showSection(section);
            });
        });

        // Loan application form
        const loanForm = document.getElementById('loanApplicationForm');
        if (loanForm) {
            loanForm.addEventListener('submit', this.handleLoanApplication.bind(this));

            // Real-time EMI calculation
            const amountInput = document.getElementById('loanAmount');
            const tenureInput = document.getElementById('loanTenure');
            const incomeInput = document.getElementById('monthlyIncome');

            [amountInput, tenureInput, incomeInput].forEach(input => {
                if (input) {
                    input.addEventListener('input', debounce(this.calculateEMIPreview.bind(this), 500));
                    input.addEventListener('change', this.calculateEMIPreview.bind(this));
                }
            });
        }
    }

    async loadDashboardData() {
        try {
            showLoading('Loading dashboard...');

            const response = await api.getDashboard();
            if (response.success) {
                this.renderStats(response.data.stats);
                this.renderRecentTransactions(response.data.recentTransactions);
            }
        } catch (error) {
            console.error('Error loading dashboard data:', error);
            showAlert('Failed to load dashboard data', 'error');
        } finally {
            hideLoading();
        }
    }

    renderStats(stats) {
        const statsGrid = document.getElementById('statsGrid');
        if (!statsGrid || !stats) return;

        const userType = this.currentUser.userType;
        let statsHTML = '';

        if (userType === 'borrower') {
            statsHTML = `
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">Total Borrowed</span>
                        <div class="stat-icon primary">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                    </div>
                    <div class="stat-value">${Format.currency(stats.totalBorrowed || 0)}</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i>
                        Active Loans: ${stats.activeLoans || 0}
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">Outstanding Amount</span>
                        <div class="stat-icon warning">
                            <i class="fas fa-exclamation-circle"></i>
                        </div>
                    </div>
                    <div class="stat-value">${Format.currency(stats.outstandingAmount || 0)}</div>
                    <div class="stat-change">
                        Next EMI: ${stats.nextEMIDate ? Format.date(stats.nextEMIDate) : 'N/A'}
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-header">
                        <span class="stat-title">Credit Grade</span>
                        <div class="stat-icon success">
                            <i class="fas fa-star"></i>
                        </div>
                    </div>
                    <div class="stat-value">${stats.creditGrade || 'Unrated'}</div>
                    <div class="stat-change">
                        ${Credit.getDescription(stats.creditGrade || 'D')}
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">KYC Status</span>
                        <div class="stat-icon ${this.getKYCStatusClass()}">
                            <i class="fas ${this.getKYCStatusIcon()}"></i>
                        </div>
                    </div>
                    <div class="stat-value">${this.currentUser.kycStatus || 'Pending'}</div>
                    <div class="stat-change">
                        ${this.getKYCStatusMessage()}
                    </div>
                </div>
            `;
        } else if (userType === 'lender') {
            statsHTML = `
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">Total Invested</span>
                        <div class="stat-icon primary">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="stat-value">${Format.currency(stats.totalInvested || 0)}</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i>
                        Active Investments: ${stats.activeInvestments || 0}
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-header">
                        <span class="stat-title">Total Returns</span>
                        <div class="stat-icon success">
                            <i class="fas fa-coins"></i>
                        </div>
                    </div>
                    <div class="stat-value">${Format.currency(stats.totalReturns || 0)}</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i>
                        Monthly: ${Format.currency(stats.monthlyReturns || 0)}
                    </div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-header">
                        <span class="stat-title">Average Return</span>
                        <div class="stat-icon warning">
                            <i class="fas fa-percentage"></i>
                        </div>
                    </div>
                    <div class="stat-value">${Format.percentage(stats.averageReturn || 0)}%</div>
                    <div class="stat-change">
                        Portfolio Performance
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">KYC Status</span>
                        <div class="stat-icon ${this.getKYCStatusClass()}">
                            <i class="fas ${this.getKYCStatusIcon()}"></i>
                        </div>
                    </div>
                    <div class="stat-value">${this.currentUser.kycStatus || 'Pending'}</div>
                    <div class="stat-change">
                        ${this.getKYCStatusMessage()}
                    </div>
                </div>
            `;
        }

        statsGrid.innerHTML = statsHTML;
    }

    renderRecentTransactions(transactions) {
        const container = document.getElementById('recentTransactions');
        if (!container) return;

        if (!transactions || transactions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <h4>No Transactions Yet</h4>
                    <p>Your transaction history will appear here once you start using the platform.</p>
                </div>
            `;
            return;
        }

        let tableHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        `;

        transactions.forEach(transaction => {
            tableHTML += `
                <tr>
                    <td>${Format.date(transaction.createdAt)}</td>
                    <td>
                        <span class="transaction-type ${transaction.type}">
                            ${this.formatTransactionType(transaction.type)}
                        </span>
                    </td>
                    <td>${Format.currency(transaction.amount)}</td>
                    <td>
                        <span class="badge badge-${this.getStatusBadgeClass(transaction.status)}">
                            ${transaction.status}
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-outline btn-sm" onclick="viewTransaction('${transaction._id}')">
                            <i class="fas fa-eye"></i>
                            View
                        </button>
                    </td>
                </tr>
            `;
        });

        tableHTML += `
                </tbody>
            </table>
        `;

        container.innerHTML = tableHTML;
    }

    async handleLoanApplication(event) {
        event.preventDefault();

        if (!this.currentUser || this.currentUser.kycStatus !== 'approved') {
            showAlert('Please complete your KYC verification before applying for a loan.', 'warning');
            return;
        }

        const formData = new FormData(event.target);
        const loanData = {
            amount: this.parseAmount(formData.get('amount')),
            purpose: formData.get('purpose'),
            tenure: parseInt(formData.get('tenure')),
            description: formData.get('description'),
            monthlyIncome: this.parseAmount(formData.get('monthlyIncome'))
        };

        // Validate loan data
        if (!this.validateLoanData(loanData)) {
            return;
        }

        try {
            showLoading('Submitting loan application...');

            const response = await api.createLoan(loanData);

            if (response.success) {
                showAlert('Loan application submitted successfully! We will review it within 24 hours.', 'success');
                closeModal('loanApplicationModal');
                this.loadLoans(); // Refresh loans list
            } else {
                throw new Error(response.message || 'Failed to submit loan application');
            }
        } catch (error) {
            console.error('Loan application error:', error);
            showAlert(error.message || 'Failed to submit loan application', 'error');
        } finally {
            hideLoading();
        }
    }

    validateLoanData(data) {
        const { amount, purpose, tenure, description, monthlyIncome } = data;

        if (amount < APP_CONFIG.LOAN.MIN_AMOUNT || amount > APP_CONFIG.LOAN.MAX_AMOUNT) {
            showAlert(`Loan amount must be between ₹${Format.number(APP_CONFIG.LOAN.MIN_AMOUNT)} and ₹${Format.number(APP_CONFIG.LOAN.MAX_AMOUNT)}`, 'error');
            return false;
        }

        if (!purpose || purpose.trim() === '') {
            showAlert('Please select a loan purpose', 'error');
            return false;
        }

        if (tenure < APP_CONFIG.LOAN.MIN_TENURE || tenure > APP_CONFIG.LOAN.MAX_TENURE) {
            showAlert(`Loan tenure must be between ${APP_CONFIG.LOAN.MIN_TENURE} and ${APP_CONFIG.LOAN.MAX_TENURE} months`, 'error');
            return false;
        }

        if (!description || description.trim().length < 10) {
            showAlert('Please provide a detailed description (at least 10 characters)', 'error');
            return false;
        }

        if (monthlyIncome < 10000) {
            showAlert('Monthly income should be at least ₹10,000', 'error');
            return false;
        }

        return true;
    }

    calculateEMIPreview() {
        const amountStr = document.getElementById('loanAmount')?.value;
        const tenure = parseInt(document.getElementById('loanTenure')?.value);
        const incomeStr = document.getElementById('monthlyIncome')?.value;

        if (!amountStr || !tenure || !incomeStr) {
            document.getElementById('emiPreview').style.display = 'none';
            return;
        }

        const amount = this.parseAmount(amountStr);
        const income = this.parseAmount(incomeStr);

        if (amount < APP_CONFIG.LOAN.MIN_AMOUNT || !income) {
            document.getElementById('emiPreview').style.display = 'none';
            return;
        }

        // Calculate credit grade and interest rate
        const grade = Credit.getGrade(income, amount);
        const rate = Credit.getInterestRate(grade);
        const emi = EMI.calculate(amount, rate, tenure);

        // Update preview
        document.getElementById('estimatedGrade').textContent = grade;
        document.getElementById('estimatedRate').textContent = `${rate}% per annum`;
        document.getElementById('estimatedEMI').textContent = Format.currency(emi);
        document.getElementById('emiPreview').style.display = 'block';
    }

    parseAmount(amountStr) {
        if (!amountStr) return 0;
        return parseInt(amountStr.replace(/[^\d]/g, '')) || 0;
    }

    showSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`)?.classList.add('active');

        // Update content
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionName)?.classList.add('active');

        this.currentSection = sectionName;

        // Load section-specific data
        this.loadSectionData(sectionName);
    }

    async loadSectionData(section) {
        switch (section) {
            case 'loans':
                await this.loadLoans();
                break;
            case 'investments':
                await this.loadInvestments();
                break;
            case 'payments':
                await this.loadPayments();
                break;
            case 'kyc':
                await this.loadKYC();
                break;
            case 'profile':
                await this.loadProfile();
                break;
        }
    }

    async loadLoans() {
        try {
            showLoading('Loading loans...');
            const response = await api.getLoans();
            // Implementation for rendering loans
        } catch (error) {
            console.error('Error loading loans:', error);
            showAlert('Failed to load loans', 'error');
        } finally {
            hideLoading();
        }
    }

    async loadInvestments() {
        // Implementation for loading investments
    }

    async loadPayments() {
        // Implementation for loading payments
    }

    async loadKYC() {
        // Implementation for loading KYC
    }

    async loadProfile() {
        // Implementation for loading profile
    }

    initializeEMICalculator() {
        // Initialize EMI calculator if inputs exist
        const amountInput = document.getElementById('loanAmount');
        if (amountInput) {
            this.calculateEMIPreview();
        }
    }

    // Helper methods
    getKYCStatusClass() {
        const status = this.currentUser?.kycStatus || 'pending';
        return status === 'approved' ? 'success' : status === 'rejected' ? 'error' : 'warning';
    }

    getKYCStatusIcon() {
        const status = this.currentUser?.kycStatus || 'pending';
        return status === 'approved' ? 'fa-check-circle' : status === 'rejected' ? 'fa-times-circle' : 'fa-clock';
    }

    getKYCStatusMessage() {
        const status = this.currentUser?.kycStatus || 'pending';
        return status === 'approved' ? 'Verified' : status === 'rejected' ? 'Verification failed' : 'Verification pending';
    }

    formatTransactionType(type) {
        return type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    getStatusBadgeClass(status) {
        switch (status) {
            case 'completed': return 'success';
            case 'failed': return 'error';
            case 'pending': return 'warning';
            default: return 'secondary';
        }
    }
}

// Global functions
function showSection(sectionName) {
    if (window.dashboard) {
        window.dashboard.showSection(sectionName);
    }
}

function loadTransactions() {
    if (window.dashboard) {
        window.dashboard.loadDashboardData();
    }
}

function viewTransaction(transactionId) {
    // Implementation for viewing transaction details
    showAlert('Transaction details feature coming soon!', 'info');
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    window.dashboard = new Dashboard();
});

// Export functions
window.showSection = showSection;
window.loadTransactions = loadTransactions;
window.viewTransaction = viewTransaction;

console.log('📊 Dashboard module loaded');
