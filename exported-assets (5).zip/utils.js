// Utility Functions for LendConnect

/**
 * Local Storage Utilities
 */
const Storage = {
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error('Error saving to localStorage:', error);
        }
    },

    get(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Error reading from localStorage:', error);
            return defaultValue;
        }
    },

    remove(key) {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.error('Error removing from localStorage:', error);
        }
    },

    clear() {
        try {
            localStorage.clear();
        } catch (error) {
            console.error('Error clearing localStorage:', error);
        }
    }
};

/**
 * Authentication Token Management
 */
const Token = {
    set(token) {
        Storage.set('auth_token', token);
    },

    get() {
        return Storage.get('auth_token');
    },

    remove() {
        Storage.remove('auth_token');
    },

    isValid() {
        const token = this.get();
        if (!token) return false;

        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            return payload.exp > Date.now() / 1000;
        } catch (error) {
            return false;
        }
    }
};

/**
 * User Management
 */
const User = {
    set(userData) {
        Storage.set('user_data', userData);
    },

    get() {
        return Storage.get('user_data');
    },

    remove() {
        Storage.remove('user_data');
    },

    isLoggedIn() {
        return this.get() && Token.isValid();
    },

    getRole() {
        const user = this.get();
        return user ? user.userType : null;
    },

    getName() {
        const user = this.get();
        return user ? user.name : null;
    },

    getEmail() {
        const user = this.get();
        return user ? user.email : null;
    }
};

/**
 * Format Utilities
 */
const Format = {
    currency(amount, showSymbol = true) {
        const formatted = new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);

        return showSymbol ? formatted : formatted.replace('₹', '').trim();
    },

    number(number) {
        return new Intl.NumberFormat('en-IN').format(number);
    },

    percentage(value, decimals = 1) {
        return `${Number(value).toFixed(decimals)}%`;
    },

    date(date, options = {}) {
        const defaultOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        };

        return new Date(date).toLocaleDateString('en-IN', { ...defaultOptions, ...options });
    },

    dateTime(date) {
        return new Date(date).toLocaleString('en-IN');
    },

    phone(phone) {
        if (!phone) return '';
        const cleaned = phone.replace(/\D/g, '');
        if (cleaned.length === 10) {
            return `+91 ${cleaned.substring(0, 5)} ${cleaned.substring(5)}`;
        }
        return phone;
    },

    truncate(text, length = 50) {
        if (!text || text.length <= length) return text;
        return text.substring(0, length) + '...';
    }
};

/**
 * Validation Utilities
 */
const Validate = {
    email(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    phone(phone) {
        const re = /^[6-9]\d{9}$/;
        return re.test(phone.replace(/\D/g, ''));
    },

    pan(pan) {
        const re = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        return re.test(pan.toUpperCase());
    },

    aadhaar(aadhaar) {
        const cleaned = aadhaar.replace(/\D/g, '');
        return cleaned.length === 12 && /^[2-9]/.test(cleaned);
    },

    ifsc(ifsc) {
        const re = /^[A-Z]{4}0[A-Z0-9]{6}$/;
        return re.test(ifsc.toUpperCase());
    },

    amount(amount, min = 0, max = Infinity) {
        const num = parseFloat(amount);
        return !isNaN(num) && num >= min && num <= max;
    },

    required(value) {
        return value !== null && value !== undefined && value.toString().trim() !== '';
    }
};

/**
 * EMI Calculation Utilities
 */
const EMI = {
    calculate(principal, rate, tenure) {
        const monthlyRate = rate / (12 * 100);
        if (monthlyRate === 0) {
            return principal / tenure;
        }

        const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / 
                   (Math.pow(1 + monthlyRate, tenure) - 1);

        return Math.round(emi);
    },

    totalInterest(principal, rate, tenure) {
        const emi = this.calculate(principal, rate, tenure);
        return (emi * tenure) - principal;
    },

    totalAmount(principal, rate, tenure) {
        const emi = this.calculate(principal, rate, tenure);
        return emi * tenure;
    },

    schedule(principal, rate, tenure) {
        const schedule = [];
        const monthlyRate = rate / (12 * 100);
        const emi = this.calculate(principal, rate, tenure);
        let balance = principal;

        for (let i = 1; i <= tenure; i++) {
            const interestComponent = balance * monthlyRate;
            const principalComponent = emi - interestComponent;
            balance -= principalComponent;

            schedule.push({
                emiNumber: i,
                amount: Math.round(emi),
                principal: Math.round(principalComponent),
                interest: Math.round(interestComponent),
                balance: Math.max(0, Math.round(balance))
            });
        }

        return schedule;
    }
};

/**
 * Credit Grade Utilities
 */
const Credit = {
    getGrade(monthlyIncome, loanAmount) {
        if (!monthlyIncome) return 'D';

        const ratio = loanAmount / (monthlyIncome * 12);

        if (monthlyIncome >= 100000 && ratio <= 3) return 'A+';
        if (monthlyIncome >= 75000 && ratio <= 4) return 'A';
        if (monthlyIncome >= 50000 && ratio <= 5) return 'B';
        if (monthlyIncome >= 25000 && ratio <= 6) return 'C';
        return 'D';
    },

    getInterestRate(grade) {
        return APP_CONFIG.INTEREST_RATES[grade] || 16;
    },

    getDescription(grade) {
        const descriptions = {
            'A+': 'Excellent credit profile',
            'A': 'Very good credit profile',
            'B': 'Good credit profile',
            'C': 'Fair credit profile',
            'D': 'Poor credit profile'
        };
        return descriptions[grade] || 'Unknown';
    },

    getColor(grade) {
        const colors = {
            'A+': '#10b981',
            'A': '#059669',
            'B': '#f59e0b',
            'C': '#f97316',
            'D': '#ef4444'
        };
        return colors[grade] || '#6b7280';
    }
};

/**
 * File Utilities
 */
const FileUtils = {
    validateFile(file) {
        const errors = [];

        // Check file size (5MB limit)
        if (file.size > APP_CONFIG.UPLOAD.MAX_SIZE) {
            errors.push(`File size must be less than ${APP_CONFIG.UPLOAD.MAX_SIZE / (1024 * 1024)}MB`);
        }

        // Check file type
        const extension = file.name.split('.').pop().toLowerCase();
        if (!APP_CONFIG.UPLOAD.ALLOWED_TYPES.includes(extension)) {
            errors.push(`File type '${extension}' is not allowed`);
        }

        return {
            valid: errors.length === 0,
            errors
        };
    },

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';

        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
};

/**
 * URL Utilities
 */
const URL = {
    getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    },

    setQueryParam(param, value) {
        const url = new URL(window.location);
        url.searchParams.set(param, value);
        window.history.pushState({}, '', url);
    },

    removeQueryParam(param) {
        const url = new URL(window.location);
        url.searchParams.delete(param);
        window.history.pushState({}, '', url);
    }
};

/**
 * DOM Utilities
 */
const DOM = {
    show(element) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.style.display = 'block';
            element.classList.remove('hidden');
        }
    },

    hide(element) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.style.display = 'none';
            element.classList.add('hidden');
        }
    },

    toggle(element) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            if (element.style.display === 'none' || element.classList.contains('hidden')) {
                this.show(element);
            } else {
                this.hide(element);
            }
        }
    },

    addClass(element, className) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.classList.add(className);
        }
    },

    removeClass(element, className) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        if (element) {
            element.classList.remove(className);
        }
    },

    hasClass(element, className) {
        if (typeof element === 'string') {
            element = document.getElementById(element);
        }
        return element ? element.classList.contains(className) : false;
    }
};

/**
 * Device Utilities
 */
const Device = {
    isMobile() {
        return window.innerWidth <= 768;
    },

    isTablet() {
        return window.innerWidth > 768 && window.innerWidth <= 1024;
    },

    isDesktop() {
        return window.innerWidth > 1024;
    }
};

/**
 * Debounce Utility
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle Utility
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export utilities to window for global access
window.Storage = Storage;
window.Token = Token;
window.User = User;
window.Format = Format;
window.Validate = Validate;
window.EMI = EMI;
window.Credit = Credit;
window.FileUtils = FileUtils;
window.URL = URL;
window.DOM = DOM;
window.Device = Device;
window.debounce = debounce;
window.throttle = throttle;

console.log('🛠️ Utility functions loaded');
