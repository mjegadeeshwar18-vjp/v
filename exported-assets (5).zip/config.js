// API Configuration
const API_CONFIG = {
    BASE_URL: 'http://localhost:5000/api', // Change this to your deployed backend URL
    ENDPOINTS: {
        // Authentication
        REGISTER: '/auth/register',
        LOGIN: '/auth/login',
        ME: '/auth/me',
        UPDATE_PROFILE: '/auth/profile',
        CHANGE_PASSWORD: '/auth/password',

        // Users
        PERSONAL_INFO: '/users/personal-info',
        DASHBOARD: '/users/dashboard',

        // Loans
        LOANS: '/loans',
        LOAN_SCHEDULE: '/loans/{id}/schedule',

        // Investments
        INVESTMENTS: '/investments',

        // KYC
        KYC_UPLOAD: '/kyc/upload',
        KYC_INFO: '/kyc/info',
        KYC_STATUS: '/kyc/status',

        // Payments
        CREATE_EMI_ORDER: '/payments/create-emi-order',
        CREATE_INVESTMENT_ORDER: '/payments/create-investment-order',
        VERIFY_PAYMENT: '/payments/verify',
        PAYMENT_HISTORY: '/payments/history',
        PAYMENT_METHODS: '/payments/methods',

        // Bank Accounts
        BANK_ACCOUNTS: '/bank-accounts',

        // Admin
        ADMIN_DASHBOARD: '/admin/dashboard',
        ADMIN_LOANS_PENDING: '/admin/loans/pending',
        ADMIN_LOAN_REVIEW: '/admin/loans/{id}/review',
        ADMIN_KYC_PENDING: '/admin/kyc/pending',
        ADMIN_KYC_REVIEW: '/admin/kyc/{id}/review',
        ADMIN_USERS: '/admin/users'
    }
};

// Razorpay Configuration
const RAZORPAY_CONFIG = {
    KEY_ID: 'rzp_test_9WzaIvXQJKvzN4', // Replace with your Razorpay key
    OPTIONS: {
        currency: 'INR',
        name: 'LendConnect',
        description: 'P2P Lending Platform',
        image: '/images/logo.png',
        theme: {
            color: '#2563eb'
        }
    }
};

// App Configuration
const APP_CONFIG = {
    NAME: 'LendConnect',
    VERSION: '1.0.0',
    ENVIRONMENT: 'development', // 'development' or 'production'

    // Loan Configuration
    LOAN: {
        MIN_AMOUNT: 10000,
        MAX_AMOUNT: 5000000,
        MIN_TENURE: 6,
        MAX_TENURE: 60,
        PURPOSES: [
            'Business Expansion',
            'Education',
            'Home Renovation',
            'Medical Emergency',
            'Wedding',
            'Travel',
            'Debt Consolidation',
            'Personal',
            'Other'
        ]
    },

    // Investment Configuration
    INVESTMENT: {
        MIN_AMOUNT: 100,
        DEFAULT_AMOUNT: 1000
    },

    // Interest Rates by Credit Grade
    INTEREST_RATES: {
        'A+': 9,
        'A': 10,
        'B': 12,
        'C': 14,
        'D': 16
    },

    // File Upload Configuration
    UPLOAD: {
        MAX_SIZE: 5 * 1024 * 1024, // 5MB
        ALLOWED_TYPES: ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']
    },

    // Pagination
    PAGINATION: {
        DEFAULT_LIMIT: 10,
        MAX_LIMIT: 50
    }
};

// Theme Configuration
const THEME_CONFIG = {
    COLORS: {
        primary: '#2563eb',
        secondary: '#10b981',
        accent: '#f59e0b',
        error: '#ef4444',
        warning: '#f59e0b',
        success: '#10b981'
    }
};

// Export configurations
window.API_CONFIG = API_CONFIG;
window.RAZORPAY_CONFIG = RAZORPAY_CONFIG;
window.APP_CONFIG = APP_CONFIG;
window.THEME_CONFIG = THEME_CONFIG;

// Set dynamic API base URL based on environment
if (APP_CONFIG.ENVIRONMENT === 'production') {
    // Update this with your production backend URL
    API_CONFIG.BASE_URL = 'https://your-app.railway.app/api';
}

console.log('🚀 LendConnect Frontend Loaded');
console.log('📡 API Base URL:', API_CONFIG.BASE_URL);
console.log('💳 Payment Gateway:', RAZORPAY_CONFIG.KEY_ID ? 'Configured' : 'Not Configured');
