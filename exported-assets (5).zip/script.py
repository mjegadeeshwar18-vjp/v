# Create frontend directory structure
import os

# Create frontend directories
frontend_dirs = [
    'frontend',
    'frontend/css',
    'frontend/js',
    'frontend/images',
    'frontend/pages',
    'frontend/components'
]

for directory in frontend_dirs:
    os.makedirs(directory, exist_ok=True)

print("Created frontend directory structure")

# Create main index.html
index_html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LendConnect - P2P Lending Platform</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/components.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-brand">
                <i class="fas fa-handshake"></i>
                <span>LendConnect</span>
            </div>
            <div class="nav-links" id="navLinks">
                <a href="#home" class="nav-link active">Home</a>
                <a href="#about" class="nav-link">About</a>
                <a href="#features" class="nav-link">Features</a>
                <a href="#calculator" class="nav-link">Calculator</a>
                <a href="#contact" class="nav-link">Contact</a>
            </div>
            <div class="nav-actions">
                <button class="btn btn-outline" onclick="showLogin()">Login</button>
                <button class="btn btn-primary" onclick="showRegister()">Get Started</button>
            </div>
            <div class="nav-toggle" id="navToggle">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1 class="hero-title">
                        Peer-to-Peer Lending<br>
                        <span class="gradient-text">Made Simple</span>
                    </h1>
                    <p class="hero-description">
                        Connect directly with borrowers and lenders. Get loans from ₹10,000 to ₹50,00,000. 
                        Start investing from just ₹100 with competitive returns.
                    </p>
                    <div class="hero-stats">
                        <div class="stat">
                            <h3>₹10Cr+</h3>
                            <p>Loans Disbursed</p>
                        </div>
                        <div class="stat">
                            <h3>5,000+</h3>
                            <p>Happy Users</p>
                        </div>
                        <div class="stat">
                            <h3>12-18%</h3>
                            <p>Returns</p>
                        </div>
                    </div>
                    <div class="hero-actions">
                        <button class="btn btn-primary btn-large" onclick="showRegister()">
                            Start Investing
                            <i class="fas fa-arrow-right"></i>
                        </button>
                        <button class="btn btn-outline btn-large" onclick="showCalculator()">
                            Calculate EMI
                            <i class="fas fa-calculator"></i>
                        </button>
                    </div>
                </div>
                <div class="hero-image">
                    <div class="hero-card">
                        <div class="card-header">
                            <h4>Quick Loan Application</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Loan Amount</label>
                                <input type="text" placeholder="₹5,00,000" readonly>
                            </div>
                            <div class="form-group">
                                <label>Purpose</label>
                                <select disabled>
                                    <option>Business Expansion</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tenure</label>
                                <input type="text" placeholder="24 months" readonly>
                            </div>
                            <button class="btn btn-primary btn-full" disabled>
                                Apply Now - ₹23,537/month
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-header">
                <h2>Why Choose LendConnect?</h2>
                <p>Experience the future of lending with our comprehensive P2P platform</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>100% Secure</h3>
                    <p>Bank-grade security with 256-bit SSL encryption and RBI compliance</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3>Quick Approval</h3>
                    <p>Get loans approved in 24 hours with our streamlined KYC process</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3>High Returns</h3>
                    <p>Earn 12-18% annual returns on your investments with diversified portfolio</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3>Easy Payments</h3>
                    <p>Pay EMIs via UPI, cards, net banking, or wallets - all in one platform</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <div class="section-header">
                <h2>How It Works</h2>
                <p>Simple steps to get started with P2P lending</p>
            </div>
            <div class="steps-container">
                <div class="steps-nav">
                    <button class="step-tab active" data-tab="borrower">For Borrowers</button>
                    <button class="step-tab" data-tab="lender">For Lenders</button>
                </div>
                <div class="steps-content">
                    <div class="step-content active" id="borrower">
                        <div class="steps-grid">
                            <div class="step">
                                <div class="step-number">1</div>
                                <h4>Register & KYC</h4>
                                <p>Sign up and complete your KYC verification with required documents</p>
                            </div>
                            <div class="step">
                                <div class="step-number">2</div>
                                <h4>Apply for Loan</h4>
                                <p>Fill loan application with amount, purpose, and tenure details</p>
                            </div>
                            <div class="step">
                                <div class="step-number">3</div>
                                <h4>Get Approved</h4>
                                <p>Our team reviews and approves your loan within 24 hours</p>
                            </div>
                            <div class="step">
                                <div class="step-number">4</div>
                                <h4>Receive Funding</h4>
                                <p>Multiple lenders fund your loan and money is disbursed to your account</p>
                            </div>
                        </div>
                    </div>
                    <div class="step-content" id="lender">
                        <div class="steps-grid">
                            <div class="step">
                                <div class="step-number">1</div>
                                <h4>Register & KYC</h4>
                                <p>Create account and complete verification to start investing</p>
                            </div>
                            <div class="step">
                                <div class="step-number">2</div>
                                <h4>Browse Loans</h4>
                                <p>Explore available loans with different risk grades and returns</p>
                            </div>
                            <div class="step">
                                <div class="step-number">3</div>
                                <h4>Invest Wisely</h4>
                                <p>Invest starting from ₹100 across multiple loans for diversification</p>
                            </div>
                            <div class="step">
                                <div class="step-number">4</div>
                                <h4>Earn Returns</h4>
                                <p>Receive monthly returns as borrowers repay their EMIs</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- EMI Calculator Section -->
    <section id="calculator" class="calculator-section">
        <div class="container">
            <div class="calculator-content">
                <div class="calculator-info">
                    <h2>EMI Calculator</h2>
                    <p>Calculate your monthly EMI and plan your loan repayment</p>
                    <div class="calculator-features">
                        <div class="feature">
                            <i class="fas fa-check"></i>
                            <span>Accurate calculations using banking formulas</span>
                        </div>
                        <div class="feature">
                            <i class="fas fa-check"></i>
                            <span>Interest rates based on credit grades</span>
                        </div>
                        <div class="feature">
                            <i class="fas fa-check"></i>
                            <span>Flexible tenure options</span>
                        </div>
                    </div>
                </div>
                <div class="calculator-widget">
                    <div class="calculator-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Loan Amount (₹)</label>
                                <input type="number" id="loanAmount" placeholder="5,00,000" min="10000" max="5000000">
                                <div class="range-info">
                                    <span>₹10K</span>
                                    <span>₹50L</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Interest Rate (%)</label>
                                <input type="number" id="interestRate" placeholder="12" step="0.1" min="8" max="24">
                                <div class="range-info">
                                    <span>8%</span>
                                    <span>24%</span>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Loan Tenure (Months)</label>
                                <input type="number" id="loanTenure" placeholder="24" min="6" max="60">
                                <div class="range-info">
                                    <span>6 months</span>
                                    <span>60 months</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Credit Grade</label>
                                <select id="creditGrade">
                                    <option value="A+">A+ (9%)</option>
                                    <option value="A" selected>A (10%)</option>
                                    <option value="B">B (12%)</option>
                                    <option value="C">C (14%)</option>
                                    <option value="D">D (16%)</option>
                                </select>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-full" onclick="calculateEMI()">
                            Calculate EMI
                        </button>
                    </div>
                    <div class="calculator-result" id="calculatorResult">
                        <div class="result-item">
                            <span class="label">Monthly EMI</span>
                            <span class="value" id="emiAmount">₹23,537</span>
                        </div>
                        <div class="result-item">
                            <span class="label">Total Interest</span>
                            <span class="value" id="totalInterest">₹1,64,888</span>
                        </div>
                        <div class="result-item">
                            <span class="label">Total Amount</span>
                            <span class="value" id="totalAmount">₹5,64,888</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-brand">
                        <i class="fas fa-handshake"></i>
                        <span>LendConnect</span>
                    </div>
                    <p>Connecting borrowers and lenders directly with secure, transparent, and efficient P2P lending solutions.</p>
                    <div class="footer-social">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>For Borrowers</h4>
                    <ul>
                        <li><a href="#" onclick="showRegister()">Apply for Loan</a></li>
                        <li><a href="#calculator">EMI Calculator</a></li>
                        <li><a href="#how-it-works">How It Works</a></li>
                        <li><a href="#">Eligibility</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>For Lenders</h4>
                    <ul>
                        <li><a href="#" onclick="showRegister()">Start Investing</a></li>
                        <li><a href="#">Investment Guide</a></li>
                        <li><a href="#">Risk Assessment</a></li>
                        <li><a href="#">Returns Calculator</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="footer-info">
                    <p>&copy; 2024 LendConnect P2P Lending Platform. All rights reserved.</p>
                    <p><strong>Created by:</strong> Vallavan Jegadeeshwar Pazhaniponmanikkavel Vishwa | <strong>Mentor:</strong> Prof. Rajamani</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Modals -->
    <!-- Login Modal -->
    <div class="modal" id="loginModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Welcome Back</h3>
                <button class="modal-close" onclick="closeModal('loginModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="loginForm">
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" id="loginEmail" placeholder="Enter your email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="loginPassword" placeholder="Enter your password" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-full">
                            <i class="fas fa-sign-in-alt"></i>
                            Login
                        </button>
                    </div>
                    <div class="form-footer">
                        <p>Don't have an account? <a href="#" onclick="showRegister()">Register here</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Register Modal -->
    <div class="modal" id="registerModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create Your Account</h3>
                <button class="modal-close" onclick="closeModal('registerModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="registerForm">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" id="registerName" placeholder="Enter your full name" required>
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="tel" id="registerPhone" placeholder="10-digit mobile number" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" id="registerEmail" placeholder="Enter your email" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" id="registerPassword" placeholder="Create password" required>
                        </div>
                        <div class="form-group">
                            <label>User Type</label>
                            <select id="userType" required>
                                <option value="">Select type</option>
                                <option value="borrower">Borrower (Need Loan)</option>
                                <option value="lender">Lender (Want to Invest)</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-full">
                            <i class="fas fa-user-plus"></i>
                            Create Account
                        </button>
                    </div>
                    <div class="form-footer">
                        <p>Already have an account? <a href="#" onclick="showLogin()">Login here</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading...</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="js/config.js"></script>
    <script src="js/utils.js"></script>
    <script src="js/api.js"></script>
    <script src="js/auth.js"></script>
    <script src="js/calculator.js"></script>
    <script src="js/main.js"></script>
</body>
</html>'''

with open('frontend/index.html', 'w') as f:
    f.write(index_html)

print("Created frontend/index.html - Main landing page")

# Create CSS files
main_css = '''/* Root Variables */
:root {
    /* Colors */
    --primary-color: #2563eb;
    --primary-dark: #1d4ed8;
    --secondary-color: #10b981;
    --accent-color: #f59e0b;
    --error-color: #ef4444;
    --success-color: #10b981;
    --warning-color: #f59e0b;
    
    /* Neutrals */
    --white: #ffffff;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;
    
    /* Typography */
    --font-primary: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    --font-weight-normal: 400;
    --font-weight-medium: 500;
    --font-weight-semibold: 600;
    --font-weight-bold: 700;
    
    /* Spacing */
    --spacing-xs: 0.5rem;
    --spacing-sm: 0.75rem;
    --spacing-md: 1rem;
    --spacing-lg: 1.5rem;
    --spacing-xl: 2rem;
    --spacing-2xl: 3rem;
    --spacing-3xl: 4rem;
    
    /* Borders */
    --border-radius-sm: 0.375rem;
    --border-radius-md: 0.5rem;
    --border-radius-lg: 0.75rem;
    --border-radius-xl: 1rem;
    
    /* Shadows */
    --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    
    /* Transitions */
    --transition-base: all 0.2s ease-in-out;
    --transition-slow: all 0.3s ease-in-out;
    
    /* Breakpoints */
    --breakpoint-sm: 640px;
    --breakpoint-md: 768px;
    --breakpoint-lg: 1024px;
    --breakpoint-xl: 1280px;
}

/* Reset & Base */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: var(--font-primary);
    font-size: 1rem;
    line-height: 1.6;
    color: var(--gray-700);
    background-color: var(--white);
    overflow-x: hidden;
}

/* Container */
.container {
    max-width: 1280px;
    margin: 0 auto;
    padding: 0 var(--spacing-md);
}

@media (min-width: 640px) {
    .container {
        padding: 0 var(--spacing-lg);
    }
}

/* Typography */
h1, h2, h3, h4, h5, h6 {
    font-weight: var(--font-weight-bold);
    line-height: 1.2;
    color: var(--gray-900);
}

h1 { font-size: 3rem; }
h2 { font-size: 2.5rem; }
h3 { font-size: 2rem; }
h4 { font-size: 1.5rem; }
h5 { font-size: 1.25rem; }
h6 { font-size: 1.125rem; }

@media (max-width: 768px) {
    h1 { font-size: 2.5rem; }
    h2 { font-size: 2rem; }
    h3 { font-size: 1.75rem; }
}

.gradient-text {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Navigation */
.navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid var(--gray-200);
    z-index: 1000;
    transition: var(--transition-base);
}

.navbar .container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--spacing-md) var(--spacing-lg);
}

.nav-brand {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    font-size: 1.5rem;
    font-weight: var(--font-weight-bold);
    color: var(--primary-color);
    text-decoration: none;
}

.nav-links {
    display: flex;
    align-items: center;
    gap: var(--spacing-xl);
}

.nav-link {
    text-decoration: none;
    color: var(--gray-600);
    font-weight: var(--font-weight-medium);
    transition: var(--transition-base);
    position: relative;
}

.nav-link:hover,
.nav-link.active {
    color: var(--primary-color);
}

.nav-link.active::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 0;
    right: 0;
    height: 2px;
    background: var(--primary-color);
    border-radius: 1px;
}

.nav-actions {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
}

.nav-toggle {
    display: none;
    font-size: 1.5rem;
    color: var(--gray-700);
    cursor: pointer;
}

@media (max-width: 1024px) {
    .nav-links,
    .nav-actions {
        display: none;
    }
    
    .nav-toggle {
        display: block;
    }
}

/* Buttons */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--spacing-sm);
    padding: var(--spacing-sm) var(--spacing-lg);
    font-family: inherit;
    font-size: 0.875rem;
    font-weight: var(--font-weight-medium);
    text-decoration: none;
    border: none;
    border-radius: var(--border-radius-lg);
    cursor: pointer;
    transition: var(--transition-base);
    white-space: nowrap;
}

.btn-primary {
    background: var(--primary-color);
    color: var(--white);
    box-shadow: var(--shadow-sm);
}

.btn-primary:hover {
    background: var(--primary-dark);
    box-shadow: var(--shadow-md);
    transform: translateY(-1px);
}

.btn-outline {
    background: transparent;
    color: var(--primary-color);
    border: 2px solid var(--primary-color);
}

.btn-outline:hover {
    background: var(--primary-color);
    color: var(--white);
}

.btn-large {
    padding: var(--spacing-lg) var(--spacing-2xl);
    font-size: 1rem;
}

.btn-full {
    width: 100%;
}

.btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

/* Hero Section */
.hero {
    padding: 120px 0 80px;
    background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    position: relative;
    overflow: hidden;
}

.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="%23e2e8f0"/><circle cx="80" cy="80" r="2" fill="%23e2e8f0"/></svg>') repeat;
    opacity: 0.5;
}

.hero-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--spacing-3xl);
    align-items: center;
    position: relative;
    z-index: 1;
}

.hero-title {
    font-size: 3.5rem;
    line-height: 1.1;
    margin-bottom: var(--spacing-lg);
}

.hero-description {
    font-size: 1.25rem;
    color: var(--gray-600);
    margin-bottom: var(--spacing-2xl);
}

.hero-stats {
    display: flex;
    gap: var(--spacing-2xl);
    margin-bottom: var(--spacing-2xl);
}

.stat {
    text-align: left;
}

.stat h3 {
    font-size: 2rem;
    color: var(--primary-color);
    margin-bottom: var(--spacing-xs);
}

.stat p {
    color: var(--gray-600);
    font-size: 0.875rem;
}

.hero-actions {
    display: flex;
    gap: var(--spacing-lg);
    flex-wrap: wrap;
}

.hero-image {
    display: flex;
    justify-content: center;
    align-items: center;
}

.hero-card {
    background: var(--white);
    border-radius: var(--border-radius-xl);
    box-shadow: var(--shadow-xl);
    padding: var(--spacing-2xl);
    width: 100%;
    max-width: 400px;
}

.hero-card .card-header {
    margin-bottom: var(--spacing-lg);
}

.hero-card .card-header h4 {
    color: var(--gray-900);
}

@media (max-width: 1024px) {
    .hero-content {
        grid-template-columns: 1fr;
        gap: var(--spacing-2xl);
        text-align: center;
    }
    
    .hero-title {
        font-size: 3rem;
    }
    
    .hero-stats {
        justify-content: center;
    }
}

@media (max-width: 640px) {
    .hero {
        padding: 100px 0 60px;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-description {
        font-size: 1.125rem;
    }
    
    .hero-stats {
        flex-direction: column;
        gap: var(--spacing-lg);
        text-align: center;
    }
    
    .hero-actions {
        justify-content: center;
    }
}

/* Features Section */
.features {
    padding: 80px 0;
    background: var(--white);
}

.section-header {
    text-align: center;
    margin-bottom: var(--spacing-3xl);
}

.section-header h2 {
    margin-bottom: var(--spacing-md);
}

.section-header p {
    font-size: 1.125rem;
    color: var(--gray-600);
    max-width: 600px;
    margin: 0 auto;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: var(--spacing-2xl);
}

.feature-card {
    text-align: center;
    padding: var(--spacing-2xl);
    border-radius: var(--border-radius-xl);
    background: var(--gray-50);
    transition: var(--transition-base);
}

.feature-card:hover {
    background: var(--white);
    box-shadow: var(--shadow-lg);
    transform: translateY(-4px);
}

.feature-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto var(--spacing-lg);
    font-size: 2rem;
    color: var(--white);
}

.feature-card h3 {
    margin-bottom: var(--spacing-md);
    color: var(--gray-900);
}

.feature-card p {
    color: var(--gray-600);
    line-height: 1.6;
}

/* How It Works Section */
.how-it-works {
    padding: 80px 0;
    background: var(--gray-50);
}

.steps-container {
    max-width: 800px;
    margin: 0 auto;
}

.steps-nav {
    display: flex;
    justify-content: center;
    margin-bottom: var(--spacing-2xl);
    background: var(--white);
    border-radius: var(--border-radius-lg);
    padding: var(--spacing-xs);
    box-shadow: var(--shadow-sm);
}

.step-tab {
    flex: 1;
    padding: var(--spacing-md) var(--spacing-lg);
    background: transparent;
    border: none;
    border-radius: var(--border-radius-md);
    font-weight: var(--font-weight-medium);
    color: var(--gray-600);
    cursor: pointer;
    transition: var(--transition-base);
}

.step-tab.active {
    background: var(--primary-color);
    color: var(--white);
}

.step-content {
    display: none;
}

.step-content.active {
    display: block;
}

.steps-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: var(--spacing-2xl);
}

.step {
    text-align: center;
    padding: var(--spacing-lg);
}

.step-number {
    width: 60px;
    height: 60px;
    background: var(--primary-color);
    color: var(--white);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: var(--font-weight-bold);
    margin: 0 auto var(--spacing-lg);
}

.step h4 {
    margin-bottom: var(--spacing-md);
    color: var(--gray-900);
}

.step p {
    color: var(--gray-600);
    line-height: 1.6;
}

/* Calculator Section */
.calculator-section {
    padding: 80px 0;
    background: var(--white);
}

.calculator-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--spacing-3xl);
    align-items: center;
}

.calculator-info h2 {
    margin-bottom: var(--spacing-lg);
}

.calculator-info p {
    font-size: 1.125rem;
    color: var(--gray-600);
    margin-bottom: var(--spacing-2xl);
}

.calculator-features {
    space-y: var(--spacing-md);
}

.feature {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    margin-bottom: var(--spacing-md);
}

.feature i {
    color: var(--secondary-color);
    font-size: 1.125rem;
}

.calculator-widget {
    background: var(--white);
    border-radius: var(--border-radius-xl);
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.calculator-form {
    padding: var(--spacing-2xl);
}

.calculator-result {
    background: var(--gray-50);
    padding: var(--spacing-2xl);
    border-top: 1px solid var(--gray-200);
}

.result-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--spacing-md) 0;
    border-bottom: 1px solid var(--gray-200);
}

.result-item:last-child {
    border-bottom: none;
}

.result-item .label {
    color: var(--gray-600);
    font-weight: var(--font-weight-medium);
}

.result-item .value {
    font-size: 1.25rem;
    font-weight: var(--font-weight-bold);
    color: var(--primary-color);
}

@media (max-width: 1024px) {
    .calculator-content {
        grid-template-columns: 1fr;
        gap: var(--spacing-2xl);
    }
}

/* Forms */
.form-group {
    margin-bottom: var(--spacing-lg);
}

.form-group label {
    display: block;
    margin-bottom: var(--spacing-sm);
    font-weight: var(--font-weight-medium);
    color: var(--gray-700);
}

.form-group input,
.form-group select {
    width: 100%;
    padding: var(--spacing-md);
    border: 2px solid var(--gray-200);
    border-radius: var(--border-radius-md);
    font-size: 1rem;
    transition: var(--transition-base);
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--spacing-lg);
}

@media (max-width: 640px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

.range-info {
    display: flex;
    justify-content: space-between;
    margin-top: var(--spacing-xs);
    font-size: 0.875rem;
    color: var(--gray-500);
}

/* Footer */
.footer {
    background: var(--gray-900);
    color: var(--gray-300);
    padding: 60px 0 30px;
}

.footer-content {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr;
    gap: var(--spacing-2xl);
    margin-bottom: var(--spacing-2xl);
}

.footer-brand {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    font-size: 1.5rem;
    font-weight: var(--font-weight-bold);
    color: var(--white);
    margin-bottom: var(--spacing-lg);
}

.footer-section p {
    margin-bottom: var(--spacing-lg);
    line-height: 1.6;
}

.footer-social {
    display: flex;
    gap: var(--spacing-md);
}

.footer-social a {
    width: 40px;
    height: 40px;
    background: var(--gray-800);
    color: var(--gray-400);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition-base);
}

.footer-social a:hover {
    background: var(--primary-color);
    color: var(--white);
    transform: translateY(-2px);
}

.footer-section h4 {
    color: var(--white);
    margin-bottom: var(--spacing-lg);
}

.footer-section ul {
    list-style: none;
}

.footer-section ul li {
    margin-bottom: var(--spacing-sm);
}

.footer-section ul li a {
    color: var(--gray-300);
    text-decoration: none;
    transition: var(--transition-base);
}

.footer-section ul li a:hover {
    color: var(--white);
}

.footer-bottom {
    padding-top: var(--spacing-lg);
    border-top: 1px solid var(--gray-800);
    text-align: center;
}

.footer-info p {
    margin-bottom: var(--spacing-sm);
    color: var(--gray-400);
}

@media (max-width: 1024px) {
    .footer-content {
        grid-template-columns: 1fr 1fr;
        gap: var(--spacing-xl);
    }
}

@media (max-width: 640px) {
    .footer-content {
        grid-template-columns: 1fr;
        text-align: center;
    }
}

/* Utilities */
.text-center { text-align: center; }
.text-left { text-align: left; }
.text-right { text-align: right; }

.hidden { display: none; }
.visible { display: block; }

.mt-0 { margin-top: 0; }
.mt-1 { margin-top: var(--spacing-xs); }
.mt-2 { margin-top: var(--spacing-sm); }
.mt-3 { margin-top: var(--spacing-md); }
.mt-4 { margin-top: var(--spacing-lg); }

.mb-0 { margin-bottom: 0; }
.mb-1 { margin-bottom: var(--spacing-xs); }
.mb-2 { margin-bottom: var(--spacing-sm); }
.mb-3 { margin-bottom: var(--spacing-md); }
.mb-4 { margin-bottom: var(--spacing-lg); }

.p-0 { padding: 0; }
.p-1 { padding: var(--spacing-xs); }
.p-2 { padding: var(--spacing-sm); }
.p-3 { padding: var(--spacing-md); }
.p-4 { padding: var(--spacing-lg); }

/* Responsive */
@media (max-width: 1024px) {
    .container {
        padding: 0 var(--spacing-md);
    }
}

@media (max-width: 640px) {
    .container {
        padding: 0 var(--spacing-sm);
    }
    
    .btn-large {
        padding: var(--spacing-md) var(--spacing-lg);
        font-size: 0.875rem;
    }
}
'''

with open('frontend/css/main.css', 'w') as f:
    f.write(main_css)

print("Created frontend/css/main.css - Main stylesheet")