# Create API service
api_js = '''// API Service for LendConnect

class ApiService {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        this.endpoints = API_CONFIG.ENDPOINTS;
    }

    /**
     * Make HTTP request with authentication
     */
    async request(url, options = {}) {
        const token = Token.get();
        
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        // Add authentication header if token exists
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        // Convert body to JSON if it's an object
        if (config.body && typeof config.body === 'object' && !(config.body instanceof FormData)) {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(`${this.baseURL}${url}`, config);
            
            // Handle token expiration
            if (response.status === 401) {
                Token.remove();
                User.remove();
                window.location.href = '/';
                return;
            }

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('API Request failed:', error);
            throw error;
        }
    }

    /**
     * GET request
     */
    async get(url, params = {}) {
        const searchParams = new URLSearchParams(params);
        const queryString = searchParams.toString();
        const fullUrl = queryString ? `${url}?${queryString}` : url;
        
        return this.request(fullUrl, {
            method: 'GET'
        });
    }

    /**
     * POST request
     */
    async post(url, data = {}) {
        return this.request(url, {
            method: 'POST',
            body: data
        });
    }

    /**
     * PUT request
     */
    async put(url, data = {}) {
        return this.request(url, {
            method: 'PUT',
            body: data
        });
    }

    /**
     * DELETE request
     */
    async delete(url) {
        return this.request(url, {
            method: 'DELETE'
        });
    }

    /**
     * Upload file
     */
    async upload(url, formData) {
        const token = Token.get();
        
        const config = {
            method: 'POST',
            body: formData,
            headers: {}
        };

        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        try {
            const response = await fetch(`${this.baseURL}${url}`, config);
            
            if (response.status === 401) {
                Token.remove();
                User.remove();
                window.location.href = '/';
                return;
            }

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('Upload failed:', error);
            throw error;
        }
    }

    // Authentication APIs
    async register(userData) {
        return this.post(this.endpoints.REGISTER, userData);
    }

    async login(credentials) {
        return this.post(this.endpoints.LOGIN, credentials);
    }

    async getMe() {
        return this.get(this.endpoints.ME);
    }

    async updateProfile(userData) {
        return this.put(this.endpoints.UPDATE_PROFILE, userData);
    }

    async changePassword(passwordData) {
        return this.put(this.endpoints.CHANGE_PASSWORD, passwordData);
    }

    // User APIs
    async updatePersonalInfo(personalInfo) {
        return this.put(this.endpoints.PERSONAL_INFO, personalInfo);
    }

    async getDashboard() {
        return this.get(this.endpoints.DASHBOARD);
    }

    // Loan APIs
    async createLoan(loanData) {
        return this.post(this.endpoints.LOANS, loanData);
    }

    async getLoans(params = {}) {
        return this.get(this.endpoints.LOANS, params);
    }

    async getLoan(id) {
        return this.get(this.endpoints.LOANS + `/${id}`);
    }

    async getLoanSchedule(id) {
        const url = this.endpoints.LOAN_SCHEDULE.replace('{id}', id);
        return this.get(url);
    }

    // Investment APIs
    async createInvestment(investmentData) {
        return this.post(this.endpoints.INVESTMENTS, investmentData);
    }

    async getInvestments(params = {}) {
        return this.get(this.endpoints.INVESTMENTS, params);
    }

    async getInvestment(id) {
        return this.get(this.endpoints.INVESTMENTS + `/${id}`);
    }

    // KYC APIs
    async uploadKYC(formData) {
        return this.upload(this.endpoints.KYC_UPLOAD, formData);
    }

    async updateKYCInfo(kycData) {
        return this.put(this.endpoints.KYC_INFO, kycData);
    }

    async getKYCStatus() {
        return this.get(this.endpoints.KYC_STATUS);
    }

    // Payment APIs
    async createEMIOrder(paymentData) {
        return this.post(this.endpoints.CREATE_EMI_ORDER, paymentData);
    }

    async createInvestmentOrder(paymentData) {
        return this.post(this.endpoints.CREATE_INVESTMENT_ORDER, paymentData);
    }

    async verifyPayment(paymentData) {
        return this.post(this.endpoints.VERIFY_PAYMENT, paymentData);
    }

    async getPaymentHistory(params = {}) {
        return this.get(this.endpoints.PAYMENT_HISTORY, params);
    }

    async getPaymentMethods() {
        return this.get(this.endpoints.PAYMENT_METHODS);
    }

    // Bank Account APIs
    async addBankAccount(bankData) {
        return this.post(this.endpoints.BANK_ACCOUNTS, bankData);
    }

    async getBankAccounts() {
        return this.get(this.endpoints.BANK_ACCOUNTS);
    }

    async updateBankAccount(id, bankData) {
        return this.put(this.endpoints.BANK_ACCOUNTS + `/${id}`, bankData);
    }

    async deleteBankAccount(id) {
        return this.delete(this.endpoints.BANK_ACCOUNTS + `/${id}`);
    }

    // Admin APIs
    async getAdminDashboard() {
        return this.get(this.endpoints.ADMIN_DASHBOARD);
    }

    async getPendingLoans() {
        return this.get(this.endpoints.ADMIN_LOANS_PENDING);
    }

    async reviewLoan(id, reviewData) {
        const url = this.endpoints.ADMIN_LOAN_REVIEW.replace('{id}', id);
        return this.put(url, reviewData);
    }

    async getPendingKYC() {
        return this.get(this.endpoints.ADMIN_KYC_PENDING);
    }

    async reviewKYC(id, reviewData) {
        const url = this.endpoints.ADMIN_KYC_REVIEW.replace('{id}', id);
        return this.put(url, reviewData);
    }

    async getUsers(params = {}) {
        return this.get(this.endpoints.ADMIN_USERS, params);
    }
}

// Create global API instance
const api = new ApiService();

// Export to window for global access
window.api = api;
window.ApiService = ApiService;

console.log('🌐 API Service loaded');
'''

with open('frontend/js/api.js', 'w') as f:
    f.write(api_js)

# Create authentication module
auth_js = '''// Authentication Module for LendConnect

class AuthManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuthStatus();
    }

    bindEvents() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', this.handleLogin.bind(this));
        }

        // Register form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', this.handleRegister.bind(this));
        }

        // Logout buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('logout-btn') || e.target.closest('.logout-btn')) {
                this.handleLogout();
            }
        });
    }

    async handleLogin(event) {
        event.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        if (!this.validateLoginForm(email, password)) {
            return;
        }

        try {
            showLoading();
            
            const response = await api.login({
                email: email.trim(),
                password: password
            });

            if (response.success) {
                // Store token and user data
                Token.set(response.token);
                User.set(response.data);

                showAlert('Login successful! Welcome back.', 'success');
                
                // Redirect based on user type
                setTimeout(() => {
                    this.redirectAfterLogin(response.data.userType);
                }, 1000);
            } else {
                showAlert(response.message || 'Login failed. Please try again.', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            showAlert(error.message || 'Login failed. Please check your credentials.', 'error');
        } finally {
            hideLoading();
        }
    }

    async handleRegister(event) {
        event.preventDefault();
        
        const formData = {
            name: document.getElementById('registerName').value.trim(),
            email: document.getElementById('registerEmail').value.trim(),
            phone: document.getElementById('registerPhone').value.trim(),
            password: document.getElementById('registerPassword').value,
            userType: document.getElementById('userType').value
        };

        if (!this.validateRegisterForm(formData)) {
            return;
        }

        try {
            showLoading();
            
            const response = await api.register(formData);

            if (response.success) {
                // Store token and user data
                Token.set(response.token);
                User.set(response.data);

                showAlert('Registration successful! Welcome to LendConnect.', 'success');
                
                // Redirect to dashboard
                setTimeout(() => {
                    this.redirectAfterLogin(response.data.userType);
                }, 1500);
            } else {
                showAlert(response.message || 'Registration failed. Please try again.', 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            showAlert(error.message || 'Registration failed. Please try again.', 'error');
        } finally {
            hideLoading();
        }
    }

    handleLogout() {
        if (confirm('Are you sure you want to logout?')) {
            Token.remove();
            User.remove();
            showAlert('You have been logged out successfully.', 'info');
            setTimeout(() => {
                window.location.href = '/';
            }, 1000);
        }
    }

    validateLoginForm(email, password) {
        if (!email || !password) {
            showAlert('Please fill in all fields.', 'error');
            return false;
        }

        if (!Validate.email(email)) {
            showAlert('Please enter a valid email address.', 'error');
            return false;
        }

        if (password.length < 6) {
            showAlert('Password must be at least 6 characters long.', 'error');
            return false;
        }

        return true;
    }

    validateRegisterForm(data) {
        const { name, email, phone, password, userType } = data;

        if (!name || !email || !phone || !password || !userType) {
            showAlert('Please fill in all fields.', 'error');
            return false;
        }

        if (name.length < 2) {
            showAlert('Name must be at least 2 characters long.', 'error');
            return false;
        }

        if (!Validate.email(email)) {
            showAlert('Please enter a valid email address.', 'error');
            return false;
        }

        if (!Validate.phone(phone)) {
            showAlert('Please enter a valid 10-digit phone number.', 'error');
            return false;
        }

        if (password.length < 6) {
            showAlert('Password must be at least 6 characters long.', 'error');
            return false;
        }

        if (!['borrower', 'lender'].includes(userType)) {
            showAlert('Please select a valid user type.', 'error');
            return false;
        }

        return true;
    }

    redirectAfterLogin(userType) {
        closeModal('loginModal');
        closeModal('registerModal');

        switch (userType) {
            case 'admin':
                window.location.href = '/pages/admin-dashboard.html';
                break;
            case 'borrower':
                window.location.href = '/pages/borrower-dashboard.html';
                break;
            case 'lender':
                window.location.href = '/pages/lender-dashboard.html';
                break;
            default:
                window.location.href = '/pages/dashboard.html';
        }
    }

    checkAuthStatus() {
        // Check if user is logged in and redirect if on login page
        if (User.isLoggedIn()) {
            const currentPage = window.location.pathname;
            
            // If on home page and logged in, redirect to dashboard
            if (currentPage === '/' || currentPage === '/index.html') {
                const userType = User.getRole();
                this.redirectAfterLogin(userType);
                return;
            }

            // Update navbar for logged in user
            this.updateNavbarForLoggedInUser();
        } else {
            // If on dashboard pages and not logged in, redirect to home
            const currentPage = window.location.pathname;
            if (currentPage.includes('dashboard') || currentPage.includes('pages/')) {
                window.location.href = '/';
                return;
            }
        }
    }

    updateNavbarForLoggedInUser() {
        const navActions = document.querySelector('.nav-actions');
        if (navActions && User.isLoggedIn()) {
            const userName = User.getName();
            const userType = User.getRole();
            
            navActions.innerHTML = `
                <div class="user-menu">
                    <span class="user-name">Welcome, ${userName}</span>
                    <div class="user-dropdown">
                        <button class="btn btn-outline" onclick="goToDashboard()">
                            <i class="fas fa-tachometer-alt"></i>
                            Dashboard
                        </button>
                        <button class="btn btn-outline logout-btn">
                            <i class="fas fa-sign-out-alt"></i>
                            Logout
                        </button>
                    </div>
                </div>
            `;
        }
    }

    async getCurrentUser() {
        if (!Token.isValid()) {
            return null;
        }

        try {
            const response = await api.getMe();
            if (response.success) {
                User.set(response.data);
                return response.data;
            }
        } catch (error) {
            console.error('Error getting current user:', error);
            Token.remove();
            User.remove();
        }
        
        return null;
    }

    requireAuth() {
        if (!User.isLoggedIn()) {
            showAlert('Please log in to access this feature.', 'warning');
            showLogin();
            return false;
        }
        return true;
    }

    requireKYC() {
        const user = User.get();
        if (!user || user.kycStatus !== 'approved') {
            showAlert('KYC verification is required to access this feature.', 'warning');
            return false;
        }
        return true;
    }

    requireRole(requiredRole) {
        const userRole = User.getRole();
        if (userRole !== requiredRole) {
            showAlert('You do not have permission to access this feature.', 'error');
            return false;
        }
        return true;
    }
}

// Global functions
function goToDashboard() {
    const userType = User.getRole();
    switch (userType) {
        case 'admin':
            window.location.href = '/pages/admin-dashboard.html';
            break;
        case 'borrower':
            window.location.href = '/pages/borrower-dashboard.html';
            break;
        case 'lender':
            window.location.href = '/pages/lender-dashboard.html';
            break;
        default:
            window.location.href = '/pages/dashboard.html';
    }
}

function showLogin() {
    showModal('loginModal');
}

function showRegister() {
    showModal('registerModal');
}

// Initialize auth manager
const authManager = new AuthManager();

// Export to window
window.authManager = authManager;
window.goToDashboard = goToDashboard;
window.showLogin = showLogin;
window.showRegister = showRegister;

console.log('🔐 Authentication module loaded');
'''

with open('frontend/js/auth.js', 'w') as f:
    f.write(auth_js)

# Create calculator module
calculator_js = '''// EMI Calculator Module for LendConnect

class EMICalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.setupDefaults();
    }

    bindEvents() {
        // Calculator form inputs
        const inputs = ['loanAmount', 'interestRate', 'loanTenure', 'creditGrade'];
        inputs.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('input', debounce(this.updateCalculation.bind(this), 300));
                element.addEventListener('change', this.updateCalculation.bind(this));
            }
        });

        // Credit grade change updates interest rate
        const creditGrade = document.getElementById('creditGrade');
        if (creditGrade) {
            creditGrade.addEventListener('change', this.updateInterestRate.bind(this));
        }

        // Format number inputs
        const amountInput = document.getElementById('loanAmount');
        if (amountInput) {
            amountInput.addEventListener('input', this.formatAmountInput.bind(this));
        }
    }

    setupDefaults() {
        // Set default values
        this.setDefaultValues();
        
        // Calculate with defaults
        setTimeout(() => {
            this.updateCalculation();
        }, 100);
    }

    setDefaultValues() {
        const defaults = {
            loanAmount: 500000,
            interestRate: 10,
            loanTenure: 24,
            creditGrade: 'A'
        };

        Object.keys(defaults).forEach(key => {
            const element = document.getElementById(key);
            if (element && !element.value) {
                element.value = defaults[key];
            }
        });
    }

    updateInterestRate() {
        const creditGrade = document.getElementById('creditGrade').value;
        const interestRateInput = document.getElementById('interestRate');
        
        if (creditGrade && interestRateInput) {
            const rate = Credit.getInterestRate(creditGrade);
            interestRateInput.value = rate;
            this.updateCalculation();
        }
    }

    formatAmountInput(event) {
        const input = event.target;
        let value = input.value.replace(/,/g, '');
        
        if (!isNaN(value) && value !== '') {
            const num = parseInt(value);
            if (num >= 0) {
                input.value = Format.number(num);
            }
        }
    }

    updateCalculation() {
        const loanAmount = this.parseAmount(document.getElementById('loanAmount')?.value);
        const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
        const loanTenure = parseInt(document.getElementById('loanTenure')?.value) || 0;

        // Validate inputs
        if (!this.validateInputs(loanAmount, interestRate, loanTenure)) {
            this.clearResults();
            return;
        }

        // Calculate EMI
        const emi = EMI.calculate(loanAmount, interestRate, loanTenure);
        const totalInterest = EMI.totalInterest(loanAmount, interestRate, loanTenure);
        const totalAmount = EMI.totalAmount(loanAmount, interestRate, loanTenure);

        // Update display
        this.displayResults({
            emi,
            totalInterest,
            totalAmount,
            loanAmount,
            interestRate,
            loanTenure
        });

        // Update progress indicators if they exist
        this.updateProgressIndicators(loanAmount, interestRate, loanTenure);
    }

    parseAmount(amountStr) {
        if (!amountStr) return 0;
        return parseInt(amountStr.replace(/,/g, '')) || 0;
    }

    validateInputs(amount, rate, tenure) {
        return (
            amount >= APP_CONFIG.LOAN.MIN_AMOUNT &&
            amount <= APP_CONFIG.LOAN.MAX_AMOUNT &&
            rate > 0 && rate <= 30 &&
            tenure >= APP_CONFIG.LOAN.MIN_TENURE &&
            tenure <= APP_CONFIG.LOAN.MAX_TENURE
        );
    }

    displayResults(results) {
        const { emi, totalInterest, totalAmount } = results;

        // Update result elements
        this.updateElement('emiAmount', Format.currency(emi));
        this.updateElement('totalInterest', Format.currency(totalInterest));
        this.updateElement('totalAmount', Format.currency(totalAmount));

        // Show breakdown if element exists
        this.showBreakdown(results);
    }

    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }

    clearResults() {
        this.updateElement('emiAmount', '₹0');
        this.updateElement('totalInterest', '₹0');
        this.updateElement('totalAmount', '₹0');
    }

    showBreakdown(results) {
        const { loanAmount, totalInterest, totalAmount } = results;
        
        // Create breakdown chart data
        const principalPercentage = (loanAmount / totalAmount) * 100;
        const interestPercentage = (totalInterest / totalAmount) * 100;

        // Update progress bars if they exist
        const principalBar = document.getElementById('principalBar');
        const interestBar = document.getElementById('interestBar');

        if (principalBar && interestBar) {
            principalBar.style.width = `${principalPercentage}%`;
            interestBar.style.width = `${interestPercentage}%`;
        }

        // Update percentage labels
        this.updateElement('principalPercentage', `${principalPercentage.toFixed(1)}%`);
        this.updateElement('interestPercentage', `${interestPercentage.toFixed(1)}%`);
    }

    updateProgressIndicators(amount, rate, tenure) {
        // Amount progress (relative to max loan amount)
        const amountProgress = (amount / APP_CONFIG.LOAN.MAX_AMOUNT) * 100;
        this.updateProgressBar('amountProgress', amountProgress);

        // Rate progress (relative to max rate of 30%)
        const rateProgress = (rate / 30) * 100;
        this.updateProgressBar('rateProgress', rateProgress);

        // Tenure progress (relative to max tenure)
        const tenureProgress = (tenure / APP_CONFIG.LOAN.MAX_TENURE) * 100;
        this.updateProgressBar('tenureProgress', tenureProgress);
    }

    updateProgressBar(id, percentage) {
        const progressBar = document.getElementById(id);
        if (progressBar) {
            progressBar.style.width = `${Math.min(percentage, 100)}%`;
        }
    }

    generateSchedule() {
        const loanAmount = this.parseAmount(document.getElementById('loanAmount')?.value);
        const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
        const loanTenure = parseInt(document.getElementById('loanTenure')?.value) || 0;

        if (!this.validateInputs(loanAmount, interestRate, loanTenure)) {
            showAlert('Please enter valid loan details to generate schedule.', 'error');
            return;
        }

        const schedule = EMI.schedule(loanAmount, interestRate, loanTenure);
        this.displaySchedule(schedule);
    }

    displaySchedule(schedule) {
        const modal = document.getElementById('scheduleModal');
        const tableBody = document.getElementById('scheduleTableBody');

        if (!modal || !tableBody) {
            console.warn('Schedule modal elements not found');
            return;
        }

        // Clear existing rows
        tableBody.innerHTML = '';

        // Populate schedule table
        schedule.forEach(payment => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${payment.emiNumber}</td>
                <td>₹${Format.number(payment.amount)}</td>
                <td>₹${Format.number(payment.principal)}</td>
                <td>₹${Format.number(payment.interest)}</td>
                <td>₹${Format.number(payment.balance)}</td>
            `;
            tableBody.appendChild(row);
        });

        // Show modal
        showModal('scheduleModal');
    }

    exportSchedule() {
        const loanAmount = this.parseAmount(document.getElementById('loanAmount')?.value);
        const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
        const loanTenure = parseInt(document.getElementById('loanTenure')?.value) || 0;

        if (!this.validateInputs(loanAmount, interestRate, loanTenure)) {
            showAlert('Please enter valid loan details to export schedule.', 'error');
            return;
        }

        const schedule = EMI.schedule(loanAmount, interestRate, loanTenure);
        
        // Create CSV content
        let csvContent = "EMI Number,EMI Amount,Principal,Interest,Balance\\n";
        schedule.forEach(payment => {
            csvContent += `${payment.emiNumber},${payment.amount},${payment.principal},${payment.interest},${payment.balance}\\n`;
        });

        // Download CSV file
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `emi_schedule_${loanAmount}_${loanTenure}months.csv`;
        link.click();
        window.URL.revokeObjectURL(url);

        showAlert('EMI schedule exported successfully!', 'success');
    }

    reset() {
        this.setDefaultValues();
        this.updateCalculation();
        showAlert('Calculator reset to default values.', 'info');
    }
}

// Global functions for calculator
function calculateEMI() {
    if (window.emiCalculator) {
        window.emiCalculator.updateCalculation();
    }
}

function showCalculator() {
    const calculatorSection = document.getElementById('calculator');
    if (calculatorSection) {
        calculatorSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function generateEMISchedule() {
    if (window.emiCalculator) {
        window.emiCalculator.generateSchedule();
    }
}

function exportEMISchedule() {
    if (window.emiCalculator) {
        window.emiCalculator.exportSchedule();
    }
}

function resetCalculator() {
    if (window.emiCalculator) {
        window.emiCalculator.reset();
    }
}

// Initialize calculator when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.emiCalculator = new EMICalculator();
});

// Export functions
window.calculateEMI = calculateEMI;
window.showCalculator = showCalculator;
window.generateEMISchedule = generateEMISchedule;
window.exportEMISchedule = exportEMISchedule;
window.resetCalculator = resetCalculator;

console.log('🧮 EMI Calculator module loaded');
'''

with open('frontend/js/calculator.js', 'w') as f:
    f.write(calculator_js)

print("Created frontend/js/calculator.js - EMI calculator module")
print("Created frontend/js/auth.js - Authentication module")
print("Created frontend/js/api.js - API service")