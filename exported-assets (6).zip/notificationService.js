const nodemailer = require('nodemailer');

class NotificationService {
    constructor() {
        this.transporter = nodemailer.createTransporter({
            host: process.env.EMAIL_HOST || 'smtp.gmail.com',
            port: process.env.EMAIL_PORT || 587,
            secure: false,
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });
    }

    /**
     * Send EMI reminder email
     */
    async sendEMIReminder(user, loan, emi) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: `EMI Reminder - Due Date: ${new Date(emi.dueDate).toLocaleDateString()}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #2563eb;">EMI Payment Reminder</h2>
                    <p>Dear ${user.name},</p>
                    <p>This is a reminder that your EMI payment is due soon.</p>
                    <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Payment Details:</h3>
                        <p><strong>Loan ID:</strong> ${loan._id}</p>
                        <p><strong>EMI Number:</strong> ${emi.emiNumber}</p>
                        <p><strong>Amount:</strong> ₹${emi.amount.toLocaleString()}</p>
                        <p><strong>Due Date:</strong> ${new Date(emi.dueDate).toLocaleDateString()}</p>
                    </div>
                    <a href="${process.env.FRONTEND_URL}/dashboard" 
                       style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                       Pay Now
                    </a>
                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        Please ensure timely payment to avoid late fees and maintain your credit score.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending EMI reminder:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send payment confirmation email
     */
    async sendPaymentConfirmation(user, transaction) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: user.email,
            subject: 'Payment Confirmation',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">Payment Confirmed</h2>
                    <p>Dear ${user.name},</p>
                    <p>Your payment has been successfully processed.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
                        <h3>Transaction Details:</h3>
                        <p><strong>Transaction ID:</strong> ${transaction._id}</p>
                        <p><strong>Amount:</strong> ₹${transaction.amount.toLocaleString()}</p>
                        <p><strong>Type:</strong> ${transaction.type.replace('_', ' ').toUpperCase()}</p>
                        <p><strong>Date:</strong> ${new Date(transaction.createdAt).toLocaleString()}</p>
                    </div>
                    <p style="color: #64748b; font-size: 14px;">
                        Thank you for using our platform.
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending payment confirmation:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Send loan approval notification
     */
    async sendLoanApproval(borrower, loan) {
        const mailOptions = {
            from: `"P2P Lending Platform" <${process.env.EMAIL_USER}>`,
            to: borrower.email,
            subject: 'Loan Application Approved',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #10b981;">Congratulations! Your Loan is Approved</h2>
                    <p>Dear ${borrower.name},</p>
                    <p>We're pleased to inform you that your loan application has been approved.</p>
                    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Loan Details:</h3>
                        <p><strong>Amount:</strong> ₹${loan.amount.toLocaleString()}</p>
                        <p><strong>Interest Rate:</strong> ${loan.interestRate}% per annum</p>
                        <p><strong>EMI:</strong> ₹${loan.emi.toLocaleString()}</p>
                    </div>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true };
        } catch (error) {
            console.error('Error sending notification:', error);
            return { success: false, error: error.message };
        }
    }
}

module.exports = new NotificationService();
