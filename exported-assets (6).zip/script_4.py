# Create bank account model
bank_account_model = '''const mongoose = require('mongoose');

const bankAccountSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    accountNumber: {
        type: String,
        required: [true, 'Account number is required'],
        match: [/^[0-9]{9,18}$/, 'Please enter a valid account number']
    },
    ifscCode: {
        type: String,
        required: [true, 'IFSC code is required'],
        match: [/^[A-Z]{4}0[A-Z0-9]{6}$/, 'Please enter a valid IFSC code']
    },
    bankName: {
        type: String,
        required: [true, 'Bank name is required']
    },
    branchName: String,
    accountHolderName: {
        type: String,
        required: [true, 'Account holder name is required']
    },
    accountType: {
        type: String,
        enum: ['savings', 'current'],
        default: 'savings'
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    isPrimary: {
        type: Boolean,
        default: false
    },
    verificationDetails: {
        method: String,
        date: Date,
        status: {
            type: String,
            enum: ['pending', 'success', 'failed'],
            default: 'pending'
        }
    }
}, {
    timestamps: true
});

// Ensure only one primary account per user
bankAccountSchema.pre('save', async function(next) {
    if (this.isPrimary && this.isModified('isPrimary')) {
        await this.constructor.updateMany(
            { user: this.user, _id: { $ne: this._id } },
            { isPrimary: false }
        );
    }
    next();
});

module.exports = mongoose.model('BankAccount', bankAccountSchema);
'''

with open('models/BankAccount.js', 'w') as f:
    f.write(bank_account_model)

# Create config files
database_config = '''const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });

        console.log(`MongoDB Connected: ${conn.connection.host}`);
        
        // Log database name
        console.log(`Database: ${conn.connection.name}`);
        
        // Set up connection event listeners
        mongoose.connection.on('error', (err) => {
            console.error('MongoDB connection error:', err);
        });

        mongoose.connection.on('disconnected', () => {
            console.log('MongoDB disconnected');
        });

        // Graceful exit
        process.on('SIGINT', async () => {
            await mongoose.connection.close();
            console.log('MongoDB connection closed through app termination');
            process.exit(0);
        });

        return conn;
    } catch (error) {
        console.error('Database connection failed:', error.message);
        process.exit(1);
    }
};

module.exports = connectDB;
'''

with open('config/database.js', 'w') as f:
    f.write(database_config)

# Create logger configuration
logger_config = '''const winston = require('winston');
const path = require('path');

// Define log format
const logFormat = winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.json()
);

// Create logger instance
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: logFormat,
    defaultMeta: { service: 'p2p-lending-api' },
    transports: [
        // Write all logs with level 'error' and below to error.log
        new winston.transports.File({
            filename: path.join(__dirname, '../logs/error.log'),
            level: 'error'
        }),
        // Write all logs to combined.log
        new winston.transports.File({
            filename: path.join(__dirname, '../logs/combined.log')
        })
    ]
});

// If we're not in production, log to the console as well
if (process.env.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
        )
    }));
}

module.exports = logger;
'''

with open('config/logger.js', 'w') as f:
    f.write(logger_config)

# Create cron jobs for automation
cron_jobs = '''const cron = require('node-cron');
const Loan = require('../models/Loan');
const User = require('../models/User');
const notificationService = require('../services/notificationService');

class CronJobs {
    static init() {
        // Run EMI reminder every day at 9 AM
        cron.schedule('0 9 * * *', async () => {
            console.log('Running EMI reminder job...');
            await this.sendEMIReminders();
        });

        // Run overdue EMI check every day at 6 PM
        cron.schedule('0 18 * * *', async () => {
            console.log('Running overdue EMI check...');
            await this.checkOverdueEMIs();
        });

        // Run monthly investment opportunities notification (1st of every month at 10 AM)
        cron.schedule('0 10 1 * *', async () => {
            console.log('Running investment opportunities notification...');
            await this.notifyInvestmentOpportunities();
        });

        console.log('Cron jobs initialized');
    }

    static async sendEMIReminders() {
        try {
            const today = new Date();
            const reminderDate = new Date(today);
            reminderDate.setDate(today.getDate() + 3); // 3 days before due date

            // Find loans with EMIs due in 3 days
            const loans = await Loan.find({
                status: 'active',
                'repayments.dueDate': {
                    $gte: reminderDate,
                    $lt: new Date(reminderDate.getTime() + 24 * 60 * 60 * 1000)
                },
                'repayments.status': 'pending'
            }).populate('borrower', 'name email');

            for (const loan of loans) {
                const dueEMI = loan.repayments.find(emi => 
                    emi.dueDate >= reminderDate && 
                    emi.dueDate < new Date(reminderDate.getTime() + 24 * 60 * 60 * 1000) &&
                    emi.status === 'pending'
                );

                if (dueEMI) {
                    await notificationService.sendEMIReminder(
                        loan.borrower,
                        loan,
                        dueEMI
                    );
                }
            }

            console.log(`EMI reminders sent for ${loans.length} loans`);
        } catch (error) {
            console.error('Error sending EMI reminders:', error);
        }
    }

    static async checkOverdueEMIs() {
        try {
            const today = new Date();
            
            // Find overdue EMIs
            const loans = await Loan.find({
                status: 'active',
                'repayments.dueDate': { $lt: today },
                'repayments.status': 'pending'
            });

            let overdueCount = 0;

            for (const loan of loans) {
                let hasOverdue = false;
                
                for (let i = 0; i < loan.repayments.length; i++) {
                    if (loan.repayments[i].dueDate < today && loan.repayments[i].status === 'pending') {
                        loan.repayments[i].status = 'overdue';
                        hasOverdue = true;
                        overdueCount++;
                    }
                }

                if (hasOverdue) {
                    await loan.save();
                }
            }

            console.log(`Marked ${overdueCount} EMIs as overdue`);
        } catch (error) {
            console.error('Error checking overdue EMIs:', error);
        }
    }

    static async notifyInvestmentOpportunities() {
        try {
            // Get approved loans available for funding
            const availableLoans = await Loan.find({
                status: { $in: ['approved', 'funding'] },
                remainingAmount: { $gt: 0 }
            }).populate('borrower', 'name creditGrade').limit(5);

            if (availableLoans.length === 0) {
                console.log('No investment opportunities available');
                return;
            }

            // Get active lenders
            const lenders = await User.find({
                userType: 'lender',
                kycStatus: 'approved',
                isActive: true
            });

            // Send notifications to lenders
            for (const lender of lenders) {
                for (const loan of availableLoans) {
                    await notificationService.sendInvestmentOpportunity(lender, loan);
                    
                    // Add delay to avoid rate limiting
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }

            console.log(`Investment opportunity notifications sent to ${lenders.length} lenders for ${availableLoans.length} loans`);
        } catch (error) {
            console.error('Error sending investment opportunity notifications:', error);
        }
    }

    // Manual methods for testing
    static async runEMIReminders() {
        await this.sendEMIReminders();
    }

    static async runOverdueCheck() {
        await this.checkOverdueEMIs();
    }

    static async runInvestmentNotifications() {
        await this.notifyInvestmentOpportunities();
    }
}

module.exports = CronJobs;
'''

with open('jobs/cronJobs.js', 'w') as f:
    f.write(cron_jobs)

# Create data seeder
data_seeder = '''const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Import models
const User = require('../models/User');
const Loan = require('../models/Loan');
const connectDB = require('../config/database');

// Sample data
const sampleUsers = [
    {
        name: 'Admin User',
        email: 'admin@p2plending.com',
        phone: '9876543210',
        password: 'admin123',
        userType: 'admin',
        kycStatus: 'approved',
        isActive: true,
        emailVerified: true,
        phoneVerified: true
    },
    {
        name: 'Rajesh Kumar',
        email: 'rajesh@example.com',
        phone: '9876543211',
        password: 'password123',
        userType: 'borrower',
        kycStatus: 'approved',
        creditGrade: 'A',
        personalInfo: {
            monthlyIncome: 75000,
            occupation: 'Software Engineer',
            maritalStatus: 'married'
        }
    },
    {
        name: 'Priya Sharma',
        email: 'priya@example.com',
        phone: '9876543212',
        password: 'password123',
        userType: 'borrower',
        kycStatus: 'approved',
        creditGrade: 'B',
        personalInfo: {
            monthlyIncome: 45000,
            occupation: 'Teacher',
            maritalStatus: 'single'
        }
    },
    {
        name: 'Amit Patel',
        email: 'amit@example.com',
        phone: '9876543213',
        password: 'password123',
        userType: 'lender',
        kycStatus: 'approved',
        personalInfo: {
            monthlyIncome: 120000,
            occupation: 'Business Owner'
        }
    },
    {
        name: 'Sunita Verma',
        email: 'sunita@example.com',
        phone: '9876543214',
        password: 'password123',
        userType: 'lender',
        kycStatus: 'approved',
        personalInfo: {
            monthlyIncome: 85000,
            occupation: 'Doctor'
        }
    }
];

const seedData = async () => {
    try {
        await connectDB();

        // Clear existing data
        console.log('Clearing existing data...');
        await User.deleteMany({});
        await Loan.deleteMany({});

        // Create users
        console.log('Creating users...');
        const createdUsers = await User.create(sampleUsers);
        console.log(`Created ${createdUsers.length} users`);

        // Find borrowers for loan creation
        const borrowers = createdUsers.filter(user => user.userType === 'borrower');

        // Create sample loans
        const sampleLoans = [
            {
                borrower: borrowers[0]._id,
                amount: 500000,
                purpose: 'Business Expansion',
                tenure: 24,
                interestRate: 12,
                emi: 23537,
                creditGrade: 'A',
                status: 'approved',
                description: 'Need funds to expand my software consultancy business'
            },
            {
                borrower: borrowers[1]._id,
                amount: 200000,
                purpose: 'Education',
                tenure: 36,
                interestRate: 10,
                emi: 6450,
                creditGrade: 'B',
                status: 'funding',
                totalFunded: 50000,
                remainingAmount: 150000,
                description: 'Higher education course fees'
            }
        ];

        console.log('Creating loans...');
        const createdLoans = await Loan.create(sampleLoans);
        console.log(`Created ${createdLoans.length} loans`);

        console.log('\\n=== Sample Data Created Successfully ===');
        console.log('\\nLogin Credentials:');
        console.log('Admin: admin@p2plending.com / admin123');
        console.log('Borrower 1: rajesh@example.com / password123');
        console.log('Borrower 2: priya@example.com / password123');
        console.log('Lender 1: amit@example.com / password123');
        console.log('Lender 2: sunita@example.com / password123');
        
        process.exit(0);
    } catch (error) {
        console.error('Error seeding data:', error);
        process.exit(1);
    }
};

// Run if called directly
if (require.main === module) {
    seedData();
}

module.exports = seedData;
'''

with open('utils/seedData.js', 'w') as f:
    f.write(data_seeder)

print("Created additional files:")
print("- models/BankAccount.js")
print("- config/database.js") 
print("- config/logger.js")
print("- jobs/cronJobs.js")
print("- utils/seedData.js")