const cron = require('node-cron');
const Loan = require('../models/Loan');
const User = require('../models/User');
const notificationService = require('../services/notificationService');

class CronJobs {
    static init() {
        // Run EMI reminder every day at 9 AM
        cron.schedule('0 9 * * *', async () => {
            console.log('Running EMI reminder job...');
            await this.sendEMIReminders();
        });

        // Run overdue EMI check every day at 6 PM
        cron.schedule('0 18 * * *', async () => {
            console.log('Running overdue EMI check...');
            await this.checkOverdueEMIs();
        });

        // Run monthly investment opportunities notification (1st of every month at 10 AM)
        cron.schedule('0 10 1 * *', async () => {
            console.log('Running investment opportunities notification...');
            await this.notifyInvestmentOpportunities();
        });

        console.log('Cron jobs initialized');
    }

    static async sendEMIReminders() {
        try {
            const today = new Date();
            const reminderDate = new Date(today);
            reminderDate.setDate(today.getDate() + 3); // 3 days before due date

            // Find loans with EMIs due in 3 days
            const loans = await Loan.find({
                status: 'active',
                'repayments.dueDate': {
                    $gte: reminderDate,
                    $lt: new Date(reminderDate.getTime() + 24 * 60 * 60 * 1000)
                },
                'repayments.status': 'pending'
            }).populate('borrower', 'name email');

            for (const loan of loans) {
                const dueEMI = loan.repayments.find(emi => 
                    emi.dueDate >= reminderDate && 
                    emi.dueDate < new Date(reminderDate.getTime() + 24 * 60 * 60 * 1000) &&
                    emi.status === 'pending'
                );

                if (dueEMI) {
                    await notificationService.sendEMIReminder(
                        loan.borrower,
                        loan,
                        dueEMI
                    );
                }
            }

            console.log(`EMI reminders sent for ${loans.length} loans`);
        } catch (error) {
            console.error('Error sending EMI reminders:', error);
        }
    }

    static async checkOverdueEMIs() {
        try {
            const today = new Date();

            // Find overdue EMIs
            const loans = await Loan.find({
                status: 'active',
                'repayments.dueDate': { $lt: today },
                'repayments.status': 'pending'
            });

            let overdueCount = 0;

            for (const loan of loans) {
                let hasOverdue = false;

                for (let i = 0; i < loan.repayments.length; i++) {
                    if (loan.repayments[i].dueDate < today && loan.repayments[i].status === 'pending') {
                        loan.repayments[i].status = 'overdue';
                        hasOverdue = true;
                        overdueCount++;
                    }
                }

                if (hasOverdue) {
                    await loan.save();
                }
            }

            console.log(`Marked ${overdueCount} EMIs as overdue`);
        } catch (error) {
            console.error('Error checking overdue EMIs:', error);
        }
    }

    static async notifyInvestmentOpportunities() {
        try {
            // Get approved loans available for funding
            const availableLoans = await Loan.find({
                status: { $in: ['approved', 'funding'] },
                remainingAmount: { $gt: 0 }
            }).populate('borrower', 'name creditGrade').limit(5);

            if (availableLoans.length === 0) {
                console.log('No investment opportunities available');
                return;
            }

            // Get active lenders
            const lenders = await User.find({
                userType: 'lender',
                kycStatus: 'approved',
                isActive: true
            });

            // Send notifications to lenders
            for (const lender of lenders) {
                for (const loan of availableLoans) {
                    await notificationService.sendInvestmentOpportunity(lender, loan);

                    // Add delay to avoid rate limiting
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }

            console.log(`Investment opportunity notifications sent to ${lenders.length} lenders for ${availableLoans.length} loans`);
        } catch (error) {
            console.error('Error sending investment opportunity notifications:', error);
        }
    }

    // Manual methods for testing
    static async runEMIReminders() {
        await this.sendEMIReminders();
    }

    static async runOverdueCheck() {
        await this.checkOverdueEMIs();
    }

    static async runInvestmentNotifications() {
        await this.notifyInvestmentOpportunities();
    }
}

module.exports = CronJobs;
