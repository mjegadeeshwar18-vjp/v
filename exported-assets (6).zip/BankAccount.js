const mongoose = require('mongoose');

const bankAccountSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    accountNumber: {
        type: String,
        required: [true, 'Account number is required'],
        match: [/^[0-9]{9,18}$/, 'Please enter a valid account number']
    },
    ifscCode: {
        type: String,
        required: [true, 'IFSC code is required'],
        match: [/^[A-Z]{4}0[A-Z0-9]{6}$/, 'Please enter a valid IFSC code']
    },
    bankName: {
        type: String,
        required: [true, 'Bank name is required']
    },
    branchName: String,
    accountHolderName: {
        type: String,
        required: [true, 'Account holder name is required']
    },
    accountType: {
        type: String,
        enum: ['savings', 'current'],
        default: 'savings'
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    isPrimary: {
        type: Boolean,
        default: false
    },
    verificationDetails: {
        method: String,
        date: Date,
        status: {
            type: String,
            enum: ['pending', 'success', 'failed'],
            default: 'pending'
        }
    }
}, {
    timestamps: true
});

// Ensure only one primary account per user
bankAccountSchema.pre('save', async function(next) {
    if (this.isPrimary && this.isModified('isPrimary')) {
        await this.constructor.updateMany(
            { user: this.user, _id: { $ne: this._id } },
            { isPrimary: false }
        );
    }
    next();
});

module.exports = mongoose.model('BankAccount', bankAccountSchema);
